/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Settings of the web transfer kept while the screen is left and re-entered. */
private object WebUi {
    val port = mutableStateOf("8080")
    val askPass = mutableStateOf(true)
    val pass = mutableStateOf((100000..999999).random().toString())
    val write = mutableStateOf(false)
}

@Composable
private fun SwitchLine(title: String, sub: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = null, enabled = enabled)
    }
}

@Composable
private fun InfoLine(label: String, value: String, onCopy: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(vertical = 4.dp)) {
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (onCopy != null) IconButton(onClick = onCopy) { Icon(Icons.Outlined.ContentCopy, "Copy $label") }
    }
}

/** "Transfer to computer" is on: this phone serves a web file manager; the computer just opens the link in a browser. */
@Composable
fun WebShareTab(vm: AppViewModel) {
    val ctx = LocalContext.current
    var port by WebUi.port
    var askPass by WebUi.askPass
    var pass by WebUi.pass
    var write by WebUi.write
    var ips by remember { mutableStateOf(lanIps()) }
    val running = vm.webServer != null
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
        if (!running) {
            Text(
                "Open the files of \"${vm.rootName}\" in the web browser of a computer on the same Wi-Fi. " +
                    "You can view, download, upload, rename and delete files. Keep IA Manager open while sharing.",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    SwitchLine("Ask for a password", "Recommended. Without it everyone on your Wi-Fi can open your files.", askPass) {
                        askPass = it
                        if (!it) write = false
                    }
                    if (askPass) OutlinedTextField(
                        value = pass, onValueChange = { pass = it.trim().take(32) }, label = { Text("Password") },
                        singleLine = true, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    )
                    HorizontalDivider()
                    SwitchLine(
                        "Allow upload, rename & delete",
                        if (askPass) "Off: view and download only. Deleted files go to the Recycle Bin." else "Needs a password.",
                        write && askPass, enabled = askPass
                    ) { write = it }
                    HorizontalDivider()
                    OutlinedTextField(
                        value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) },
                        label = { Text("Port") }, singleLine = true,
                        supportingText = { Text("Leave as it is unless another app uses 8080") },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    ips = lanIps()
                    vm.startWebServer(ctx, port.toIntOrNull() ?: 8080, if (askPass) pass else "", write && askPass)
                },
                enabled = !askPass || pass.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Start sharing") }
        } else {
            ElevatedCard(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF34A853)))
                        Spacer(Modifier.width(8.dp))
                        Text("Sharing is on", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Open this link in your computer's browser", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (ips.isEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text("No Wi-Fi address found. Connect to a Wi-Fi network or turn on the hotspot.")
                    }
                    ips.forEach { ip ->
                        val link = "http://$ip:${vm.webPort}"
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                link, color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { copyFtpText(ctx, link, "Link") }) { Icon(Icons.Outlined.ContentCopy, "Copy link") }
                            IconButton(onClick = { shareFtpText(ctx, link, "Share link") }) { Icon(Icons.Outlined.Share, "Share link") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(4.dp))
                    if (vm.webPass.isNotEmpty()) InfoLine("Password", vm.webPass) { copyFtpText(ctx, vm.webPass, "Password") }
                    InfoLine("Access", if (vm.webWrite) "View, download, upload, rename & delete" else "View and download only")
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "Type the link into the address bar of Chrome, Edge or Firefox. The computer must be on the same Wi-Fi as this phone.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.stopWebServer() }, modifier = Modifier.fillMaxWidth()) { Text("Stop sharing") }
        }
    }
}
