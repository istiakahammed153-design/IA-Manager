/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

/**
 * The page the computer's browser shows (served by [WebServer]). One self-contained file: no internet needed.
 * Note: this text must not contain the dollar sign, because Kotlin would read it as a template.
 */
internal val WEB_PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IA Manager - Files</title>
<style>
:root{--bg:#f4f6fb;--card:#fff;--text:#18202e;--muted:#6a7488;--line:#e3e8f1;--brand:#14408f;--brand2:#0b2a5b;--accent:#1a73e8;--hover:#f0f4fc;--danger:#d93025;--ok:#1e8e3e}
@media (prefers-color-scheme:dark){:root{--bg:#0d1220;--card:#151c2e;--text:#e8ecf5;--muted:#93a0ba;--line:#242d44;--hover:#1b2438;--accent:#6ea8ff}}
*{box-sizing:border-box}
html,body{margin:0}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
header{background:linear-gradient(135deg,var(--brand2),var(--brand));color:#fff;padding:18px 20px}
header .in{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:14px}
.logo{width:42px;height:42px;border-radius:12px;background:rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center}
header h1{font-size:20px;margin:0;font-weight:700}
header p{margin:2px 0 0;font-size:13px;color:#c3d1ee}
main{max-width:1000px;margin:0 auto;padding:16px}
.bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:12px}
#crumbs{flex:1 1 280px;font-size:15px;display:flex;flex-wrap:wrap;align-items:center;gap:2px;min-width:0}
.crumb{color:var(--accent);text-decoration:none;padding:4px 6px;border-radius:8px;font-weight:600}
.crumb:hover{background:var(--hover)}
.crumb:last-child{color:var(--text)}
.sep{color:var(--muted)}
.btn{border:1px solid var(--line);background:var(--card);color:var(--text);border-radius:10px;padding:9px 14px;font-size:14px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:6px;text-decoration:none}
.btn:hover{background:var(--hover)}
.btn.primary{background:var(--accent);border-color:var(--accent);color:#fff}
.btn.primary:hover{filter:brightness(1.08)}
input.find{border:1px solid var(--line);background:var(--card);color:var(--text);border-radius:10px;padding:9px 12px;font-size:14px;min-width:0;width:200px}
.chip{font-size:12px;padding:5px 10px;border-radius:999px;background:var(--hover);color:var(--muted);font-weight:600}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden}
.head,.row{display:flex;align-items:center;gap:12px;padding:10px 16px}
.head{font-size:12px;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--line);user-select:none}
.head span{cursor:pointer}
.row{border-bottom:1px solid var(--line)}
.row:last-child{border-bottom:0}
.row:hover{background:var(--hover)}
.c-name{flex:1;min-width:0;display:flex;align-items:center;gap:12px}
.c-size{width:90px;text-align:right;color:var(--muted);font-size:13px}
.c-date{width:150px;color:var(--muted);font-size:13px}
.c-act{width:112px;display:flex;justify-content:flex-end;gap:2px}
.name{color:var(--text);text-decoration:none;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block}
.name:hover{color:var(--accent)}
.badge{flex:none;width:38px;height:38px;border-radius:10px;color:#fff;font-size:10px;font-weight:800;display:flex;align-items:center;justify-content:center;letter-spacing:.02em}
.b-img{background:#e91e63}.b-vid{background:#7c4dff}.b-aud{background:#fb8c00}.b-doc{background:#1a73e8}.b-zip{background:#8d6e63}.b-apk{background:#3ddc84;color:#0b3d20}.b-other{background:#78909c}
.folder{flex:none;width:38px;height:38px;display:flex;align-items:center;justify-content:center}
.ib{border:0;background:transparent;color:var(--muted);width:34px;height:34px;border-radius:9px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;text-decoration:none}
.ib:hover{background:var(--line);color:var(--text)}
.ib.del:hover{color:var(--danger)}
.ib svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.empty{padding:48px 16px;text-align:center;color:var(--muted)}
footer{max-width:1000px;margin:0 auto;padding:8px 16px 28px;font-size:12px;color:var(--muted);text-align:center}
#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(90px);background:#202636;color:#fff;padding:11px 18px;border-radius:12px;font-size:14px;transition:transform .25s;z-index:60;max-width:90vw}
#toast.show{transform:translateX(-50%) translateY(0)}
#toast.err{background:var(--danger)}
#ups{position:fixed;right:16px;bottom:16px;width:320px;max-width:calc(100vw - 32px);z-index:40;display:none}
#ups .card{padding:10px 12px;box-shadow:0 8px 30px rgba(0,0,0,.25)}
#ups h4{margin:0 0 6px;font-size:13px;display:flex;justify-content:space-between;align-items:center}
.up{margin:8px 0}
.up .t{font-size:12px;display:flex;justify-content:space-between;gap:8px}
.up .t b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}
.up .pb{height:5px;border-radius:5px;background:var(--line);margin-top:4px;overflow:hidden}
.up .pb i{display:block;height:100%;width:0;background:var(--accent);transition:width .15s}
.up.ok .pb i{background:var(--ok)}.up.bad .pb i{background:var(--danger)}
#drop{position:fixed;inset:0;background:rgba(20,64,143,.82);color:#fff;font-size:24px;font-weight:700;display:none;align-items:center;justify-content:center;z-index:50;text-align:center;padding:20px}
#view{position:fixed;inset:0;background:rgba(5,8,16,.92);display:none;align-items:center;justify-content:center;z-index:55;flex-direction:column;padding:16px}
#view .top{position:absolute;top:0;left:0;right:0;display:flex;justify-content:space-between;align-items:center;padding:12px 16px;color:#fff;gap:12px}
#view .top span{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#view img,#view video{max-width:96vw;max-height:84vh;border-radius:8px;background:#000}
#view audio{width:min(520px,90vw)}
#view .btn{background:rgba(255,255,255,.14);border-color:transparent;color:#fff}
#login{display:none;max-width:380px;margin:60px auto;padding:28px;text-align:center}
#login h2{margin:12px 0 4px}
#login p{margin:0 0 18px;color:var(--muted);font-size:14px}
#login input{width:100%;border:1px solid var(--line);background:var(--bg);color:var(--text);border-radius:12px;padding:13px 14px;font-size:18px;text-align:center;letter-spacing:.2em;margin-bottom:12px}
#login .btn{width:100%;justify-content:center;padding:12px}
#login .msg{color:var(--danger);font-size:13px;min-height:18px;margin-top:10px}
@media (max-width:680px){.c-date{display:none}.c-size{width:70px}.c-act{width:80px}input.find{width:100%}.row,.head{padding:9px 10px}}
</style>
</head>
<body>
<header><div class="in">
<div class="logo"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg></div>
<div><h1>IA Manager</h1><p>Your phone's files in this browser</p></div>
</div></header>
<main>
<div id="login" class="card">
<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>
<h2>Enter password</h2>
<p>Shown on the phone, in IA Manager.</p>
<form id="lf"><input id="pw" type="password" autocomplete="off" placeholder="Password" autofocus><button class="btn primary" type="submit">Open files</button></form>
<div class="msg" id="lmsg"></div>
</div>
<div id="app" style="display:none">
<div class="bar">
<div id="crumbs"></div>
</div>
<div class="bar">
<button class="btn primary" id="bUp" style="display:none"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M6 10l6-6 6 6M4 20h16"/></svg>Upload</button>
<button class="btn" id="bNew" style="display:none">New folder</button>
<a class="btn" id="bZip" href="#">Download folder (ZIP)</a>
<span class="chip" id="ro" style="display:none">Read only</span>
<span style="flex:1"></span>
<input class="find" id="find" placeholder="Search in this folder" autocomplete="off">
</div>
<input type="file" id="pick" multiple style="display:none">
<div class="card">
<div class="head"><span class="c-name" data-s="name">Name</span><span class="c-size" data-s="size">Size</span><span class="c-date" data-s="date">Modified</span><span class="c-act"></span></div>
<div id="list"></div>
</div>
</div>
</main>
<footer>@@OWNER@@</footer>
<div id="ups"><div class="card"><h4><span>Uploads</span><button class="ib" id="upx" title="Close"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></h4><div id="uplist"></div></div></div>
<div id="drop">Drop files to upload them to this folder</div>
<div id="view"><div class="top"><span id="vname"></span><span><a class="btn" id="vdl" href="#">Download</a> <button class="btn" id="vx">Close</button></span></div><div id="vbody"></div></div>
<div id="toast"></div>
<script>
(function(){
var NEEDLOGIN = '@@LOGIN@@' === '1';
var S = {path:'', items:[], write:false, sort:'name', asc:true, filter:''};
var g = function(id){ return document.getElementById(id); };
var enc = encodeURIComponent;

function el(tag, cls, text){ var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
function icon(paths){ var s = document.createElementNS('http://www.w3.org/2000/svg','svg'); s.setAttribute('viewBox','0 0 24 24'); s.innerHTML = paths; return s; }
var I = {
  dl:'<path d="M12 4v12M6 12l6 6 6-6M4 20h16"/>',
  ren:'<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13 7l4 4"/>',
  del:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'
};
var timer = 0;
function toast(msg, bad){ var t = g('toast'); t.textContent = msg; t.className = 'show' + (bad ? ' err' : ''); clearTimeout(timer); timer = setTimeout(function(){ t.className = ''; }, 3200); }

function api(url, opts){
  opts = opts || {};
  opts.headers = {'X-IA':'1'};
  opts.credentials = 'same-origin';
  return fetch(url, opts).then(function(r){
    if (r.ok) return r;
    return r.json().then(function(j){ return j; }, function(){ return {}; }).then(function(j){
      if (r.status === 401 && url.indexOf('/api/login') !== 0) showLogin();
      var e = new Error(j.error || ('Error ' + r.status)); e.status = r.status; throw e;
    });
  });
}
function showLogin(){ g('app').style.display = 'none'; g('login').style.display = 'block'; g('pw').focus(); }
function hideLogin(){ g('login').style.display = 'none'; g('app').style.display = 'block'; }
g('lf').addEventListener('submit', function(ev){
  ev.preventDefault();
  g('lmsg').textContent = '';
  api('/api/login', {method:'POST', body: g('pw').value}).then(function(){ g('pw').value = ''; load(hashPath()); })
    .catch(function(e){ g('lmsg').textContent = e.message; });
});

function hashPath(){ try { return decodeURIComponent(location.hash.slice(1)); } catch (e) { return ''; } }
function child(n){ return S.path ? S.path + '/' + n : n; }
function load(path){
  return api('/api/list?p=' + enc(path)).then(function(r){ return r.json(); }).then(function(d){
    S.path = d.path; S.items = d.items; S.write = d.write; hideLogin(); render();
  }).catch(function(e){ if (e.status !== 401) toast(e.message, true); });
}
window.addEventListener('hashchange', function(){ g('find').value = ''; S.filter = ''; load(hashPath()); });

function fmtSize(b){
  if (b < 1024) return b + ' B';
  var u = ['KB','MB','GB','TB'], i = -1;
  do { b = b / 1024; i++; } while (b >= 1024 && i < 3);
  return (b >= 100 ? b.toFixed(0) : b.toFixed(1)) + ' ' + u[i];
}
function fmtDate(t){
  var d = new Date(t);
  return d.toLocaleDateString(undefined, {day:'numeric', month:'short', year:'numeric'}) + ' ' + d.toLocaleTimeString(undefined, {hour:'2-digit', minute:'2-digit'});
}
var EXT = {
  img:'jpg jpeg png gif webp bmp svg heic', vid:'mp4 m4v webm mkv 3gp mov avi', aud:'mp3 m4a aac wav ogg oga opus flac',
  doc:'pdf doc docx xls xlsx ppt pptx txt md csv rtf odt json xml', zip:'zip rar 7z tar gz', apk:'apk apks xapk apkm'
};
function ext(n){ var i = n.lastIndexOf('.'); return i > 0 ? n.slice(i + 1).toLowerCase() : ''; }
function cat(n){ var e = ext(n); for (var k in EXT) { if (EXT[k].split(' ').indexOf(e) >= 0) return k; } return 'other'; }

function btn(svgPaths, title, cls){ var b = el('button', 'ib ' + (cls || '')); b.title = title; b.appendChild(icon(svgPaths)); return b; }

function render(){
  var bc = g('crumbs'); bc.textContent = '';
  var a = el('a', 'crumb', 'Phone storage'); a.href = '#'; bc.appendChild(a);
  var acc = '';
  (S.path ? S.path.split('/') : []).forEach(function(p){
    acc = acc ? acc + '/' + p : p;
    bc.appendChild(el('span', 'sep', '/'));
    var l = el('a', 'crumb', p); l.href = '#' + enc(acc); bc.appendChild(l);
  });
  g('bUp').style.display = S.write ? '' : 'none';
  g('bNew').style.display = S.write ? '' : 'none';
  g('ro').style.display = S.write ? 'none' : '';
  g('bZip').href = '/api/zip?p=' + enc(S.path);

  var f = S.filter.toLowerCase();
  var items = S.items.filter(function(it){ return !f || it.n.toLowerCase().indexOf(f) >= 0; });
  var dir = S.asc ? 1 : -1;
  items.sort(function(x, y){
    if (x.d !== y.d) return x.d ? -1 : 1;
    var r = 0;
    if (S.sort === 'size') r = x.s - y.s; else if (S.sort === 'date') r = x.t - y.t; else r = x.n.toLowerCase() < y.n.toLowerCase() ? -1 : (x.n.toLowerCase() > y.n.toLowerCase() ? 1 : 0);
    return r * dir;
  });
  var list = g('list'); list.textContent = '';
  if (!items.length) { list.appendChild(el('div', 'empty', f ? 'Nothing matches your search' : 'This folder is empty')); return; }
  items.forEach(function(it){
    var path = child(it.n);
    var row = el('div', 'row');
    var nm = el('div', 'c-name');
    if (it.d) {
      var fo = el('div', 'folder'); fo.innerHTML = '<svg width="34" height="34" viewBox="0 0 24 24"><path fill="#f9b928" d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
      nm.appendChild(fo);
    } else {
      nm.appendChild(el('div', 'badge b-' + cat(it.n), (ext(it.n) || 'file').slice(0, 4).toUpperCase()));
    }
    var link = el('a', 'name', it.n); link.title = it.n;
    if (it.d) link.href = '#' + enc(path);
    else { link.href = '/api/file?p=' + enc(path); link.addEventListener('click', function(ev){ ev.preventDefault(); openFile(it, path); }); }
    nm.appendChild(link);
    row.appendChild(nm);
    row.appendChild(el('div', 'c-size', it.d ? '' : fmtSize(it.s)));
    row.appendChild(el('div', 'c-date', fmtDate(it.t)));
    var act = el('div', 'c-act');
    if (!it.d) { var d = btn(I.dl, 'Download'); d.addEventListener('click', function(){ download(path); }); act.appendChild(d); }
    if (S.write) {
      var r = btn(I.ren, 'Rename'); r.addEventListener('click', function(){ rename(it, path); }); act.appendChild(r);
      var x = btn(I.del, 'Move to Recycle Bin', 'del'); x.addEventListener('click', function(){ remove(it, path); }); act.appendChild(x);
    }
    row.appendChild(act);
    list.appendChild(row);
  });
}

document.querySelectorAll('.head span[data-s]').forEach(function(h){
  h.addEventListener('click', function(){
    var k = h.getAttribute('data-s');
    if (S.sort === k) S.asc = !S.asc; else { S.sort = k; S.asc = true; }
    render();
  });
});
g('find').addEventListener('input', function(){ S.filter = g('find').value; render(); });

function download(path){ var a = el('a'); a.href = '/api/file?p=' + enc(path) + '&dl=1'; document.body.appendChild(a); a.click(); a.remove(); }
function openFile(it, path){
  var c = cat(it.n), url = '/api/file?p=' + enc(path);
  if (c === 'img' || c === 'vid' || c === 'aud') {
    var b = g('vbody'); b.textContent = '';
    var m = el(c === 'img' ? 'img' : (c === 'vid' ? 'video' : 'audio'));
    m.src = url; if (c !== 'img') { m.controls = true; m.autoplay = true; }
    b.appendChild(m);
    g('vname').textContent = it.n; g('vdl').onclick = function(ev){ ev.preventDefault(); download(path); };
    g('view').style.display = 'flex';
  } else if (ext(it.n) === 'pdf' || ext(it.n) === 'txt') { window.open(url, '_blank'); }
  else download(path);
}
function closeView(){ g('view').style.display = 'none'; g('vbody').textContent = ''; }
g('vx').addEventListener('click', closeView);
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeView(); });

function post(url){ return api(url, {method:'POST'}); }
function rename(it, path){
  var n = prompt('New name', it.n);
  if (!n || n === it.n) return;
  post('/api/rename?p=' + enc(path) + '&name=' + enc(n)).then(function(){ toast('Renamed'); load(S.path); }).catch(function(e){ toast(e.message, true); });
}
function remove(it, path){
  if (!confirm('Move "' + it.n + '" to the Recycle Bin on the phone?')) return;
  post('/api/delete?p=' + enc(path)).then(function(){ toast('Moved to Recycle Bin'); load(S.path); }).catch(function(e){ toast(e.message, true); });
}
g('bNew').addEventListener('click', function(){
  var n = prompt('Folder name');
  if (!n) return;
  post('/api/mkdir?p=' + enc(S.path) + '&name=' + enc(n)).then(function(){ toast('Folder created'); load(S.path); }).catch(function(e){ toast(e.message, true); });
});

// ---- upload (button or drag and drop)
g('bUp').addEventListener('click', function(){ g('pick').click(); });
g('pick').addEventListener('change', function(){ uploadFiles(g('pick').files); g('pick').value = ''; });
g('upx').addEventListener('click', function(){ g('ups').style.display = 'none'; g('uplist').textContent = ''; });
function uploadFiles(files){
  if (!S.write) { toast('Uploading is turned off in IA Manager', true); return; }
  var queue = Array.prototype.slice.call(files), target = S.path;
  if (!queue.length) return;
  g('ups').style.display = 'block';
  var rows = queue.map(function(f){
    var r = el('div', 'up'), t = el('div', 't'), nm = el('b', '', f.name), st = el('span', '', 'Waiting'), pb = el('div', 'pb'), bar = el('i');
    t.appendChild(nm); t.appendChild(st); pb.appendChild(bar); r.appendChild(t); r.appendChild(pb);
    g('uplist').appendChild(r);
    return {el: r, st: st, bar: bar};
  });
  var i = 0;
  function next(){
    if (i >= queue.length) { if (S.path === target) load(S.path); return; }
    var f = queue[i], row = rows[i]; i++;
    var x = new XMLHttpRequest();
    x.open('POST', '/api/upload?p=' + enc(target) + '&name=' + enc(f.name));
    x.setRequestHeader('X-IA', '1');
    x.upload.onprogress = function(e){ if (e.lengthComputable) { row.bar.style.width = (e.loaded * 100 / e.total) + '%'; row.st.textContent = Math.round(e.loaded * 100 / e.total) + '%'; } };
    x.onload = function(){
      if (x.status === 200) { row.el.className = 'up ok'; row.bar.style.width = '100%'; row.st.textContent = 'Done'; }
      else { row.el.className = 'up bad'; var m = 'Failed'; try { m = JSON.parse(x.responseText).error || m; } catch (e) { } row.st.textContent = m; if (x.status === 401) showLogin(); }
      next();
    };
    x.onerror = function(){ row.el.className = 'up bad'; row.st.textContent = 'Connection lost'; next(); };
    row.st.textContent = '0%';
    x.send(f);
  }
  next();
}
var dragDepth = 0;
window.addEventListener('dragenter', function(e){ if (!S.write) return; e.preventDefault(); dragDepth++; g('drop').style.display = 'flex'; });
window.addEventListener('dragover', function(e){ e.preventDefault(); });
window.addEventListener('dragleave', function(){ dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) g('drop').style.display = 'none'; });
window.addEventListener('drop', function(e){
  e.preventDefault(); dragDepth = 0; g('drop').style.display = 'none';
  if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) uploadFiles(e.dataTransfer.files);
});

if (NEEDLOGIN) { api('/api/list?p=').then(function(){ load(hashPath()); }).catch(function(){ showLogin(); }); }
else load(hashPath());
})();
</script>
</body>
</html>
"""
