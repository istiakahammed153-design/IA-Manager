/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// ======================================================================
//  Minimal FTP server (share the phone's files with a PC on the same Wi-Fi)
// ======================================================================

class FtpServer(
    private val root: File,
    private val port: Int,
    private val user: String,
    private val pass: String,
    private val readOnly: Boolean
) {
    @Volatile
    private var running = false
    private var server: ServerSocket? = null
    private val clients = Collections.synchronizedList(ArrayList<Socket>())

    fun start() {
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(port))
        server = ss
        running = true
        Thread {
            while (running) {
                try {
                    val s = ss.accept()
                    clients.add(s)
                    Thread { Session(s).run() }.start()
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        synchronized(clients) {
            clients.forEach { try { it.close() } catch (e: Exception) { } }
            clients.clear()
        }
    }

    private inner class Session(val ctl: Socket) {
        private val input = BufferedReader(InputStreamReader(ctl.getInputStream(), Charsets.UTF_8))
        private val out = ctl.getOutputStream()
        private var cwd = "/"
        private var gotUser = false
        private var authed = user.isEmpty()
        private var pasv: ServerSocket? = null
        private var active: InetSocketAddress? = null
        private var rest = 0L
        private var renameFrom: File? = null

        private fun reply(s: String) {
            out.write((s + "\r\n").toByteArray(Charsets.UTF_8))
            out.flush()
        }

        private fun virtual(arg: String): String {
            val raw = if (arg.startsWith("/")) arg else if (cwd == "/") "/$arg" else "$cwd/$arg"
            val parts = ArrayList<String>()
            for (p in raw.split("/")) {
                when (p) {
                    "", "." -> {}
                    ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
                    else -> parts.add(p)
                }
            }
            return "/" + parts.joinToString("/")
        }

        private fun fileOf(virt: String): File = if (virt == "/") root else File(root, virt.trimStart('/'))

        private fun listLine(f: File): String {
            val d = f.isDirectory
            val date = SimpleDateFormat("MMM dd HH:mm", Locale.US).format(Date(f.lastModified()))
            return String.format(Locale.US, "%s 1 ftp ftp %12d %s %s", if (d) "drwxr-xr-x" else "-rw-r--r--", if (d) 4096L else f.length(), date, f.name)
        }

        private fun openData(): Socket? {
            return try {
                val p = pasv
                if (p != null) {
                    p.soTimeout = 20000
                    val s = p.accept()
                    p.close()
                    pasv = null
                    s
                } else {
                    val a = active
                    if (a != null) {
                        val s = Socket()
                        s.connect(a, 15000)
                        active = null
                        s
                    } else null
                }
            } catch (e: Exception) {
                null
            }
        }

        fun run() {
            try {
                reply("220 IA Manager FTP ready")
                while (true) {
                    val line = input.readLine() ?: break
                    val sp = line.indexOf(' ')
                    val cmd = (if (sp < 0) line else line.substring(0, sp)).uppercase(Locale.US)
                    val arg = if (sp < 0) "" else line.substring(sp + 1).trim()
                    if (!handle(cmd, arg)) break
                }
            } catch (e: Exception) {
            } finally {
                try { pasv?.close() } catch (e: Exception) { }
                try { ctl.close() } catch (e: Exception) { }
                clients.remove(ctl)
            }
        }

        private fun handle(cmd: String, arg: String): Boolean {
            when (cmd) {
                "USER" -> {
                    if (user.isEmpty()) {
                        reply("230 Logged in")
                    } else {
                        gotUser = arg == user
                        reply("331 Password required")
                    }
                    return true
                }
                "PASS" -> {
                    if (user.isEmpty() || (gotUser && arg == pass)) {
                        authed = true
                        reply("230 Logged in")
                    } else {
                        reply("530 Login incorrect")
                    }
                    return true
                }
                "QUIT" -> {
                    reply("221 Goodbye")
                    return false
                }
                "SYST" -> { reply("215 UNIX Type: L8"); return true }
                "FEAT" -> { reply("211-Features:\r\n SIZE\r\n REST STREAM\r\n UTF8\r\n211 End"); return true }
                "OPTS" -> { reply("200 OK"); return true }
                "NOOP" -> { reply("200 OK"); return true }
            }
            if (!authed) {
                reply("530 Please log in first")
                return true
            }
            when (cmd) {
                "PWD", "XPWD" -> reply("257 \"$cwd\" is current directory")
                "CWD", "XCWD" -> {
                    val v = virtual(arg)
                    if (fileOf(v).isDirectory) {
                        cwd = v
                        reply("250 OK")
                    } else reply("550 No such directory")
                }
                "CDUP", "XCUP" -> {
                    cwd = virtual("..")
                    reply("250 OK")
                }
                "TYPE", "MODE", "STRU" -> reply("200 OK")
                "PASV" -> {
                    try { pasv?.close() } catch (e: Exception) { }
                    val ss = ServerSocket(0, 1, ctl.localAddress)
                    pasv = ss
                    val b = ctl.localAddress.address
                    val p = ss.localPort
                    reply("227 Entering Passive Mode (${b[0].toInt() and 255},${b[1].toInt() and 255},${b[2].toInt() and 255},${b[3].toInt() and 255},${p / 256},${p % 256})")
                }
                "EPSV" -> {
                    try { pasv?.close() } catch (e: Exception) { }
                    val ss = ServerSocket(0, 1, ctl.localAddress)
                    pasv = ss
                    reply("229 Entering Extended Passive Mode (|||${ss.localPort}|)")
                }
                "PORT" -> {
                    val n = arg.split(",").map { it.trim().toIntOrNull() ?: -1 }
                    if (n.size == 6 && n.all { it in 0..255 }) {
                        val host = "${n[0]}.${n[1]}.${n[2]}.${n[3]}"
                        val port = n[4] * 256 + n[5]
                        // Only the connected client may receive data. Otherwise the phone could be used to
                        // reach other machines on the network (the classic FTP "bounce" attack).
                        if (port < 1024 || host != ctl.inetAddress.hostAddress) {
                            reply("504 PORT must point to your own address")
                        } else {
                            active = InetSocketAddress(host, port)
                            reply("200 OK")
                        }
                    } else reply("501 Bad PORT")
                }
                "LIST", "NLST" -> {
                    val target = arg.split(" ").filter { it.isNotEmpty() && !it.startsWith("-") }.joinToString(" ")
                    val dir = fileOf(virtual(if (target.isEmpty()) "." else target))
                    if (!dir.exists()) {
                        reply("550 No such file or directory")
                        return true
                    }
                    reply("150 Opening data connection")
                    val ds = openData()
                    if (ds == null) {
                        reply("425 Can't open data connection")
                    } else {
                        try {
                            val w = ds.getOutputStream()
                            val files = if (dir.isDirectory) (dir.listFiles()?.toList() ?: emptyList()) else listOf(dir)
                            for (f in files) {
                                val line = if (cmd == "LIST") listLine(f) else f.name
                                w.write((line + "\r\n").toByteArray(Charsets.UTF_8))
                            }
                            w.flush()
                            ds.close()
                            reply("226 Transfer complete")
                        } catch (e: Exception) {
                            try { ds.close() } catch (x: Exception) { }
                            reply("426 Transfer aborted")
                        }
                    }
                }
                "RETR" -> {
                    val f = fileOf(virtual(arg))
                    if (!f.isFile) {
                        reply("550 File not found")
                    } else {
                        reply("150 Opening data connection")
                        val ds = openData()
                        if (ds == null) {
                            reply("425 Can't open data connection")
                        } else {
                            try {
                                FileInputStream(f).use { fin ->
                                    if (rest > 0) fin.skip(rest)
                                    fin.copyTo(ds.getOutputStream())
                                }
                                ds.getOutputStream().flush()
                                ds.close()
                                reply("226 Transfer complete")
                            } catch (e: Exception) {
                                try { ds.close() } catch (x: Exception) { }
                                reply("426 Transfer aborted")
                            }
                        }
                        rest = 0
                    }
                }
                "STOR" -> {
                    if (readOnly) {
                        reply("550 Read-only server")
                    } else {
                        val f = fileOf(virtual(arg))
                        reply("150 Opening data connection")
                        val ds = openData()
                        if (ds == null) {
                            reply("425 Can't open data connection")
                        } else {
                            try {
                                FileOutputStream(f).use { fo -> ds.getInputStream().copyTo(fo) }
                                ds.close()
                                reply("226 Transfer complete")
                            } catch (e: Exception) {
                                try { ds.close() } catch (x: Exception) { }
                                reply("426 Transfer aborted")
                            }
                        }
                    }
                }
                "REST" -> {
                    rest = arg.toLongOrNull() ?: 0L
                    reply("350 Restarting at $rest")
                }
                "SIZE" -> {
                    val f = fileOf(virtual(arg))
                    if (f.isFile) reply("213 ${f.length()}") else reply("550 File not found")
                }
                "MDTM" -> {
                    val f = fileOf(virtual(arg))
                    if (f.exists()) {
                        val fmt = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
                        fmt.timeZone = TimeZone.getTimeZone("UTC")
                        reply("213 " + fmt.format(Date(f.lastModified())))
                    } else reply("550 File not found")
                }
                "DELE" -> {
                    if (readOnly) reply("550 Read-only server")
                    else if (fileOf(virtual(arg)).let { it.isFile && it.delete() }) reply("250 Deleted") else reply("550 Cannot delete")
                }
                "RMD", "XRMD" -> {
                    if (readOnly) reply("550 Read-only server")
                    else if (fileOf(virtual(arg)).let { it.isDirectory && it.delete() }) reply("250 Removed") else reply("550 Cannot remove")
                }
                "MKD", "XMKD" -> {
                    if (readOnly) reply("550 Read-only server")
                    else {
                        val v = virtual(arg)
                        if (fileOf(v).mkdirs()) reply("257 \"$v\" created") else reply("550 Cannot create")
                    }
                }
                "RNFR" -> {
                    val f = fileOf(virtual(arg))
                    if (!readOnly && f.exists()) {
                        renameFrom = f
                        reply("350 Ready for RNTO")
                    } else reply("550 Cannot rename")
                }
                "RNTO" -> {
                    val from = renameFrom
                    if (!readOnly && from != null && from.renameTo(fileOf(virtual(arg)))) reply("250 Renamed") else reply("550 Rename failed")
                    renameFrom = null
                }
                else -> reply("502 Command not implemented")
            }
            return true
        }
    }
}

fun localIps(): List<String> = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { ni -> ni.inetAddresses.toList() }
        .filter { it is Inet4Address && !it.isLoopbackAddress }
        .map { it.hostAddress ?: "" }
        .filter { it.isNotEmpty() }
} catch (e: Exception) {
    emptyList()
}

/** The Wi-Fi / hotspot addresses of this phone. Mobile-data addresses are left out when a home-network one exists. */
fun lanIps(): List<String> {
    val all = localIps()
    val lan = all.filter { ip ->
        val p = ip.split(".").mapNotNull { it.toIntOrNull() }
        p.size == 4 && (p[0] == 10 || (p[0] == 192 && p[1] == 168) || (p[0] == 172 && p[1] in 16..31))
    }
    return lan.ifEmpty { all }
}

// ======================================================================
//  UI: tab 1 = share my files (server), tab 2 = connect to an FTP server (client)
// ======================================================================

/**
 * Screen state that must survive leaving the FTP screen (for example while a downloaded file is open),
 * so coming back lands on the same tab, the same folder and the same scroll position.
 */
private object FtpUi {
    /** true = sharing this phone with a computer, false = this phone connects to another phone / FTP server */
    val computerMode = mutableStateOf(true)
    /** phone mode: 0 = connect to another phone / server, 1 = let another phone connect to this one */
    val phoneTab = mutableIntStateOf(0)
    val sPort = mutableStateOf("2121")
    val sUser = mutableStateOf("ia")
    val sPass = mutableStateOf((1000..9999).random().toString())
    val sWrite = mutableStateOf(false)
    val cHost = mutableStateOf("")
    val cPort = mutableStateOf("21")
    val cUser = mutableStateOf("anonymous")
    val cPass = mutableStateOf("")
    val listState = LazyListState()
    var lastPath: String? = null
}

internal fun copyFtpText(ctx: Context, text: String, what: String) {
    try {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("FTP", text))
        Toast.makeText(ctx, "$what copied", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Could not copy", Toast.LENGTH_SHORT).show()
    }
}

internal fun shareFtpText(ctx: Context, text: String, title: String = "Share link") {
    try {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot share", Toast.LENGTH_SHORT).show()
    }
}

/** ftp://user:password@ip:port/ - the single address a computer needs (File Explorer, FileZilla, ...). */
private fun ftpLink(ip: String, port: Int, user: String, pass: String): String =
    if (user.isEmpty()) "ftp://$ip:$port/" else "ftp://${Uri.encode(user)}:${Uri.encode(pass)}@$ip:$port/"

/** Splits a pasted ftp:// link into host, port, username and password; null when it is not an FTP link. */
private fun parseFtpLink(link: String): List<String>? {
    val u = try { Uri.parse(link.trim()) } catch (e: Exception) { return null }
    val host = u.host ?: return null
    if (!"ftp".equals(u.scheme, ignoreCase = true) || host.isEmpty()) return null
    val info = u.userInfo ?: ""
    return listOf(host, (if (u.port > 0) u.port else 21).toString(), info.substringBefore(':').ifEmpty { "anonymous" }, info.substringAfter(':', ""))
}

@Composable
fun FtpScreen(vm: AppViewModel) {
    var computer by FtpUi.computerMode
    var phoneTab by FtpUi.phoneTab
    Column(Modifier.fillMaxSize()) {
        SimpleTop("FTP", onBack = { vm.pop() })
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                Modifier.clickable {
                    computer = !computer
                    // only one kind of sharing at a time
                    if (computer) { if (vm.ftpServer != null) vm.stopFtpServer() } else if (vm.webServer != null) vm.stopWebServer()
                }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (computer) Icons.Outlined.Computer else Icons.Outlined.PhoneAndroid, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Transfer to computer", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (computer) "On: open your files in a computer's web browser" else "Off: connect with another phone",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = computer, onCheckedChange = null)
            }
        }
        if (computer) WebShareTab(vm) else {
            TabRow(selectedTabIndex = phoneTab) {
                Tab(selected = phoneTab == 0, onClick = { phoneTab = 0 }, text = { Text("Connect") })
                Tab(selected = phoneTab == 1, onClick = { phoneTab = 1 }, text = { Text("Share to phone") })
            }
            if (phoneTab == 0) FtpClientTab(vm) else FtpShareTab(vm)
        }
    }
}

@Composable
private fun FtpShareTab(vm: AppViewModel) {
    val ctx = LocalContext.current
    var port by FtpUi.sPort
    var user by FtpUi.sUser
    var pass by FtpUi.sPass
    var allowWrite by FtpUi.sWrite
    var ips by remember { mutableStateOf(lanIps()) }
    val running = vm.ftpServer != null
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(
            "Let another phone browse the files of \"${vm.rootName}\" over the same Wi-Fi. Keep IA Manager open while sharing.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) }, label = { Text("Port") }, singleLine = true, enabled = !running, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Username (empty = anonymous)") }, singleLine = true, enabled = !running, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Password") }, singleLine = true, enabled = !running, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Allow upload / delete / rename", modifier = Modifier.weight(1f))
            Switch(checked = allowWrite, onCheckedChange = { allowWrite = it }, enabled = !running)
        }
        Spacer(Modifier.height(16.dp))
        if (running) {
            ElevatedCard(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF34A853)))
                        Spacer(Modifier.width(8.dp))
                        Text("Server is running", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (ips.isEmpty()) Text("No Wi-Fi address found. Connect to a Wi-Fi network or turn on the hotspot.")
                    ips.forEach { ip ->
                        val link = ftpLink(ip, vm.ftpPort, vm.ftpUser, vm.ftpPass)
                        Text("Link for the other phone", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(2.dp))
                        Text(link, color = MaterialTheme.colorScheme.primary, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { copyFtpText(ctx, link, "Link") }) {
                                Icon(Icons.Outlined.ContentCopy, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Copy link")
                            }
                            OutlinedButton(onClick = { shareFtpText(ctx, link, "Share FTP link") }) {
                                Icon(Icons.Outlined.Share, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Share")
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                    Text(
                        (if (vm.ftpUser.isNotEmpty()) "User: ${vm.ftpUser}  \u00B7  Password: ${vm.ftpPass}  \u00B7  " else "No login  \u00B7  ") +
                            (if (vm.ftpWrite) "Read & write" else "Read only"),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "On the other phone, open IA Manager > FTP, switch off \"Transfer to computer\" and paste this link in the Connect tab. " +
                    "Any FTP app works too. Web browsers cannot open FTP links.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.stopFtpServer() }, modifier = Modifier.fillMaxWidth()) { Text("Stop sharing") }
        } else {
            Button(
                onClick = {
                    ips = lanIps()
                    vm.startFtpServer(ctx, port.toIntOrNull() ?: 2121, user.trim(), pass, allowWrite)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Start sharing") }
        }
    }
}

private fun joinPath(a: String, b: String): String = if (a.endsWith("/")) a + b else "$a/$b"

@Composable
private fun FtpClientTab(vm: AppViewModel) {
    var host by FtpUi.cHost
    var port by FtpUi.cPort
    var user by FtpUi.cUser
    var pass by FtpUi.cPass
    var picked by remember { mutableStateOf<FTPFile?>(null) }
    if (!vm.ftpConnected) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("Connect to another phone or an FTP server to browse its files, open them inside the app or download them.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            var link by remember { mutableStateOf("") }
            OutlinedTextField(
                value = link,
                onValueChange = { v ->
                    link = v
                    parseFtpLink(v)?.let { (h, p, u, pw) -> host = h; port = p; user = u; pass = pw }
                },
                label = { Text("Paste FTP link (optional)") },
                supportingText = { Text("ftp://user:password@192.168.0.100:2121/ fills in the fields below") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = host, onValueChange = { host = it.trim() }, label = { Text("Host / IP address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = port, onValueChange = { port = it.filter { c -> c.isDigit() }.take(5) }, label = { Text("Port") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = pass, onValueChange = { pass = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { vm.ftpConnect(host, port.toIntOrNull() ?: 21, user, pass) },
                enabled = host.isNotEmpty() && !vm.ftpBusy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (vm.ftpBusy) "Connecting..." else "Connect") }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(vm.ftpPath, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                TextButton(onClick = { FtpUi.lastPath = null; vm.ftpDisconnect() }) { Text("Disconnect") }
            }
            if (vm.ftpBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
            LaunchedEffect(vm.ftpPath) {
                // new folder -> start at the top; coming back from an opened file keeps the old position
                if (FtpUi.lastPath != vm.ftpPath) {
                    FtpUi.lastPath = vm.ftpPath
                    FtpUi.listState.scrollToItem(0)
                }
            }
            LazyColumn(Modifier.fillMaxSize(), state = FtpUi.listState) {
                item {
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.ftpUp() }.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.ArrowBack, null)
                        Spacer(Modifier.width(16.dp)); Text("..")
                    }
                }
                items(vm.ftpList) { f ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { if (f.isDirectory) vm.ftpOpenDir(f.name) else picked = f }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (f.isDirectory) Icons.Outlined.Folder else Icons.Outlined.InsertDriveFile, null,
                            tint = if (f.isDirectory) FolderYellow else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (!f.isDirectory) Text(fmtSize(f.size), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
    val p = picked
    if (p != null) {
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(p.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = { Text(fmtSize(p.size)) },
            confirmButton = {
                TextButton(onClick = { picked = null; vm.ftpOpenFile(p.name) }) { Text("Open") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { picked = null; vm.ftpDownload(p.name) }) { Text("Download") }
                    TextButton(onClick = { picked = null }) { Text("Cancel") }
                }
            }
        )
    }
}
