/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * A small web file manager: the computer opens http://phone-ip:port in any browser (same Wi-Fi) and can browse,
 * preview, download, upload, rename and delete files. Deleting only moves files to the Recycle Bin.
 * The Vault and the Recycle Bin folders are never reachable.
 */
class WebServer(
    private val root: File,
    private val port: Int,
    /** empty = no password; otherwise the browser first asks for this password */
    private val password: String,
    private val readOnly: Boolean,
    private val showHidden: Boolean,
    private val moveToTrash: (File) -> Unit
) {
    @Volatile
    private var running = false
    private var server: ServerSocket? = null
    private val clients = Collections.synchronizedList(ArrayList<Socket>())
    private val pool = Executors.newCachedThreadPool()
    private val rootCanon: File = try { root.canonicalFile } catch (e: IOException) { root }
    private val sessions: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val random = SecureRandom()

    /** wrong-password counter per computer: after [MAX_FAILS] misses that address is blocked for a minute */
    private class Fails(var count: Int = 0, var lockedUntil: Long = 0L)
    private val fails = ConcurrentHashMap<String, Fails>()

    fun start() {
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(port))
        server = ss
        running = true
        Thread {
            while (running) {
                try {
                    val s = ss.accept()
                    clients.add(s)
                    pool.execute { handle(s) }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        synchronized(clients) {
            clients.forEach { try { it.close() } catch (e: Exception) { } }
            clients.clear()
        }
        sessions.clear()
        pool.shutdownNow()
    }

    // ------------------------------------------------------------------ HTTP plumbing

    private class Request(
        val method: String,
        val path: String,
        val query: Map<String, String>,
        val headers: Map<String, String>,
        val ip: String
    ) {
        fun q(k: String): String? = query[k]
        val contentLength: Long get() = headers["content-length"]?.trim()?.toLongOrNull() ?: -1L
    }

    private class HttpError(val code: Int, message: String) : Exception(message)

    private fun handle(s: Socket) {
        try {
            s.soTimeout = 60_000
            s.tcpNoDelay = true
            val inp = BufferedInputStream(s.getInputStream(), 32 * 1024)
            val out = BufferedOutputStream(s.getOutputStream(), 64 * 1024)
            val req = readRequest(inp, s) ?: return
            try {
                route(req, inp, out)
            } catch (e: HttpError) {
                json(out, e.code, "{\"error\":" + jstr(e.message ?: "Error") + "}")
            }
            out.flush()
        } catch (e: Exception) {
            // the browser closed the connection (page changed, download cancelled): nothing to do
        } finally {
            try { s.close() } catch (e: Exception) { }
            clients.remove(s)
        }
    }

    private fun readLine(inp: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = inp.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) break
            if (c != '\r'.code) sb.append(c.toChar())
            if (sb.length > 16 * 1024) throw HttpError(431, "Request too large")
        }
        return sb.toString()
    }

    private fun readRequest(inp: InputStream, s: Socket): Request? {
        val first = readLine(inp) ?: return null
        val parts = first.split(" ")
        if (parts.size < 2) return null
        val headers = HashMap<String, String>()
        var n = 0
        while (true) {
            val line = readLine(inp) ?: return null
            if (line.isEmpty()) break
            if (++n > 80) return null
            val i = line.indexOf(':')
            if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        val target = parts[1]
        val qi = target.indexOf('?')
        val rawPath = if (qi >= 0) target.substring(0, qi) else target
        val query = HashMap<String, String>()
        if (qi >= 0) for (kv in target.substring(qi + 1).split("&")) {
            if (kv.isEmpty()) continue
            val e = kv.indexOf('=')
            val k = if (e >= 0) kv.substring(0, e) else kv
            val v = if (e >= 0) kv.substring(e + 1) else ""
            query[urlDecode(k)] = urlDecode(v)
        }
        val ip = (s.remoteSocketAddress as? InetSocketAddress)?.address?.hostAddress ?: "?"
        return Request(parts[0].uppercase(), urlDecode(rawPath), query, headers, ip)
    }

    private fun urlDecode(s: String): String = try { URLDecoder.decode(s.replace("+", "%2B"), "UTF-8") } catch (e: Exception) { s }

    private fun head(out: OutputStream, code: Int, type: String, length: Long, extra: String = "") {
        val status = when (code) {
            200 -> "OK"; 206 -> "Partial Content"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 403 -> "Forbidden"
            404 -> "Not Found"; 405 -> "Method Not Allowed"; 409 -> "Conflict"; 411 -> "Length Required"
            416 -> "Range Not Satisfiable"; 429 -> "Too Many Requests"; 431 -> "Request Header Fields Too Large"
            else -> "Error"
        }
        val sb = StringBuilder()
        sb.append("HTTP/1.1 ").append(code).append(' ').append(status).append("\r\n")
        sb.append("Content-Type: ").append(type).append("\r\n")
        if (length >= 0) sb.append("Content-Length: ").append(length).append("\r\n")
        sb.append("Connection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n")
        sb.append(extra).append("\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun bytes(out: OutputStream, code: Int, type: String, body: ByteArray, extra: String = "") {
        head(out, code, type, body.size.toLong(), extra)
        out.write(body)
    }

    private fun json(out: OutputStream, code: Int, body: String, extra: String = "") =
        bytes(out, code, "application/json; charset=utf-8", body.toByteArray(Charsets.UTF_8), extra)

    private fun jstr(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) when {
            c == '"' -> sb.append("\\\"")
            c == '\\' -> sb.append("\\\\")
            c == '\n' -> sb.append("\\n")
            c == '\r' -> sb.append("\\r")
            c == '\t' -> sb.append("\\t")
            c < ' ' || c == ' ' || c == ' ' -> sb.append("\\u%04x".format(c.code))
            else -> sb.append(c)
        }
        return sb.append('"').toString()
    }

    // ------------------------------------------------------------------ login

    private fun cookie(req: Request, name: String): String? =
        req.headers["cookie"]?.split(";")?.map { it.trim() }?.firstOrNull { it.startsWith("$name=") }?.substringAfter('=')

    private fun loggedIn(req: Request): Boolean {
        if (password.isEmpty()) return true
        val t = cookie(req, "ia_s") ?: return false
        return t in sessions
    }

    private fun sameSecret(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    private fun login(req: Request, inp: InputStream, out: OutputStream) {
        val f = fails.getOrPut(req.ip) { Fails() }
        val now = System.currentTimeMillis()
        if (f.lockedUntil > now) throw HttpError(429, "Too many wrong passwords. Try again in a minute.")
        val len = req.contentLength
        if (len < 0 || len > 512) throw HttpError(400, "Bad request")
        val body = String(readExactly(inp, len.toInt()), Charsets.UTF_8)
        if (password.isNotEmpty() && sameSecret(body, password)) {
            f.count = 0
            val tok = ByteArray(24).also { random.nextBytes(it) }.joinToString("") { "%02x".format(it) }
            sessions.add(tok)
            json(out, 200, "{\"ok\":true}", "Set-Cookie: ia_s=$tok; Path=/; HttpOnly; SameSite=Strict\r\n")
        } else {
            f.count++
            if (f.count >= MAX_FAILS) { f.lockedUntil = now + 60_000L; f.count = 0 }
            try { Thread.sleep(600) } catch (e: InterruptedException) { }
            throw HttpError(401, "Wrong password")
        }
    }

    private fun readExactly(inp: InputStream, n: Int): ByteArray {
        val b = ByteArray(n)
        var o = 0
        while (o < n) {
            val r = inp.read(b, o, n - o)
            if (r < 0) throw IOException("closed")
            o += r
        }
        return b
    }

    // ------------------------------------------------------------------ paths

    /** Resolves a path relative to the shared root; null when it leaves the root or touches the Vault / Recycle Bin. */
    private fun resolve(rel: String?): File? {
        val r = (rel ?: "").trim('/')
        val f = if (r.isEmpty()) rootCanon else File(rootCanon, r)
        val c = try { f.canonicalFile } catch (e: IOException) { return null }
        if (c.path != rootCanon.path && !c.path.startsWith(rootCanon.path + "/")) return null
        if (Vault.isVaultPath(c.path)) return null
        var x: File? = c
        while (x != null && x.path != rootCanon.path) {
            if (isAppFolder(x)) return null
            x = x.parentFile
        }
        return c
    }

    private fun relOf(f: File): String =
        if (f.path == rootCanon.path) "" else f.path.removePrefix(rootCanon.path + "/")

    private fun visible(f: File): Boolean = !isAppFolder(f) && (showHidden || !f.name.startsWith("."))

    private fun cleanName(n: String?): String {
        val t = (n ?: "").trim()
        if (t.isEmpty() || t == "." || t == ".." || t.contains('/') || t.contains('\\') || t.contains('\u0000') || t.length > 200)
            throw HttpError(400, "Invalid name")
        return t
    }

    // ------------------------------------------------------------------ routing

    private fun route(req: Request, inp: InputStream, out: OutputStream) {
        if (req.method != "GET" && req.method != "POST") throw HttpError(405, "Method not allowed")
        if (req.path == "/" || req.path == "/index.html") {
            if (req.method != "GET") throw HttpError(405, "Method not allowed")
            val page = PAGE.replace("@@OWNER@@", Owner.notice).replace("@@LOGIN@@", if (password.isEmpty()) "0" else "1")
            bytes(out, 200, "text/html; charset=utf-8", page.toByteArray(Charsets.UTF_8))
            return
        }
        if (!req.path.startsWith("/api/")) throw HttpError(404, "Not found")
        // Every change needs this header; other websites cannot send it, so they cannot trigger actions in this browser.
        if (req.method == "POST" && req.headers["x-ia"] != "1") throw HttpError(403, "Forbidden")
        if (req.path == "/api/login" && req.method == "POST") return login(req, inp, out)
        if (!loggedIn(req)) throw HttpError(401, "Password needed")
        when (req.path) {
            "/api/list" -> list(req, out)
            "/api/file" -> file(req, out)
            "/api/zip" -> zip(req, out)
            "/api/upload" -> upload(req, inp, out)
            "/api/mkdir" -> mkdir(req, out)
            "/api/rename" -> rename(req, out)
            "/api/delete" -> delete(req, out)
            else -> throw HttpError(404, "Not found")
        }
    }

    private fun needWrite() {
        if (readOnly) throw HttpError(403, "Read-only: turn on \"Allow upload, rename & delete\" in IA Manager")
    }

    private fun dirOrFail(rel: String?): File {
        val d = resolve(rel) ?: throw HttpError(403, "Not allowed")
        if (!d.isDirectory) throw HttpError(404, "Folder not found")
        return d
    }

    private fun list(req: Request, out: OutputStream) {
        val dir = dirOrFail(req.q("p"))
        val kids = (dir.listFiles() ?: throw HttpError(403, "Cannot read this folder")).filter { visible(it) }
            .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
        val sb = StringBuilder()
        sb.append("{\"path\":").append(jstr(relOf(dir))).append(",\"write\":").append(!readOnly).append(",\"items\":[")
        kids.forEachIndexed { i, f ->
            if (i > 0) sb.append(',')
            sb.append("{\"n\":").append(jstr(f.name)).append(",\"d\":").append(f.isDirectory)
                .append(",\"s\":").append(if (f.isDirectory) 0L else f.length()).append(",\"t\":").append(f.lastModified()).append('}')
        }
        sb.append("]}")
        json(out, 200, sb.toString())
    }

    private fun disposition(kind: String, name: String): String {
        val ascii = name.map { if (it.code in 32..126 && it != '"' && it != '\\' && it != '%') it else '_' }.joinToString("")
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        return "Content-Disposition: $kind; filename=\"$ascii\"; filename*=UTF-8''$enc\r\n"
    }

    private fun file(req: Request, out: OutputStream) {
        val f = resolve(req.q("p")) ?: throw HttpError(403, "Not allowed")
        if (!f.isFile) throw HttpError(404, "File not found")
        val mime = mimeOf(f.name)
        // Only content that cannot run scripts is shown inside the browser; everything else is downloaded.
        val inlineOk = req.q("dl") != "1" && (mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/") || mime == "application/pdf" || mime == "text/plain")
        val total = f.length()
        var start = 0L
        var end = total - 1
        var code = 200
        val range = req.headers["range"]
        if (range != null) {
            val m = Regex("bytes=(\\d*)-(\\d*)").matchEntire(range.trim())
            if (m != null && (m.groupValues[1].isNotEmpty() || m.groupValues[2].isNotEmpty())) {
                if (m.groupValues[1].isEmpty()) {
                    start = maxOf(0L, total - m.groupValues[2].toLong())
                } else {
                    start = m.groupValues[1].toLong()
                    if (m.groupValues[2].isNotEmpty()) end = minOf(end, m.groupValues[2].toLong())
                }
                if (start > end || start >= total) {
                    head(out, 416, "text/plain", 0, "Content-Range: bytes */$total\r\n")
                    return
                }
                code = 206
            }
        }
        val type = if (inlineOk) (if (mime == "text/plain") "text/plain; charset=utf-8" else mime) else "application/octet-stream"
        var extra = "Accept-Ranges: bytes\r\n" + disposition(if (inlineOk) "inline" else "attachment", f.name)
        if (code == 206) extra += "Content-Range: bytes $start-$end/$total\r\n"
        if (mime != "application/pdf") extra += "Content-Security-Policy: sandbox\r\n"
        head(out, code, type, if (total == 0L) 0L else end - start + 1, extra)
        if (total == 0L) return
        FileInputStream(f).use { fin ->
            var skip = start
            while (skip > 0) { val k = fin.skip(skip); if (k <= 0) break; skip -= k }
            val buf = ByteArray(64 * 1024)
            var left = end - start + 1
            while (left > 0) {
                val r = fin.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (r < 0) break
                out.write(buf, 0, r)
                left -= r
            }
        }
    }

    private fun zip(req: Request, out: OutputStream) {
        val dir = dirOrFail(req.q("p"))
        val name = (if (dir.path == rootCanon.path) "Files" else dir.name) + ".zip"
        head(out, 200, "application/zip", -1, disposition("attachment", name))
        val z = ZipOutputStream(out)
        z.setLevel(1)
        val buf = ByteArray(64 * 1024)
        fun add(f: File, prefix: String) {
            if (!visible(f) || Vault.isVaultPath(f.path)) return
            if (f.isDirectory) {
                val kids = f.listFiles() ?: return
                if (kids.isEmpty()) { z.putNextEntry(ZipEntry("$prefix${f.name}/")); z.closeEntry() }
                kids.forEach { add(it, "$prefix${f.name}/") }
            } else if (f.isFile) {
                z.putNextEntry(ZipEntry(prefix + f.name))
                try { FileInputStream(f).use { fin -> while (true) { val r = fin.read(buf); if (r < 0) break; z.write(buf, 0, r) } } } catch (e: IOException) { }
                z.closeEntry()
            }
        }
        (dir.listFiles() ?: emptyArray()).forEach { add(it, "") }
        z.finish()
    }

    private fun upload(req: Request, inp: InputStream, out: OutputStream) {
        needWrite()
        val dir = dirOrFail(req.q("p"))
        val name = cleanName(req.q("name"))
        val len = req.contentLength
        if (len < 0) throw HttpError(411, "Length required")
        if (req.headers["expect"]?.contains("100-continue", true) == true) {
            out.write("HTTP/1.1 100 Continue\r\n\r\n".toByteArray()); out.flush()
        }
        val dest = uniqueFile(dir, name)
        val tmp = File(dir, "." + dest.name + ".iapart")
        Ops.registerTmp(tmp)
        var ok = false
        try {
            FileOutputStream(tmp).use { fo ->
                val buf = ByteArray(64 * 1024)
                var left = len
                while (left > 0) {
                    val r = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (r < 0) throw IOException("Upload interrupted")
                    fo.write(buf, 0, r)
                    left -= r
                }
            }
            if (!tmp.renameTo(dest)) throw HttpError(409, "Could not save the file")
            ok = true
        } finally {
            if (!ok) tmp.delete()
            Ops.unregisterTmp(tmp)
        }
        json(out, 200, "{\"ok\":true,\"name\":" + jstr(dest.name) + "}")
    }

    private fun mkdir(req: Request, out: OutputStream) {
        needWrite()
        val dir = dirOrFail(req.q("p"))
        val t = File(dir, cleanName(req.q("name")))
        if (t.exists()) throw HttpError(409, "A file or folder with that name already exists")
        if (!t.mkdir()) throw HttpError(409, "Could not create the folder")
        json(out, 200, "{\"ok\":true}")
    }

    private fun rename(req: Request, out: OutputStream) {
        needWrite()
        val f = resolve(req.q("p")) ?: throw HttpError(403, "Not allowed")
        if (f.path == rootCanon.path || !f.exists()) throw HttpError(404, "Not found")
        val t = File(f.parentFile, cleanName(req.q("name")))
        if (t.exists()) throw HttpError(409, "A file or folder with that name already exists")
        if (!f.renameTo(t)) throw HttpError(409, "Rename failed")
        json(out, 200, "{\"ok\":true}")
    }

    private fun delete(req: Request, out: OutputStream) {
        needWrite()
        val f = resolve(req.q("p")) ?: throw HttpError(403, "Not allowed")
        if (f.path == rootCanon.path || !f.exists()) throw HttpError(404, "Not found")
        try { moveToTrash(f) } catch (e: Exception) { throw HttpError(409, e.message ?: "Could not delete") }
        json(out, 200, "{\"ok\":true}")
    }

    companion object {
        private const val MAX_FAILS = 8

        fun mimeOf(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"
            "bmp" -> "image/bmp"; "svg" -> "image/svg+xml"; "heic" -> "image/heic"
            "mp4", "m4v" -> "video/mp4"; "webm" -> "video/webm"; "mkv" -> "video/x-matroska"; "3gp" -> "video/3gpp"
            "mov" -> "video/quicktime"; "avi" -> "video/x-msvideo"
            "mp3" -> "audio/mpeg"; "m4a", "aac" -> "audio/mp4"; "wav" -> "audio/wav"; "ogg", "oga", "opus" -> "audio/ogg"; "flac" -> "audio/flac"
            "pdf" -> "application/pdf"
            "txt", "log", "md", "csv", "json", "xml" -> "text/plain"
            else -> "application/octet-stream"
        }

        private val PAGE = WEB_PAGE
    }
}
