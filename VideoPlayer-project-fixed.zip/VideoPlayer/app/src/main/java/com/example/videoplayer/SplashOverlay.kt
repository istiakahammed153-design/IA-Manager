package com.example.videoplayer

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** A spinning green ring with a gap, drawn around the app icon. */
private class RingView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#2ECC71")
    }
    private val faint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(40, 255, 255, 255)
    }
    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        val stroke = width * 0.04f
        paint.strokeWidth = stroke
        faint.strokeWidth = stroke
        val pad = stroke
        box.set(pad, pad, width - pad, height - pad)
        canvas.drawOval(box, faint)
        canvas.drawArc(box, -90f, 100f, false, paint)
    }
}

/**
 * Start-up animation shown over the video list. It keeps playing (pulsing icon, turning ring,
 * moving dots) until [hide] is called, which happens once the list is ready.
 */
class SplashOverlay private constructor(private val act: Activity) {

    private val ui = Handler(Looper.getMainLooper())
    private val shownAt = SystemClock.uptimeMillis()
    private val animators = ArrayList<Animator>()
    private var root: FrameLayout? = null
    private var hiding = false

    private val failSafe = Runnable { hide(force = true) }

    companion object {
        private const val MIN_SHOW_MS = 700L
        private const val FAIL_SAFE_MS = 10_000L

        fun show(act: Activity): SplashOverlay {
            val s = SplashOverlay(act)
            s.build()
            return s
        }
    }

    private fun build() {
        val frame = FrameLayout(act)
        frame.setBackgroundColor(Color.parseColor("#0F0F10"))
        frame.isClickable = true // swallow touches while it is on screen

        val column = LinearLayout(act)
        column.orientation = LinearLayout.VERTICAL
        column.gravity = Gravity.CENTER_HORIZONTAL

        val size = act.dp(132)
        val stack = FrameLayout(act)
        val ring = RingView(act)
        stack.addView(ring, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        val icon = ImageView(act)
        icon.setImageResource(R.drawable.ic_launcher)
        val iconSize = act.dp(92)
        stack.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        column.addView(stack, LinearLayout.LayoutParams(size, size))

        val title = TextView(act)
        title.text = act.getString(R.string.app_name)
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.gravity = Gravity.CENTER
        val tlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        tlp.topMargin = act.dp(20)
        column.addView(title, tlp)

        val dots = LinearLayout(act)
        dots.orientation = LinearLayout.HORIZONTAL
        val dotViews = ArrayList<View>()
        for (i in 0 until 3) {
            val d = View(act)
            val bg = android.graphics.drawable.GradientDrawable()
            bg.shape = android.graphics.drawable.GradientDrawable.OVAL
            bg.setColor(Color.parseColor("#2ECC71"))
            d.background = bg
            d.alpha = 0.25f
            val lp = LinearLayout.LayoutParams(act.dp(8), act.dp(8))
            lp.setMargins(act.dp(4), 0, act.dp(4), 0)
            dots.addView(d, lp)
            dotViews.add(d)
        }
        val dlp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dlp.topMargin = act.dp(18)
        column.addView(dots, dlp)

        frame.addView(
            column,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            )
        )

        act.addContentView(
            frame,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        root = frame

        // ring keeps turning
        val spin = ObjectAnimator.ofFloat(ring, View.ROTATION, 0f, 360f)
        spin.duration = 1100
        spin.repeatCount = ValueAnimator.INFINITE
        spin.interpolator = LinearInterpolator()

        // icon breathes
        val sx = ObjectAnimator.ofFloat(icon, View.SCALE_X, 0.92f, 1.06f)
        val sy = ObjectAnimator.ofFloat(icon, View.SCALE_Y, 0.92f, 1.06f)
        for (a in arrayOf(sx, sy)) {
            a.duration = 650
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            a.interpolator = AccelerateDecelerateInterpolator()
        }

        // three dots light up one after another
        val dotAnims = ArrayList<Animator>()
        for ((i, d) in dotViews.withIndex()) {
            val a = ObjectAnimator.ofFloat(d, View.ALPHA, 0.25f, 1f)
            a.duration = 420
            a.startDelay = i * 160L
            a.repeatCount = ValueAnimator.INFINITE
            a.repeatMode = ValueAnimator.REVERSE
            dotAnims.add(a)
        }

        val set = AnimatorSet()
        set.playTogether(listOf<Animator>(spin, sx, sy) + dotAnims)
        set.start()
        animators.add(set)

        // entrance
        column.alpha = 0f
        column.scaleX = 0.9f
        column.scaleY = 0.9f
        column.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).start()

        ui.postDelayed(failSafe, FAIL_SAFE_MS)
    }

    /** Fades the animation out once the app is ready. Safe to call more than once. */
    fun hide(force: Boolean = false) {
        val r = root ?: return
        if (hiding) return
        hiding = true
        ui.removeCallbacks(failSafe)
        val wait = if (force) 0L else maxOf(0L, MIN_SHOW_MS - (SystemClock.uptimeMillis() - shownAt))
        ui.postDelayed({
            if (act.isFinishing || act.isDestroyed) {
                cleanup()
                return@postDelayed
            }
            r.animate().alpha(0f).setDuration(300).setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    cleanup()
                }
            }).start()
        }, wait)
    }

    private fun cleanup() {
        for (a in animators) a.cancel()
        animators.clear()
        val r = root ?: return
        root = null
        (r.parent as? ViewGroup)?.removeView(r)
    }
}
