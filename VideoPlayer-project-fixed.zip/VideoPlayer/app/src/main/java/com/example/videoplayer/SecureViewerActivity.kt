package com.example.videoplayer

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Hands the chosen hidden file from the list to the viewer (kept in memory only). */
object ViewerHolder {
    var item: VideoItem? = null
}

/**
 * Opens hidden pictures, PDFs and text files. Pictures and text are decrypted in memory only. A PDF needs a
 * real file for Android's renderer, so a short-lived copy is made in the app's private cache and is
 * overwritten and deleted when this screen closes. Screenshots are blocked, and leaving the app locks the vault.
 */
class SecureViewerActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var item: VideoItem? = null
    private lateinit var content: FrameLayout
    private lateinit var tvTitle: TextView
    private lateinit var zoomBar: LinearLayout

    // PDF state
    private var tempFile: File? = null
    private var pdfFd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var pageW = IntArray(0)
    private var pageH = IntArray(0)
    private var zoomStep = 0
    private val zooms = floatArrayOf(1f, 1.5f, 2f)
    private var generation = 0
    private val pdfLock = Any()
    private var pool: ExecutorService? = null
    private var pageCache: LruCache<String, Bitmap>? = null
    private var pdfList: ListView? = null
    private var pdfAdapter: BaseAdapter? = null
    @Volatile
    private var closed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val it = ViewerHolder.item
        if (it == null || !Vault.isUnlocked()) {
            finish()
            return
        }
        item = it
        buildUi(it)
        when (fileKind(it.name, it.mime)) {
            KIND_IMAGE -> loadImage(it)
            KIND_PDF -> loadPdf(it)
            else -> loadText(it)
        }
    }

    private fun buildUi(it: VideoItem) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#1C1C1F"))
        bar.setPadding(dp(4), dp(4), dp(8), dp(4))

        val back = ImageButton(this)
        back.setImageResource(R.drawable.ic_back)
        back.setBackgroundResource(android.R.color.transparent)
        back.setPadding(dp(10), dp(10), dp(10), dp(10))
        back.setOnClickListener { finish() }
        bar.addView(back, LinearLayout.LayoutParams(dp(46), dp(46)))

        tvTitle = TextView(this)
        tvTitle.text = it.name
        tvTitle.setTextColor(Color.WHITE)
        tvTitle.textSize = 16f
        tvTitle.isSingleLine = true
        tvTitle.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        bar.addView(tvTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        zoomBar = LinearLayout(this)
        zoomBar.orientation = LinearLayout.HORIZONTAL
        zoomBar.visibility = View.GONE
        zoomBar.addView(zoomButton("\u2212") { changeZoom(-1) })
        zoomBar.addView(zoomButton("+") { changeZoom(1) })
        bar.addView(zoomBar)

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        showBusy()
    }

    private fun zoomButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 22f
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        t.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        return t
    }

    private fun showBusy() {
        content.removeAllViews()
        val p = ProgressBar(this)
        content.addView(p, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))
    }

    private fun showMessage(text: String) {
        content.removeAllViews()
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.parseColor("#DDDDDD"))
        t.gravity = Gravity.CENTER
        t.setPadding(dp(24), dp(24), dp(24), dp(24))
        content.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    // ------------------------------------------------------------------ pictures

    private fun loadImage(it: VideoItem) {
        Thread {
            var bmp: Bitmap? = null
            val key = Vault.sessionKey()
            val id = it.vaultId
            if (key != null && id != null) {
                try {
                    VaultReader.open(Vault.fileFor(this, id), key).use { r ->
                        bmp = VaultImages.decode(r, 3000)
                    }
                } catch (e: Exception) {
                    bmp = null
                } catch (e: OutOfMemoryError) {
                    bmp = null
                } finally {
                    key.fill(0)
                }
            }
            val result = bmp
            runOnUiThread {
                if (closed) return@runOnUiThread
                if (result == null) {
                    showMessage("This picture cannot be shown.")
                } else {
                    content.removeAllViews()
                    val z = ZoomImageView(this)
                    z.setPicture(result)
                    content.addView(z, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ text

    private fun loadText(it: VideoItem) {
        Thread {
            var text: String? = null
            val key = Vault.sessionKey()
            val id = it.vaultId
            if (key != null && id != null) {
                try {
                    VaultReader.open(Vault.fileFor(this, id), key).use { r ->
                        val max = 2 * 1024 * 1024
                        val len = minOf(r.size, max.toLong()).toInt()
                        val buf = ByteArray(len)
                        var got = 0
                        while (got < len) {
                            val n = r.readAt(got.toLong(), buf, got, len - got)
                            if (n < 0) break
                            got += n
                        }
                        text = String(buf, 0, got, Charsets.UTF_8) +
                            (if (r.size > max) "\n\n... (only the first 2 MB are shown)" else "")
                    }
                } catch (e: Exception) {
                    text = null
                } finally {
                    key.fill(0)
                }
            }
            val result = text
            runOnUiThread {
                if (closed) return@runOnUiThread
                if (result == null) {
                    showMessage("This file cannot be shown.")
                } else {
                    content.removeAllViews()
                    val sv = ScrollView(this)
                    val tv = TextView(this)
                    tv.text = result
                    tv.setTextColor(Color.WHITE)
                    tv.textSize = 14f
                    tv.setPadding(dp(16), dp(16), dp(16), dp(16))
                    sv.addView(tv)
                    content.addView(sv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ PDF

    private fun loadPdf(it: VideoItem) {
        Thread {
            var error: String? = null
            try {
                val f = Vault.decryptToTemp(this, it)
                tempFile = f
                if (closed) {
                    Vault.wipe(f)
                    return@Thread
                }
                val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                pdfFd = fd
                val r = PdfRenderer(fd)
                renderer = r
                val w = IntArray(r.pageCount)
                val h = IntArray(r.pageCount)
                for (i in 0 until r.pageCount) {
                    val p = r.openPage(i)
                    w[i] = p.width
                    h[i] = p.height
                    p.close()
                }
                pageW = w
                pageH = h
            } catch (e: SecurityException) {
                error = "Password-protected PDFs cannot be shown."
            } catch (e: Exception) {
                error = "This PDF cannot be shown."
            }
            val err = error
            runOnUiThread {
                if (closed) return@runOnUiThread
                if (err != null || renderer == null) showMessage(err ?: "This PDF cannot be shown.") else showPdf()
            }
        }.start()
    }

    private fun displayWidth(): Int = (resources.displayMetrics.widthPixels * zooms[zoomStep]).toInt()

    private fun showPdf() {
        content.removeAllViews()
        zoomBar.visibility = View.VISIBLE
        pool = Executors.newSingleThreadExecutor()
        pageCache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 4L).toInt()) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }
        val list = ListView(this)
        list.divider = null
        list.setBackgroundColor(Color.parseColor("#333333"))
        val adapter = PdfAdapter()
        list.adapter = adapter
        pdfList = list
        pdfAdapter = adapter
        val hsv = HorizontalScrollView(this)
        hsv.isFillViewport = true
        hsv.addView(list, FrameLayout.LayoutParams(displayWidth(), ViewGroup.LayoutParams.MATCH_PARENT))
        content.addView(hsv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun changeZoom(delta: Int) {
        val list = pdfList ?: return
        val n = (zoomStep + delta).coerceIn(0, zooms.size - 1)
        if (n == zoomStep) return
        zoomStep = n
        generation++
        pageCache?.evictAll()
        val lp = list.layoutParams
        lp.width = displayWidth()
        list.layoutParams = lp
        pdfAdapter?.notifyDataSetChanged()
    }

    private inner class PdfAdapter : BaseAdapter() {
        override fun getCount(): Int = pageW.size
        override fun getItem(position: Int): Any = position
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val iv = (convertView as? ImageView) ?: ImageView(this@SecureViewerActivity).also {
                it.scaleType = ImageView.ScaleType.FIT_XY
                it.setBackgroundColor(Color.WHITE)
            }
            val w = displayWidth()
            val h = (w.toLong() * pageH[position] / maxOf(1, pageW[position])).toInt().coerceAtLeast(1)
            iv.layoutParams = android.widget.AbsListView.LayoutParams(w, h)
            iv.setPadding(0, 0, 0, 0)
            val key = position.toString() + ":" + w
            iv.tag = key + ":" + generation
            val hit = pageCache?.get(key)
            if (hit != null) {
                iv.setImageBitmap(hit)
            } else {
                iv.setImageDrawable(null)
                val gen = generation
                pool?.execute { renderPage(position, w, h, key, gen, iv) }
            }
            return iv
        }
    }

    private fun renderPage(position: Int, w: Int, h: Int, key: String, gen: Int, view: ImageView) {
        if (closed || gen != generation) return
        var bmp: Bitmap? = null
        synchronized(pdfLock) {
            val r = renderer ?: return
            try {
                val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                b.eraseColor(Color.WHITE)
                val page = r.openPage(position)
                try {
                    page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                } finally {
                    page.close()
                }
                bmp = b
            } catch (e: Exception) {
                bmp = null
            } catch (e: OutOfMemoryError) {
                bmp = null
            }
        }
        val done = bmp ?: return
        pageCache?.put(key, done)
        ui.post {
            if (!closed && view.tag == key + ":" + generation) view.setImageBitmap(done)
        }
    }

    // ------------------------------------------------------------------ leaving

    override fun onStop() {
        super.onStop()
        if (!isFinishing) {
            // the app was left: nothing stays open, and the vault locks
            Vault.lock()
            finish()
        }
    }

    override fun onDestroy() {
        closed = true
        pool?.shutdownNow()
        synchronized(pdfLock) {
            try {
                renderer?.close()
            } catch (e: Exception) {
                // ignore
            }
            renderer = null
            try {
                pdfFd?.close()
            } catch (e: Exception) {
                // ignore
            }
            pdfFd = null
        }
        pageCache?.evictAll()
        val f = tempFile
        tempFile = null
        if (f != null) Thread { Vault.wipe(f) }.start()
        if (ViewerHolder.item === item) ViewerHolder.item = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (renderer != null) {
            generation++
            pageCache?.evictAll()
            pdfList?.layoutParams?.let {
                it.width = displayWidth()
                pdfList?.layoutParams = it
            }
            pdfAdapter?.notifyDataSetChanged()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

/** An ImageView with pinch-to-zoom, drag and double-tap zoom. */
private class ZoomImageView(context: Context) : ImageView(context) {
    private val m = Matrix()
    private val v = FloatArray(9)
    private var bw = 0
    private var bh = 0
    private var minScale = 1f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomBy(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scaleDetector.isInProgress) return false
            m.postTranslate(-dx, -dy)
            fix()
            imageMatrix = m
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val cur = scale()
            if (cur > minScale * 1.05f) fit() else zoomBy(3f, e.x, e.y)
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
        setBackgroundColor(Color.BLACK)
    }

    fun setPicture(b: Bitmap) {
        setImageBitmap(b)
        bw = b.width
        bh = b.height
        fit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fit()
    }

    private fun scale(): Float {
        m.getValues(v)
        return v[Matrix.MSCALE_X]
    }

    private fun fit() {
        if (bw == 0 || bh == 0 || width == 0 || height == 0) return
        val s = minOf(width / bw.toFloat(), height / bh.toFloat())
        minScale = s
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - bw * s) / 2f, (height - bh * s) / 2f)
        imageMatrix = m
    }

    private fun zoomBy(factor: Float, fx: Float, fy: Float) {
        val cur = scale()
        if (cur <= 0f) return
        val target = (cur * factor).coerceIn(minScale, minScale * 8f)
        val real = target / cur
        m.postScale(real, real, fx, fy)
        fix()
        imageMatrix = m
    }

    private fun fix() {
        m.getValues(v)
        val s = v[Matrix.MSCALE_X]
        val tx = v[Matrix.MTRANS_X]
        val ty = v[Matrix.MTRANS_Y]
        val w = bw * s
        val h = bh * s
        var dx = 0f
        var dy = 0f
        if (w <= width) {
            dx = (width - w) / 2f - tx
        } else if (tx > 0f) {
            dx = -tx
        } else if (tx + w < width) {
            dx = width - (tx + w)
        }
        if (h <= height) {
            dy = (height - h) / 2f - ty
        } else if (ty > 0f) {
            dy = -ty
        } else if (ty + h < height) {
            dy = height - (ty + h)
        }
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestures.onTouchEvent(event)
        return true
    }
}
