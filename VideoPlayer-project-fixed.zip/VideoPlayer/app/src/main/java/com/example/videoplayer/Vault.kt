package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.InputType
import android.util.Base64
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.security.GeneralSecurityException
import java.security.MessageDigest
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * The private vault. Any kind of file (video, audio, picture, PDF, document ...) can be hidden in it.
 *
 * - Every hidden file is encrypted with AES-256-GCM (see [VaultFormat]); the name, type and size are
 *   encrypted too, and the stored file has a random name.
 * - A random 256-bit master key encrypts everything. The master key itself is stored only in
 *   encrypted form, locked by a key derived from the password (PBKDF2-HMAC-SHA256, 200,000 rounds).
 *   The password is never stored, so without it nobody can read the files, not even with root access.
 * - After unlocking, the master key lives only in memory and is wiped as soon as the vault locks.
 */
object Vault {
    const val SCHEME = "vault"
    private const val KEY_FILE = "vault.key"
    private const val LEGACY_HASH = "vault_hash"
    private const val LEGACY_SALT = "vault_salt"
    private const val ITERATIONS = 200_000
    private const val PREF_FAILS = "vault_fails"
    private const val PREF_LOCK_UNTIL = "vault_lock_until"
    private val ID_PATTERN = Regex("[0-9a-f]{32}")

    @Volatile
    private var master: ByteArray? = null

    // ------------------------------------------------------------------ folders and names

    fun dir(c: Context): File {
        val d = File(c.filesDir, "vault_enc")
        if (!d.exists()) d.mkdirs()
        return d
    }

    private fun legacyDir(c: Context): File = File(c.filesDir, "vault")

    private fun keyFile(c: Context): File = File(dir(c), KEY_FILE)

    fun isValidId(id: String): Boolean = ID_PATTERN.matches(id)

    private fun newId(): String {
        val b = VaultCrypto.randomBytes(16)
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02x", x.toInt() and 0xFF))
        return sb.toString()
    }

    fun fileFor(c: Context, id: String): File = File(dir(c), id + VaultFormat.EXT)

    fun uriFor(id: String, name: String): Uri =
        Uri.Builder().scheme(SCHEME).authority("f").appendPath(id).appendPath(name.ifBlank { "file" }).build()

    // ------------------------------------------------------------------ session (unlocked state)

    fun isUnlocked(): Boolean = master != null

    /** A private copy of the master key for a long-running job such as playback, or null if locked. */
    fun sessionKey(): ByteArray? = master?.copyOf()

    fun lock() {
        val m = master
        master = null
        m?.fill(0)
    }

    fun hasPassword(c: Context): Boolean =
        keyFile(c).exists() || Prefs.getStr(c, LEGACY_HASH, "").isNotEmpty()

    // ------------------------------------------------------------------ wrong-password delay

    fun lockoutMs(c: Context): Long {
        val until = Prefs.getStr(c, PREF_LOCK_UNTIL, "0").toLongOrNull() ?: 0L
        return maxOf(0L, until - System.currentTimeMillis())
    }

    private fun failed(c: Context) {
        val n = Prefs.getInt(c, PREF_FAILS, 0) + 1
        Prefs.putInt(c, PREF_FAILS, n)
        if (n >= 5) {
            val steps = minOf(n - 5, 5)
            val wait = 30_000L shl steps // 30 s, 1 min, 2 min ... up to 16 min
            Prefs.putStr(c, PREF_LOCK_UNTIL, (System.currentTimeMillis() + wait).toString())
        }
    }

    private fun succeeded(c: Context) {
        Prefs.putInt(c, PREF_FAILS, 0)
        Prefs.putStr(c, PREF_LOCK_UNTIL, "0")
    }

    // ------------------------------------------------------------------ password and master key

    private fun wrapMaster(mk: ByteArray, password: String): ByteArray {
        val salt = VaultCrypto.randomBytes(16)
        val iv = VaultCrypto.randomBytes(12)
        val head = ByteArrayOutputStream()
        head.write(byteArrayOf('I'.code.toByte(), 'A'.code.toByte(), 'V'.code.toByte(), 'K'.code.toByte()))
        head.write(1)
        head.write(
            byteArrayOf(
                (ITERATIONS ushr 24).toByte(), (ITERATIONS ushr 16).toByte(),
                (ITERATIONS ushr 8).toByte(), ITERATIONS.toByte()
            )
        )
        head.write(salt)
        val headBytes = head.toByteArray()
        val kek = VaultCrypto.pbkdf2(password.toByteArray(Charsets.UTF_8), salt, ITERATIONS, 32)
        try {
            val c = VaultCrypto.newCipher()
            c.init(javax.crypto.Cipher.ENCRYPT_MODE, SecretKeySpec(kek, "AES"), GCMParameterSpec(128, iv))
            c.updateAAD(headBytes)
            return headBytes + iv + c.doFinal(mk)
        } finally {
            kek.fill(0)
        }
    }

    /** Returns the master key, or null if the password is wrong. */
    private fun unwrapMaster(data: ByteArray, password: String): ByteArray? {
        val headLen = 4 + 1 + 4 + 16
        if (data.size < headLen + 12 + 48) return null
        val magic = byteArrayOf('I'.code.toByte(), 'A'.code.toByte(), 'V'.code.toByte(), 'K'.code.toByte())
        for (i in 0 until 4) if (data[i] != magic[i]) return null
        if (data[4].toInt() != 1) return null
        val iterations = ((data[5].toInt() and 0xFF) shl 24) or ((data[6].toInt() and 0xFF) shl 16) or
            ((data[7].toInt() and 0xFF) shl 8) or (data[8].toInt() and 0xFF)
        if (iterations < 1000 || iterations > 10_000_000) return null
        val salt = data.copyOfRange(9, 25)
        val iv = data.copyOfRange(headLen, headLen + 12)
        val enc = data.copyOfRange(headLen + 12, data.size)
        val kek = VaultCrypto.pbkdf2(password.toByteArray(Charsets.UTF_8), salt, iterations, 32)
        return try {
            val c = VaultCrypto.newCipher()
            c.init(javax.crypto.Cipher.DECRYPT_MODE, SecretKeySpec(kek, "AES"), GCMParameterSpec(128, iv))
            c.updateAAD(data.copyOfRange(0, headLen))
            c.doFinal(enc)
        } catch (e: GeneralSecurityException) {
            null
        } finally {
            kek.fill(0)
        }
    }

    private fun writeKeyFile(c: Context, bytes: ByteArray) {
        val f = keyFile(c)
        val tmp = File(f.parentFile, KEY_FILE + ".tmp")
        FileOutputStream(tmp).use {
            it.write(bytes)
            it.fd.sync()
        }
        if (!tmp.renameTo(f)) {
            tmp.delete()
            throw IOException("Could not save the vault key")
        }
    }

    private fun clearLegacyPassword(c: Context) {
        Prefs.remove(c, LEGACY_HASH)
        Prefs.remove(c, LEGACY_SALT)
    }

    /** Slow (about a second): call from a background thread. Creates a brand-new vault key. */
    fun create(c: Context, password: String): Boolean {
        return try {
            val mk = VaultCrypto.randomBytes(32)
            writeKeyFile(c, wrapMaster(mk, password))
            master = mk
            succeeded(c)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Slow (about a second): call from a background thread. Also upgrades an old (unencrypted) vault. */
    fun unlock(c: Context, password: String): Boolean {
        if (lockoutMs(c) > 0) return false
        val kf = keyFile(c)
        var ok = false
        if (kf.exists()) {
            val mk = try {
                unwrapMaster(kf.readBytes(), password)
            } catch (e: Exception) {
                null
            }
            if (mk != null) {
                master = mk
                ok = true
                clearLegacyPassword(c)
            }
        } else if (Prefs.getStr(c, LEGACY_HASH, "").isNotEmpty()) {
            ok = legacyCheck(c, password) && create(c, password)
            if (ok) clearLegacyPassword(c)
        }
        if (ok) succeeded(c) else failed(c)
        return ok
    }

    /** Re-locks the master key with a new password. The hidden files themselves are not touched. */
    fun change(c: Context, oldPassword: String, newPassword: String): Boolean {
        if (!unlock(c, oldPassword)) return false
        val mk = master ?: return false
        return try {
            writeKeyFile(c, wrapMaster(mk, newPassword))
            true
        } catch (e: Exception) {
            false
        }
    }

    // the password check of the previous (unencrypted) vault, kept only to upgrade it
    private fun legacyCheck(c: Context, pw: String): Boolean {
        val stored = Prefs.getStr(c, LEGACY_HASH, "")
        val saltText = Prefs.getStr(c, LEGACY_SALT, "")
        if (stored.isEmpty() || saltText.isEmpty()) return false
        return try {
            val salt = Base64.decode(saltText, Base64.NO_WRAP)
            val spec = PBEKeySpec(pw.toCharArray(), salt, 20000, 256)
            val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            val h = Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
            MessageDigest.isEqual(h.toByteArray(), stored.toByteArray())
        } catch (e: Exception) {
            false
        }
    }

    // ------------------------------------------------------------------ listing

    private fun toItem(id: String, f: File, info: VaultFileInfo): VideoItem =
        VideoItem(
            uriFor(id, info.name), info.name, info.durationMs, info.size, f.absolutePath,
            info.addedSec, info.width, info.height, false, true,
            fileKind(info.name, info.mime) == KIND_AUDIO, id, info.mime
        )

    /** Reads the (encrypted) headers of all hidden files. Call from a background thread. */
    fun list(c: Context): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val mk = master ?: return out
        val files = dir(c).listFiles() ?: return out
        val now = System.currentTimeMillis()
        for (f in files) {
            if (!f.isFile) continue
            val n = f.name
            if (n.endsWith(".tmp")) {
                // leftovers of an interrupted copy
                if (now - f.lastModified() > 6 * 3600_000L) f.delete()
                continue
            }
            if (!n.endsWith(VaultFormat.EXT)) continue
            val id = n.removeSuffix(VaultFormat.EXT)
            if (!isValidId(id)) continue
            try {
                RandomAccessFile(f, "r").use { raf ->
                    out.add(toItem(id, f, VaultCrypto.readInfo(raf, mk).second))
                }
            } catch (e: Exception) {
                // damaged or foreign file: leave it alone, just do not list it
            }
        }
        return out
    }

    // ------------------------------------------------------------------ hide (encrypt)

    fun guessMime(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun cleanName(name: String): String =
        name.replace(Regex("[\\\\/]"), "_").trim().ifEmpty { "file" }

    /** Encrypts everything [input] delivers into a new vault file. Call from a background thread. */
    fun importStream(
        c: Context,
        input: InputStream,
        name: String,
        mime: String,
        durationMs: Long,
        width: Int,
        height: Int,
        progress: (Long) -> Unit
    ): VideoItem {
        val mk = master?.copyOf() ?: throw IOException("The vault is locked")
        try {
            val id = newId()
            val dest = fileFor(c, id)
            val safeName = cleanName(name)
            val info = VaultCrypto.encrypt(mk, input, dest, safeName, mime, durationMs, width, height, progress)
            return toItem(id, dest, info)
        } finally {
            mk.fill(0)
        }
    }

    private class Probe(val durationMs: Long, val width: Int, val height: Int)

    private fun probe(setSource: (MediaMetadataRetriever) -> Unit): Probe {
        val r = MediaMetadataRetriever()
        try {
            setSource(r)
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            return Probe(d, w, h)
        } catch (e: Exception) {
            return Probe(0L, 0, 0)
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    /**
     * Hides one file picked by the user (or taken from the video list). Video and audio length and size are
     * read first so the list can show them without opening the encrypted file again.
     */
    fun importUri(
        c: Context,
        uri: Uri,
        name: String,
        knownDurationMs: Long = 0L,
        knownWidth: Int = 0,
        knownHeight: Int = 0,
        progress: (Long) -> Unit = {}
    ): VideoItem {
        val mime = c.contentResolver.getType(uri) ?: guessMime(name)
        val kind = fileKind(name, mime)
        var dur = knownDurationMs
        var w = knownWidth
        var h = knownHeight
        if ((kind == KIND_VIDEO || kind == KIND_AUDIO) && dur <= 0L) {
            val p = probe { it.setDataSource(c, uri) }
            dur = p.durationMs
            w = p.width
            h = p.height
        }
        val input = c.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open the file")
        return input.use { importStream(c, it, name, mime, dur, w, h, progress) }
    }

    // ------------------------------------------------------------------ unhide (decrypt), rename, delete

    /** Writes the decrypted content of a hidden file to [out]. Call from a background thread. */
    fun exportTo(c: Context, item: VideoItem, out: OutputStream, progress: (Long) -> Unit = {}) {
        val mk = master?.copyOf() ?: throw IOException("The vault is locked")
        val id = item.vaultId ?: throw IOException("Not a hidden file")
        try {
            VaultReader.open(fileFor(c, id), mk).use { r ->
                val buf = ByteArray(VaultFormat.CHUNK)
                var pos = 0L
                while (true) {
                    val n = r.readAt(pos, buf, 0, buf.size)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    pos += n
                    progress(pos)
                }
            }
        } finally {
            mk.fill(0)
        }
    }

    fun rename(c: Context, item: VideoItem, newName: String): VideoItem? {
        val mk = master?.copyOf() ?: return null
        val id = item.vaultId ?: return null
        val clean = cleanName(newName)
        return try {
            VaultCrypto.updateHeader(mk, fileFor(c, id)) {
                VaultFileInfo(clean, it.mime, it.size, it.durationMs, it.width, it.height, it.addedSec)
            }
            item.copy(uri = uriFor(id, clean), name = clean)
        } catch (e: Exception) {
            null
        } finally {
            mk.fill(0)
        }
    }

    fun delete(c: Context, item: VideoItem): Boolean {
        val id = item.vaultId ?: return false
        if (!isValidId(id)) return false
        return fileFor(c, id).delete()
    }

    // ------------------------------------------------------------------ short-lived plain copy (PDF viewer only)

    private fun tempDir(c: Context): File {
        val d = File(c.cacheDir, "vault_tmp")
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** The PDF renderer of Android needs a real file. It is overwritten and deleted as soon as the viewer closes. */
    fun decryptToTemp(c: Context, item: VideoItem): File {
        val f = File(tempDir(c), newId() + ".tmp")
        try {
            FileOutputStream(f).use { exportTo(c, item, it) }
        } catch (e: Exception) {
            wipe(f)
            throw e
        }
        return f
    }

    fun wipe(f: File) {
        try {
            if (f.exists()) {
                RandomAccessFile(f, "rw").use { raf ->
                    val zeros = ByteArray(64 * 1024)
                    var left = raf.length()
                    raf.seek(0)
                    while (left > 0) {
                        val n = minOf(left, zeros.size.toLong()).toInt()
                        raf.write(zeros, 0, n)
                        left -= n
                    }
                    try {
                        raf.fd.sync()
                    } catch (e: Exception) {
                        // best effort
                    }
                }
            }
        } catch (e: Exception) {
            // best effort
        }
        f.delete()
    }

    fun wipeTemp(c: Context) {
        val files = tempDir(c).listFiles() ?: return
        for (f in files) wipe(f)
    }

    // ------------------------------------------------------------------ upgrade from the old, unencrypted vault

    fun legacyFiles(c: Context): List<File> {
        val files = legacyDir(c).listFiles() ?: return emptyList()
        return files.filter { it.isFile }
    }

    /** Encrypts every file of the old vault folder, then deletes the plain copy. Returns how many failed. */
    fun migrateLegacy(c: Context, progress: (index: Int, total: Int) -> Unit): Int {
        val files = legacyFiles(c)
        var failed = 0
        for ((i, f) in files.withIndex()) {
            progress(i, files.size)
            try {
                val mime = guessMime(f.name)
                var dur = 0L
                var w = 0
                var h = 0
                val kind = fileKind(f.name, mime)
                if (kind == KIND_VIDEO || kind == KIND_AUDIO) {
                    val p = probe { it.setDataSource(f.absolutePath) }
                    dur = p.durationMs
                    w = p.width
                    h = p.height
                }
                FileInputStream(f).use { importStream(c, it, f.name, mime, dur, w, h) {} }
                f.delete()
            } catch (e: Exception) {
                failed++
            }
        }
        if (failed == 0) legacyDir(c).delete()
        return failed
    }
}

/** Password dialogs for the vault. */
object VaultUi {

    private fun field(act: Activity, hint: String): EditText {
        val e = EditText(act)
        e.hint = hint
        e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        e.setSingleLine()
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#CCCCCC"))
        return e
    }

    private fun box(act: Activity): LinearLayout {
        val b = LinearLayout(act)
        b.orientation = LinearLayout.VERTICAL
        b.setPadding(act.dp(22), act.dp(8), act.dp(22), act.dp(4))
        return b
    }

    private fun note(act: Activity, text: String): TextView {
        val t = TextView(act)
        t.text = text
        t.setTextColor(Color.parseColor("#F0F0F0"))
        t.textSize = 13f
        t.setPadding(0, 0, 0, act.dp(8))
        return t
    }

    private fun toast(act: Activity, s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    private fun safeDismiss(d: AlertDialog) {
        try {
            d.dismiss()
        } catch (e: Exception) {
            // the screen may already be gone
        }
    }

    private const val MIN_LENGTH = 6

    /** Runs [onReady] once the vault is open: asks for a new password, or for the existing one, if needed. */
    fun ensureUnlocked(act: Activity, onReady: () -> Unit) {
        when {
            !Vault.hasPassword(act) -> create(act, onReady)
            Vault.isUnlocked() -> onReady()
            else -> unlock(act, onReady)
        }
    }

    fun create(act: Activity, onDone: () -> Unit) {
        val b = box(act)
        b.addView(
            note(
                act,
                "Hidden files are encrypted with AES-256 and can only be opened with this password. " +
                    "Nobody can read them without it.\n\n" +
                    "If you forget the password the files cannot be recovered, and uninstalling the app " +
                    "deletes them."
            )
        )
        val p1 = field(act, "Password (at least $MIN_LENGTH characters)")
        val p2 = field(act, "Confirm password")
        b.addView(p1)
        b.addView(p2)
        val d = AlertDialog.Builder(act)
            .setTitle("Create vault password")
            .setView(b)
            .setPositiveButton("Create", null)
            .setNegativeButton("Cancel", null)
            .show()
        val btn = d.getButton(DialogInterface.BUTTON_POSITIVE)
        btn.setOnClickListener {
            val a = p1.text.toString()
            val c = p2.text.toString()
            if (a.length < MIN_LENGTH) {
                toast(act, "Use at least $MIN_LENGTH characters")
            } else if (a != c) {
                toast(act, "Passwords do not match")
            } else {
                btn.isEnabled = false
                Thread {
                    val ok = Vault.create(act, a)
                    act.runOnUiThread {
                        if (ok) {
                            safeDismiss(d)
                            onDone()
                        } else {
                            btn.isEnabled = true
                            toast(act, "Could not create the vault")
                        }
                    }
                }.start()
            }
        }
    }

    fun unlock(act: Activity, onSuccess: () -> Unit) {
        val b = box(act)
        val p = field(act, "Password")
        b.addView(p)
        val d = AlertDialog.Builder(act)
            .setTitle("Hidden files")
            .setView(b)
            .setPositiveButton("Unlock", null)
            .setNegativeButton("Cancel", null)
            .show()
        val btn = d.getButton(DialogInterface.BUTTON_POSITIVE)
        btn.setOnClickListener {
            val wait = Vault.lockoutMs(act)
            if (wait > 0) {
                toast(act, "Too many wrong attempts. Try again in " + ((wait + 999) / 1000) + " s")
            } else {
                val pw = p.text.toString()
                btn.isEnabled = false
                Thread {
                    val ok = Vault.unlock(act, pw)
                    act.runOnUiThread {
                        if (ok) {
                            safeDismiss(d)
                            upgradeOldVault(act, onSuccess)
                        } else {
                            btn.isEnabled = true
                            toast(act, "Wrong password")
                            p.setText("")
                        }
                    }
                }.start()
            }
        }
    }

    /** Files hidden by the older version were not encrypted. They are encrypted now, once, after unlocking. */
    private fun upgradeOldVault(act: Activity, onDone: () -> Unit) {
        if (Vault.legacyFiles(act).isEmpty()) {
            onDone()
            return
        }
        val row = LinearLayout(act)
        row.gravity = android.view.Gravity.CENTER
        row.setPadding(act.dp(24), act.dp(16), act.dp(24), act.dp(16))
        row.addView(ProgressBar(act))
        val dlg = AlertDialog.Builder(act)
            .setTitle("Encrypting your hidden files...")
            .setView(row)
            .setCancelable(false)
            .show()
        Thread {
            val failed = Vault.migrateLegacy(act) { i, total ->
                act.runOnUiThread { dlg.setTitle("Encrypting your hidden files... " + (i + 1) + "/" + total) }
            }
            act.runOnUiThread {
                safeDismiss(dlg)
                if (failed > 0) {
                    toast(act, "$failed file(s) could not be encrypted and were left in place")
                }
                onDone()
            }
        }.start()
    }

    fun change(act: Activity) {
        val b = box(act)
        val old = field(act, "Current password")
        val n1 = field(act, "New password (at least $MIN_LENGTH characters)")
        val n2 = field(act, "Confirm new password")
        b.addView(old)
        b.addView(n1)
        b.addView(n2)
        val d = AlertDialog.Builder(act)
            .setTitle("Change vault password")
            .setView(b)
            .setPositiveButton("Change", null)
            .setNegativeButton("Cancel", null)
            .show()
        val btn = d.getButton(DialogInterface.BUTTON_POSITIVE)
        btn.setOnClickListener {
            val a = n1.text.toString()
            val wait = Vault.lockoutMs(act)
            if (wait > 0) {
                toast(act, "Too many wrong attempts. Try again in " + ((wait + 999) / 1000) + " s")
            } else if (a.length < MIN_LENGTH) {
                toast(act, "Use at least $MIN_LENGTH characters")
            } else if (a != n2.text.toString()) {
                toast(act, "Passwords do not match")
            } else {
                val current = old.text.toString()
                btn.isEnabled = false
                Thread {
                    val ok = Vault.change(act, current, a)
                    act.runOnUiThread {
                        if (ok) {
                            safeDismiss(d)
                            toast(act, "Password changed")
                            upgradeOldVault(act) {}
                        } else {
                            btn.isEnabled = true
                            toast(act, "Current password is wrong")
                        }
                    }
                }.start()
            }
        }
    }
}
