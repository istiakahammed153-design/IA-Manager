package com.example.videoplayer

import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.view.Gravity
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * File operations shared by the video list and the player: rename, delete, share, details,
 * hide into the private vault and restore from it. Android 10+ asks the user to confirm changes to
 * files owned by other apps, so those calls finish in [onActivityResult].
 */
class MediaActions(private val act: Activity) {

    interface Listener {
        fun onPlay(item: VideoItem) {}
        fun onDeleted(item: VideoItem) {}
        fun onRenamed(old: VideoItem, updated: VideoItem) {}
        fun onHiddenChanged(item: VideoItem) {}
        fun onFavoriteChanged(item: VideoItem) {}
        fun onVaultChanged() {}
    }

    companion object {
        const val REQ_DELETE = 9101
        const val REQ_WRITE = 9102
    }

    private val ui = Handler(Looper.getMainLooper())

    private var pendingDelete: VideoItem? = null
    private var deleteDone: ((Boolean) -> Unit)? = null
    private var pendingRenameItem: VideoItem? = null
    private var pendingRenameName: String = ""
    private var renameDone: ((VideoItem?) -> Unit)? = null

    private fun toast(s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ long-press menu

    fun showMenu(item: VideoItem, showPlay: Boolean, listener: Listener) {
        val labels = ArrayList<String>()
        val runs = ArrayList<() -> Unit>()
        fun add(label: String, run: () -> Unit) {
            labels.add(label)
            runs.add(run)
        }

        if (showPlay) add(if (item.isVault) "Open" else "Play") { listener.onPlay(item) }
        add("Rename") { promptRename(item, listener) }
        add("Delete") { confirmDelete(item, listener) }
        if (!item.isVault) {
            add("Share") { share(item) }
            val id = item.prefKey
            val fav = Prefs.isFavorite(act, id)
            add(if (fav) "Remove from favorites" else "Add to favorites") {
                Prefs.toggleFavorite(act, id)
                listener.onFavoriteChanged(item)
            }
            add("Hide (password protected)") { startHide(item, listener) }
        } else {
            add("Unhide (decrypt and restore)") { startUnhide(item, listener) }
        }
        add("Details") { showDetails(item) }

        AlertDialog.Builder(act)
            .setTitle(item.name)
            .setItems(labels.toTypedArray()) { _, which -> runs[which]() }
            .show()
    }

    // ------------------------------------------------------------------ delete

    private fun confirmDelete(item: VideoItem, listener: Listener) {
        AlertDialog.Builder(act)
            .setTitle("Delete this file?")
            .setMessage(item.name + "\n\nThis cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                delete(item) { ok ->
                    if (ok) {
                        Prefs.forget(act, item.prefKey)
                        listener.onDeleted(item)
                        toast("Deleted")
                    } else {
                        toast("Could not delete this file")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun delete(item: VideoItem, done: (Boolean) -> Unit) {
        if (item.isVault) {
            done(Vault.delete(act, item))
            return
        }
        val uri = item.uri
        if (uri.authority != MediaStore.AUTHORITY) {
            val ok = try {
                DocumentsContract.deleteDocument(act.contentResolver, uri)
            } catch (e: Exception) {
                false
            }
            done(ok)
            return
        }
        deleteDone = done
        pendingDelete = item
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(act.contentResolver, listOf(uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } else {
                val rows = act.contentResolver.delete(uri, null, null)
                finishDelete(rows > 0)
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_DELETE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishDelete(false)
                }
            } else {
                finishDelete(false)
            }
        } catch (e: Exception) {
            finishDelete(false)
        }
    }

    private fun finishDelete(ok: Boolean) {
        val cb = deleteDone
        deleteDone = null
        pendingDelete = null
        cb?.invoke(ok)
    }

    // ------------------------------------------------------------------ rename

    private fun sanitize(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        return cleaned
    }

    private fun promptRename(item: VideoItem, listener: Listener) {
        val dot = item.name.lastIndexOf('.')
        val ext = if (dot > 0) item.name.substring(dot) else ""
        val base = if (dot > 0) item.name.substring(0, dot) else item.name

        val input = EditText(act)
        input.setText(base)
        input.setSingleLine()
        input.setSelectAllOnFocus(true)
        val box = LinearLayout(act)
        box.setPadding(act.dp(22), act.dp(8), act.dp(22), act.dp(4))
        box.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        AlertDialog.Builder(act)
            .setTitle("Rename")
            .setView(box)
            .setPositiveButton("Rename") { _, _ ->
                val nn = sanitize(input.text.toString())
                if (nn.isEmpty()) {
                    toast("Name cannot be empty")
                } else {
                    rename(item, nn + ext) { updated ->
                        if (updated != null) {
                            listener.onRenamed(item, updated)
                            toast("Renamed")
                        } else {
                            toast("Could not rename this file")
                        }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun rename(item: VideoItem, newName: String, done: (VideoItem?) -> Unit) {
        if (item.isVault) {
            // only the encrypted name inside the file changes; the stored file keeps its random name
            done(Vault.rename(act, item, newName))
            return
        }
        if (item.uri.authority != MediaStore.AUTHORITY) {
            val nu = try {
                DocumentsContract.renameDocument(act.contentResolver, item.uri, newName)
            } catch (e: Exception) {
                null
            }
            done(if (nu != null) item.copy(uri = nu, name = newName) else null)
            return
        }
        renameDone = done
        pendingRenameItem = item
        pendingRenameName = newName
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createWriteRequest(act.contentResolver, listOf(item.uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_WRITE, null, 0, 0, 0)
            } else {
                finishRename(doRename())
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishRename(false)
                }
            } else {
                finishRename(false)
            }
        } catch (e: Exception) {
            finishRename(false)
        }
    }

    private fun doRename(): Boolean {
        val item = pendingRenameItem ?: return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingRenameName)
            act.contentResolver.update(item.uri, v, null, null) > 0
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                    // finishRename() will be called from onActivityResult
                    pendingRetryRename = true
                } catch (x: Exception) {
                    // give up
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }

    private var pendingRetryRename = false

    private fun finishRename(ok: Boolean) {
        if (pendingRetryRename && !ok) {
            // a permission prompt is on screen; the result arrives in onActivityResult
            return
        }
        val item = pendingRenameItem
        val cb = renameDone
        val name = pendingRenameName
        pendingRenameItem = null
        renameDone = null
        pendingRetryRename = false
        if (item == null || cb == null) return
        cb(if (ok) item.copy(name = name) else null)
    }

    // ------------------------------------------------------------------ activity results

    /** Forward Activity.onActivityResult here. Returns true if the result belonged to us. */
    fun onActivityResult(requestCode: Int, resultCode: Int): Boolean {
        if (requestCode == REQ_DELETE) {
            if (resultCode == Activity.RESULT_OK && Build.VERSION.SDK_INT == 29) {
                val ok = try {
                    val u = pendingDelete?.uri
                    u != null && act.contentResolver.delete(u, null, null) > 0
                } catch (e: Exception) {
                    false
                }
                finishDelete(ok)
            } else {
                finishDelete(resultCode == Activity.RESULT_OK)
            }
            return true
        }
        if (requestCode == REQ_WRITE) {
            // the user answered the permission prompt; stop waiting and try (or give up)
            pendingRetryRename = false
            if (resultCode == Activity.RESULT_OK) {
                finishRename(doRename())
            } else {
                finishRename(false)
            }
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ share and details

    fun share(item: VideoItem) {
        if (item.uri.scheme != "content") {
            toast("Unhide the file first to share it")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
        send.type = if (item.isAudio) "audio/*" else "video/*"
        send.putExtra(Intent.EXTRA_STREAM, item.uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.startActivity(Intent.createChooser(send, "Share"))
    }

    fun showDetails(item: VideoItem) {
        val sb = StringBuilder()
        sb.append("Name: ").append(item.name).append('\n')
        if (item.isVault) {
            sb.append("Location: private vault (encrypted)\n")
            sb.append("Type: ").append(kindLabel(fileKind(item.name, item.mime))).append('\n')
        } else if (!item.path.isNullOrEmpty()) {
            sb.append("Path: ").append(item.path).append('\n')
            sb.append("Storage: ").append(if (item.isSdCard) "SD card" else "Internal").append('\n')
        }
        if (item.sizeBytes > 0) sb.append("Size: ").append(formatSize(item.sizeBytes)).append('\n')
        if (item.durationMs > 0) sb.append("Duration: ").append(formatTime(item.durationMs)).append('\n')
        if (item.width > 0 && item.height > 0) {
            sb.append("Resolution: ").append(item.width).append(" x ").append(item.height).append('\n')
        }
        if (item.dateAdded > 0) {
            sb.append("Added: ")
                .append(DateFormat.getDateTimeInstance().format(Date(item.dateAdded * 1000)))
                .append('\n')
        }
        AlertDialog.Builder(act)
            .setTitle("Details")
            .setMessage(sb.toString().trim())
            .setPositiveButton("OK", null)
            .show()
    }

    // ------------------------------------------------------------------ vault: hide / unhide

    private fun busy(title: String): AlertDialog {
        val box = LinearLayout(act)
        box.gravity = Gravity.CENTER
        box.setPadding(act.dp(24), act.dp(16), act.dp(24), act.dp(16))
        box.addView(ProgressBar(act))
        return AlertDialog.Builder(act).setTitle(title).setView(box).setCancelable(false).show()
    }

    private fun startHide(item: VideoItem, listener: Listener) {
        // hiding needs the password, because the file is encrypted with the vault key
        VaultUi.ensureUnlocked(act) {
            AlertDialog.Builder(act)
                .setTitle("Hide file")
                .setMessage(
                    "Encrypt \"" + item.name + "\" and move it into the private vault?\n\n" +
                        "It will disappear from the gallery and file managers and can only be opened " +
                        "from the Hidden tab with your password. Android may ask you to confirm " +
                        "removing the original file."
                )
                .setPositiveButton("Hide") { _, _ -> doHide(item, listener) }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun dismissQuietly(d: AlertDialog) {
        try {
            d.dismiss()
        } catch (e: Exception) {
            // the screen may already be gone
        }
    }

    private fun doHide(item: VideoItem, listener: Listener) {
        val dlg = busy("Encrypting...")
        Thread {
            var hidden: VideoItem? = null
            try {
                val total = if (item.sizeBytes > 0) item.sizeBytes else 1L
                var lastPct = -1
                hidden = Vault.importUri(act, item.uri, item.name, item.durationMs, item.width, item.height) { done ->
                    val pct = (done * 100 / total).toInt().coerceAtMost(100)
                    if (pct != lastPct) {
                        lastPct = pct
                        ui.post { dlg.setTitle("Encrypting... $pct%") }
                    }
                }
            } catch (e: Exception) {
                hidden = null
            }
            val copy = hidden
            ui.post {
                dismissQuietly(dlg)
                if (copy == null) {
                    toast("Could not hide this file")
                } else {
                    delete(item) { ok ->
                        if (ok) {
                            Prefs.forget(act, item.prefKey)
                            listener.onHiddenChanged(item)
                            toast("File hidden")
                        } else {
                            Vault.delete(act, copy)
                            toast("Cancelled. The file was not hidden.")
                        }
                    }
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ vault: hide any file picked from storage

    private fun querySize(uri: Uri): Long {
        try {
            act.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (e: Exception) {
            // unknown size
        }
        return 0L
    }

    /** Encrypts files chosen with the file picker (pictures, PDFs, documents, anything). */
    fun hidePicked(uris: List<Uri>, listener: Listener) {
        if (uris.isEmpty()) return
        VaultUi.ensureUnlocked(act) { encryptPicked(uris, listener) }
    }

    private fun encryptPicked(uris: List<Uri>, listener: Listener) {
        val dlg = busy("Encrypting...")
        Thread {
            val done = ArrayList<Uri>()
            for ((i, u) in uris.withIndex()) {
                val label = if (uris.size > 1) "Encrypting " + (i + 1) + "/" + uris.size + "..." else "Encrypting..."
                ui.post { dlg.setTitle(label) }
                try {
                    val name = queryName(act, u)
                    val total = querySize(u)
                    var lastPct = -1
                    Vault.importUri(act, u, name) { bytes ->
                        if (total > 0) {
                            val pct = (bytes * 100 / total).toInt().coerceAtMost(100)
                            if (pct != lastPct) {
                                lastPct = pct
                                ui.post { dlg.setTitle("$label $pct%") }
                            }
                        }
                    }
                    done.add(u)
                } catch (e: Exception) {
                    // this one is skipped; the rest continue
                }
            }
            ui.post {
                dismissQuietly(dlg)
                listener.onVaultChanged()
                if (done.isEmpty()) {
                    toast("Could not hide the selected files")
                } else {
                    askDeleteOriginals(done, uris.size - done.size)
                }
            }
        }.start()
    }

    private fun askDeleteOriginals(hidden: List<Uri>, failed: Int) {
        val msg = StringBuilder()
        msg.append(hidden.size).append(if (hidden.size == 1) " file is" else " files are")
        msg.append(" now encrypted in the vault.")
        if (failed > 0) msg.append("\n\n").append(failed).append(" could not be hidden and were left untouched.")
        msg.append("\n\nDelete the original")
        msg.append(if (hidden.size == 1) " file" else " files")
        msg.append(" from your storage? Otherwise anyone can still open them.")
        AlertDialog.Builder(act)
            .setTitle("Hidden")
            .setMessage(msg.toString())
            .setPositiveButton("Delete originals") { _, _ -> deleteOriginals(hidden) }
            .setNegativeButton("Keep originals", null)
            .show()
    }

    private fun deleteOriginals(uris: List<Uri>) {
        Thread {
            var deleted = 0
            for (u in uris) {
                var ok = try {
                    DocumentsContract.deleteDocument(act.contentResolver, u)
                } catch (e: Exception) {
                    false
                }
                if (!ok) {
                    ok = try {
                        act.contentResolver.delete(u, null, null) > 0
                    } catch (e: Exception) {
                        false
                    }
                }
                if (ok) deleted++
            }
            ui.post {
                if (deleted == uris.size) {
                    toast("Originals deleted")
                } else {
                    toast("Deleted $deleted of ${uris.size}. Delete the rest in your file manager.")
                }
            }
        }.start()
    }

    // ------------------------------------------------------------------ vault: unhide

    private fun startUnhide(item: VideoItem, listener: Listener) {
        val dlg = busy("Decrypting...")
        Thread {
            val kindOf = fileKind(item.name, item.mime)
            val kind = when (kindOf) {
                KIND_AUDIO -> MediaSaver.Kind.AUDIO
                KIND_VIDEO -> MediaSaver.Kind.VIDEO
                KIND_IMAGE -> MediaSaver.Kind.IMAGE
                else -> MediaSaver.Kind.FILE
            }
            var mime = item.mime.ifEmpty { Vault.guessMime(item.name) }
            // the public media folders only accept the matching MIME family
            if (kind == MediaSaver.Kind.AUDIO && !mime.startsWith("audio/")) mime = "audio/mpeg"
            if (kind == MediaSaver.Kind.VIDEO && !mime.startsWith("video/")) mime = "video/mp4"
            if (kind == MediaSaver.Kind.IMAGE && !mime.startsWith("image/")) mime = "image/jpeg"
            val total = if (item.sizeBytes > 0) item.sizeBytes else 1L
            var lastPct = -1
            val res = MediaSaver.saveStream(act, item.name, mime, kind, "Restored") { out ->
                Vault.exportTo(act, item, out) { done ->
                    val pct = (done * 100 / total).toInt().coerceAtMost(100)
                    if (pct != lastPct) {
                        lastPct = pct
                        ui.post { dlg.setTitle("Decrypting... $pct%") }
                    }
                }
            }
            ui.post {
                dismissQuietly(dlg)
                if (res != null) {
                    Vault.delete(act, item)
                    Prefs.forget(act, item.prefKey)
                    listener.onHiddenChanged(item)
                    toast("Restored to $res")
                } else {
                    toast("Could not restore this file")
                }
            }
        }.start()
    }
}
