/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/*
 * SAFE FILE OPERATIONS
 *  - Nothing is ever overwritten (a free name is always chosen).
 *  - A copy is written to a hidden ".iapart" temp file, flushed to disk, size-checked, and only then renamed.
 *  - A move/delete removes the original ONLY after the new copy has been verified.
 *  - If anything fails or is cancelled, the original is untouched and half-written copies are removed.
 *  - Free space is checked before starting. Progress, speed and cancel are reported through OpState.
 */

class OpCancelled : IOException("Cancelled")

/** Live progress of a running operation (read by the progress dialog). */
class OpState(val title: String) {
    var totalBytes by mutableLongStateOf(0L)
    var doneBytes by mutableLongStateOf(0L)
    var totalItems by mutableIntStateOf(0)
    var doneItems by mutableIntStateOf(0)
    var current by mutableStateOf("")
    var speed by mutableDoubleStateOf(0.0)
    var preparing by mutableStateOf(true)
    var cancelRequested by mutableStateOf(false)

    /** Vault operations: file names must never appear in notifications (lock screen, notification shade). */
    @Volatile var secret = false

    /** How many times every byte is handled (Vault in: encrypt + verify + wipe = 3). [totalBytes] stays the real size. */
    var passes by mutableIntStateOf(1)

    /** What is happening to the current file ("Encrypting", "Verifying" ...). */
    var phase by mutableStateOf("")
    private val cancelFlag = java.util.concurrent.atomic.AtomicBoolean(false)

    private var bytes = 0L
    private var lastT = System.nanoTime()
    private var lastB = 0L

    val fraction: Float
        get() = when {
            totalBytes > 0 -> (doneBytes.toDouble() / (totalBytes.toDouble() * passes.coerceAtLeast(1))).coerceIn(0.0, 1.0).toFloat()
            totalItems > 0 -> (doneItems.toFloat() / totalItems).coerceIn(0f, 1f)
            else -> 0f
        }

    fun cancel() { cancelFlag.set(true); cancelRequested = true }
    fun checkCancel() { if (cancelFlag.get()) throw OpCancelled() }

    fun addBytes(n: Long) {
        bytes += n
        val now = System.nanoTime()
        if (now - lastT >= 250_000_000L) {
            val inst = (bytes - lastB) * 1e9 / (now - lastT)
            speed = if (speed == 0.0) inst else speed * 0.6 + inst * 0.4
            lastT = now
            lastB = bytes
            doneBytes = bytes
        }
    }

    fun flush() { doneBytes = bytes }
}

private const val CHUNK = 1L shl 20

/** Total bytes and number of files below [f]. */
fun treeStats(f: File): Pair<Long, Int> {
    if (f.isFile) return Pair(f.length(), 1)
    var b = 0L
    var n = 0
    f.walkTopDown().forEach { if (it.isFile) { b += it.length(); n++ } }
    return Pair(b, n)
}

private fun checkSpace(dir: File, need: Long) {
    dir.mkdirs()
    val free = dir.usableSpace
    if (need > 0 && free > 0 && free < need + (8L shl 20)) {
        throw IOException("Not enough free space (need ${fmtSize(need)}, free ${fmtSize(free)})")
    }
}

/** Copy one file safely: temp file -> flush -> verify size -> rename. */
fun copyFileSafe(src: File, dest: File, op: OpState?) {
    dest.parentFile?.mkdirs()
    val tmp = File(dest.parentFile, "." + dest.name + ".iapart")
    val track = src.length() > (4L shl 20)
    if (track) Ops.registerTmp(tmp)   // removed at the next start if the phone kills the app half way
    try {
        val expected = src.length()
        FileInputStream(src).channel.use { inp ->
            FileOutputStream(tmp).use { fos ->
                val out = fos.channel
                val size = inp.size()
                var pos = 0L
                while (pos < size) {
                    op?.checkCancel()
                    val n = inp.transferTo(pos, minOf(CHUNK, size - pos), out)
                    if (n <= 0) throw IOException("Could not read ${src.name}")
                    pos += n
                    op?.addBytes(n)
                }
                out.force(true)
            }
        }
        if (tmp.length() != expected || src.length() != expected) throw IOException("Copy check failed for ${src.name}")
        if (!tmp.renameTo(dest)) throw IOException("Could not finish writing ${dest.name}")
        dest.setLastModified(src.lastModified())
    } catch (e: Throwable) {
        tmp.delete()
        throw e
    } finally {
        if (track) Ops.unregisterTmp(tmp)
    }
}

private fun copyTreeSafe(src: File, dest: File, op: OpState?) {
    op?.checkCancel()
    if (src.isDirectory) {
        if (!dest.exists() && !dest.mkdirs()) throw IOException("Could not create folder ${dest.name}")
        val kids = src.listFiles() ?: throw IOException("Cannot read folder ${src.name}")
        kids.forEach { copyTreeSafe(it, File(dest, it.name), op) }
    } else {
        op?.current = src.name
        copyFileSafe(src, dest, op)
    }
}

/** True when both trees have the same names and sizes. */
fun sameTree(a: File, b: File): Boolean {
    if (a.isDirectory != b.isDirectory) return false
    if (a.isFile) return b.isFile && a.length() == b.length()
    val ka = a.listFiles() ?: return false
    val kb = b.listFiles() ?: return false
    if (ka.size != kb.size) return false
    return ka.all { sameTree(it, File(b, it.name)) }
}

private fun intoItself(src: File, dest: File) =
    src.isDirectory && (dest.path + "/").startsWith(src.path + "/")

fun copyItemSafe(src: File, destDir: File, op: OpState?): File {
    if (!src.exists()) throw IOException("Not found: ${src.name}")
    val dest = uniqueFile(destDir, src.name)
    if (intoItself(src, dest)) throw IOException("Cannot copy a folder into itself")
    checkSpace(destDir, treeStats(src).first)
    val trackDir = src.isDirectory && !dest.exists()
    if (trackDir) Ops.registerTmp(dest)
    try {
        copyTreeSafe(src, dest, op)
        if (!sameTree(src, dest)) throw IOException("Copy of ${src.name} could not be verified")
    } catch (e: Throwable) {
        dest.deleteRecursively()   // only the copy we just made; the original is never touched
        throw e
    } finally {
        if (trackDir) Ops.unregisterTmp(dest)
    }
    return dest
}

/**
 * Move [src] to the exact path [dest]. Same storage: atomic rename. Different storage: verified copy,
 * then the original is removed. Returns normally only if [src] is really gone and [dest] is complete.
 */
fun moveExact(src: File, dest: File, op: OpState?) {
    if (!src.exists()) throw IOException("Not found: ${src.name}")
    if (intoItself(src, dest)) throw IOException("Cannot move a folder into itself")
    dest.parentFile?.mkdirs()
    val bytes = if (op != null) treeStats(src).first else 0L
    if (src.renameTo(dest)) {
        if (!dest.exists() || src.exists()) throw IOException("Move of ${src.name} failed")
        op?.addBytes(bytes)
        return
    }
    // different storage (or rename refused): copy -> verify -> delete original
    checkSpace(dest.parentFile ?: dest, bytes)
    val trackDir = src.isDirectory && !dest.exists()
    if (trackDir) Ops.registerTmp(dest)
    try {
        copyTreeSafe(src, dest, op)
        if (!sameTree(src, dest)) throw IOException("Copy of ${src.name} could not be verified")
    } catch (e: Throwable) {
        dest.deleteRecursively()
        throw e
    } finally {
        // from here on the copy is complete and verified; deleting the original below can safely be interrupted
        if (trackDir) Ops.unregisterTmp(dest)
    }
    val wasFile = src.isFile
    val gone = if (wasFile) src.delete() else src.deleteRecursively()
    if (!gone || src.exists()) {
        if (wasFile) {
            dest.delete()   // nothing was lost: the original is still complete
            throw IOException("Cannot remove the original of ${src.name} (permission denied or file in use). Nothing was changed.")
        }
        throw IOException("${src.name}: copied, but part of the original folder could not be removed. A full copy exists at ${dest.path}")
    }
}

fun moveItemSafe(src: File, destDir: File, op: OpState?): File {
    if (src.parentFile == destDir) return src
    val dest = uniqueFile(destDir, src.name)
    op?.current = src.name
    moveExact(src, dest, op)
    return dest
}

/** Moves [f] into the recycle bin folder; returns the trash entry "storedName<TAB>originalPath". */
fun trashItem(f: File, trashDir: File, op: OpState?): String {
    trashDir.mkdirs()
    val t = uniqueFile(trashDir, f.name)
    op?.current = f.name
    moveExact(f, t, op)
    if (f.exists()) throw IOException("${f.name} is still in its folder")
    return t.name + "\t" + f.path
}

/** ZIP with temp file + cancel + progress. */
fun zipFilesSafe(files: List<File>, out: File, op: OpState?) {
    val tmp = File(out.parentFile, "." + out.name + ".iapart")
    Ops.registerTmp(tmp)
    try {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp), 64 * 1024)).use { z ->
            val buf = ByteArray(64 * 1024)
            fun add(f: File, prefix: String) {
                op?.checkCancel()
                if (f.isDirectory) {
                    val kids = f.listFiles() ?: throw IOException("Cannot read folder ${f.name}")
                    if (kids.isEmpty()) { z.putNextEntry(ZipEntry(prefix + f.name + "/")); z.closeEntry() }
                    kids.forEach { add(it, prefix + f.name + "/") }
                } else {
                    op?.current = f.name
                    z.putNextEntry(ZipEntry(prefix + f.name))
                    f.inputStream().use { i ->
                        while (true) {
                            op?.checkCancel()
                            val n = i.read(buf)
                            if (n < 0) break
                            z.write(buf, 0, n)
                            op?.addBytes(n.toLong())
                        }
                    }
                    z.closeEntry()
                }
            }
            files.forEach { add(it, "") }
        }
        if (!tmp.renameTo(out)) throw IOException("Could not finish writing ${out.name}")
    } catch (e: Throwable) {
        tmp.delete()
        throw e
    } finally {
        Ops.unregisterTmp(tmp)
    }
}

fun unzipSafe(zip: File, dest: File, op: OpState?) {
    val canon = dest.canonicalPath
    try {
        ZipFile(zip).use { zf ->
            val entries = zf.entries().toList()
            if (op != null) {
                op.totalBytes = entries.sumOf { maxOf(it.size, 0L) }
                op.totalItems = entries.count { !it.isDirectory }
                op.preparing = false
            }
            checkSpace(dest.parentFile ?: dest, entries.sumOf { maxOf(it.size, 0L) })
            if (!dest.exists()) Ops.registerTmp(dest)   // removed at the next start if the extraction is interrupted
            dest.mkdirs()
            val buf = ByteArray(64 * 1024)
            for (e in entries) {
                op?.checkCancel()
                val out = File(dest, e.name)
                if (!out.canonicalPath.startsWith(canon + File.separator)) throw IOException("Invalid zip entry")
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                op?.current = out.name
                zf.getInputStream(e).use { i ->
                    BufferedOutputStream(FileOutputStream(out), 64 * 1024).use { o ->
                        while (true) {
                            op?.checkCancel()
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            op?.addBytes(n.toLong())
                        }
                    }
                }
                op?.let { it.doneItems++ }
            }
        }
    } catch (e: Throwable) {
        dest.deleteRecursively()   // the folder we were creating
        throw e
    } finally {
        Ops.unregisterTmp(dest)
    }
}

// ---------------- progress dialog ----------------
@Composable
fun OpDialog(st: OpState) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(300); show = true }   // quick operations never flash a dialog
    if (!show) return
    val frac = st.fraction
    val passes = st.passes.coerceAtLeast(1)
    val workTotal = st.totalBytes * passes
    val left = if (st.speed > 1 && workTotal > st.doneBytes) ((workTotal - st.doneBytes) / st.speed).toInt() else -1
    val shownDone = minOf(st.doneBytes / passes, st.totalBytes)   // the real file size is shown, not the work of every pass
    AlertDialog(
        onDismissRequest = {},
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
        title = { Text(st.title) },
        text = {
            Column {
                Text(st.current, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (st.phase.isNotEmpty()) {
                    Text(st.phase, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(12.dp))
                if (st.preparing) LinearProgressIndicator(Modifier.fillMaxWidth())
                else LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(if (st.preparing) "Preparing..." else "${(frac * 100).toInt()}%", fontWeight = FontWeight.Bold)
                    if (st.totalBytes > 0 && st.speed > 0) Text(fmtSize((st.speed / passes).toLong()) + "/s", fontWeight = FontWeight.Medium)
                }
                if (st.totalBytes > 0) {
                    Text(
                        fmtSize(shownDone) + " / " + fmtSize(st.totalBytes) + if (left >= 0) "  \u2022  ~${left}s left" else "",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (st.totalItems > 0) {
                    Text(
                        "${minOf(st.doneItems, st.totalItems)} / ${st.totalItems} items",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { st.cancel() }, enabled = !st.cancelRequested) {
                Text(if (st.cancelRequested) "Cancelling..." else "Cancel")
            }
        }
    )
}
