/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app.player

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import com.iamanager.app.Vault
import java.io.IOException

/**
 * Feeds the player straight from an encrypted vault file ("iavault://<id>/f.mp4").
 * The data is decrypted chunk by chunk in memory while it plays: nothing readable is ever written to storage,
 * playback starts at once, and seeking is instant - no waiting for a whole video to be decrypted first.
 */
class VaultDataSource : BaseDataSource(false) {
    private var reader: Vault.StreamReader? = null
    private var curUri: Uri? = null
    private var pos = 0L
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        curUri = dataSpec.uri
        transferInitializing(dataSpec)
        val id = dataSpec.uri.host ?: throw IOException("Not a vault address")
        val r = Vault.openStream(id) ?: throw IOException("The Vault is locked")
        reader = r
        if (dataSpec.position > r.size) {
            close()
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        pos = dataSpec.position
        val left = r.size - pos
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) minOf(dataSpec.length, left) else left
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val r = reader ?: return C.RESULT_END_OF_INPUT
        val n = r.read(pos, buffer, offset, minOf(length.toLong(), remaining).toInt())
        if (n <= 0) return C.RESULT_END_OF_INPUT
        pos += n
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = curUri

    override fun close() {
        try {
            reader?.close()
        } finally {
            reader = null
            curUri = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }
}
