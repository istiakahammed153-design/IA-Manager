/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

val APK_BUNDLE_EXTS = setOf("apks", "xapk", "apkm")
val APK_EXTS = setOf("apk") + APK_BUNDLE_EXTS
private val ApkGreen = Color(0xFF3DDC84)

// =====================================================================================
//  Installer engine (PackageInstaller session - works for normal and split APKs)
// =====================================================================================

object ApkInstall {
    /** Latest result message coming back from the system installer (shown once, then cleared). */
    val result = mutableStateOf<String?>(null)
}

/** Receives the status of an install session and opens the system confirmation screen when needed. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                }
                if (confirm != null) {
                    try {
                        confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(confirm)
                    } catch (e: Exception) {
                        ApkInstall.result.value = "Could not open the system installer"
                    }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> ApkInstall.result.value = "Installed successfully"
            PackageInstaller.STATUS_FAILURE_ABORTED -> ApkInstall.result.value = "Installation cancelled"
            PackageInstaller.STATUS_FAILURE_CONFLICT -> ApkInstall.result.value =
                "Install failed: conflicts with an installed app (different signature?). Uninstall the old one first."
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE -> ApkInstall.result.value =
                "Install failed: this app is not compatible with your phone"
            PackageInstaller.STATUS_FAILURE_STORAGE -> ApkInstall.result.value = "Install failed: not enough storage"
            PackageInstaller.STATUS_FAILURE_INVALID -> ApkInstall.result.value =
                "Install failed: the APK file is invalid or corrupted"
            else -> ApkInstall.result.value = "Install failed" + if (msg.isNotBlank()) ": $msg" else ""
        }
    }
}

private fun installApkFiles(ctx: Context, files: List<File>) {
    val pi = ctx.packageManager.packageInstaller
    val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
    val id = pi.createSession(params)
    val session = pi.openSession(id)
    try {
        files.forEachIndexed { i, f ->
            f.inputStream().use { ins ->
                session.openWrite("part_$i.apk", 0, f.length()).use { out ->
                    ins.copyTo(out, 1 shl 16)
                    session.fsync(out)
                }
            }
        }
        val intent = Intent(ctx, InstallReceiver::class.java).setPackage(ctx.packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pending = PendingIntent.getBroadcast(ctx, id, intent, flags)
        session.commit(pending.intentSender)
    } catch (t: Throwable) {
        try { session.abandon() } catch (_: Throwable) {}
        throw t
    } finally {
        try { session.close() } catch (_: Throwable) {}
    }
}

/** Installs a .apk, or a split bundle (.apks / .xapk / .apkm) by installing every APK inside it together. */
fun installApkFile(ctx: Context, f: File) {
    if (f.ext == "apk") {
        installApkFiles(ctx, listOf(f))
        return
    }
    val dir = File(ctx.cacheDir, "apkinst")
    dir.deleteRecursively()
    dir.mkdirs()
    val parts = ArrayList<File>()
    try {
        ZipInputStream(f.inputStream().buffered()).use { z ->
            var e: ZipEntry? = z.nextEntry
            while (e != null) {
                if (!e.isDirectory && e.name.endsWith(".apk", ignoreCase = true)) {
                    val t = File(dir, "p${parts.size}.apk")
                    t.outputStream().use { o -> z.copyTo(o, 1 shl 16) }
                    parts.add(t)
                }
                e = z.nextEntry
            }
        }
        if (parts.isEmpty()) throw IOException("No APK files found inside this package")
        installApkFiles(ctx, parts)
    } finally {
        dir.deleteRecursively()
    }
}

class ApkMeta(
    val label: String,
    val pkg: String,
    val versionName: String,
    val versionCode: Long,
    val icon: ImageBitmap?,
    val perms: List<String>,
    val parts: Int
)

private fun readApkMeta(ctx: Context, f: File): ApkMeta? {
    val pm = ctx.packageManager
    if (f.ext == "apk") {
        val info = try {
            pm.getPackageArchiveInfo(f.path, android.content.pm.PackageManager.GET_PERMISSIONS)
        } catch (e: Throwable) { null } ?: return null
        val ai = info.applicationInfo ?: return ApkMeta(f.nameWithoutExtension, info.packageName ?: "", info.versionName ?: "", PackageInfoCompat.getLongVersionCode(info), null, emptyList(), 1)
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        val label = try { ai.loadLabel(pm).toString() } catch (e: Throwable) { f.nameWithoutExtension }
        val icon = try { ai.loadIcon(pm).toBitmap(160, 160).asImageBitmap() } catch (e: Throwable) { null }
        return ApkMeta(
            label, info.packageName ?: "", info.versionName ?: "",
            PackageInfoCompat.getLongVersionCode(info), icon,
            info.requestedPermissions?.toList() ?: emptyList(), 1
        )
    }
    // split bundle: count the APKs and read the small info file when there is one
    var parts = 0
    var label = f.nameWithoutExtension
    var pkg = ""
    var ver = ""
    try {
        ZipFile(f).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory && e.name.endsWith(".apk", ignoreCase = true)) parts++
            }
            val j = z.getEntry("manifest.json") ?: z.getEntry("info.json")
            if (j != null) {
                val o = JSONObject(z.getInputStream(j).bufferedReader().readText())
                label = o.optString("name", o.optString("app_name", label)).ifBlank { label }
                pkg = o.optString("package_name", o.optString("pname", ""))
                ver = o.optString("version_name", o.optString("versionname", ""))
            }
        }
    } catch (e: Throwable) {
        if (parts == 0) return null
    }
    return ApkMeta(label, pkg, ver, 0L, null, emptyList(), parts)
}

private class InstalledState(val versionName: String, val versionCode: Long, val canOpen: Boolean)

private fun installedState(ctx: Context, pkg: String): InstalledState? {
    if (pkg.isBlank()) return null
    return try {
        val pm = ctx.packageManager
        val i = pm.getPackageInfo(pkg, 0)
        InstalledState(i.versionName ?: "", PackageInfoCompat.getLongVersionCode(i), pm.getLaunchIntentForPackage(pkg) != null)
    } catch (e: Throwable) { null }
}

// =====================================================================================
//  APK viewer (opens when an APK is tapped)
// =====================================================================================

@Composable
fun ApkViewer(vm: AppViewModel, f: File) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var resume by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var needPerm by remember { mutableStateOf(false) }
    var showPerms by remember { mutableStateOf(false) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) resume++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    // result of the system installer
    val res = ApkInstall.result.value
    LaunchedEffect(res) {
        if (res != null) {
            vm.message = res
            ApkInstall.result.value = null
            busy = false
            resume++
        }
    }

    var loaded by remember(f.path) { mutableStateOf(false) }
    val meta by produceState<ApkMeta?>(null, f.path) {
        value = withContext(Dispatchers.IO) { readApkMeta(ctx, f) }
        loaded = true
    }
    val installed by produceState<InstalledState?>(null, meta, resume) {
        val pkg = meta?.pkg ?: ""
        value = withContext(Dispatchers.IO) { installedState(ctx, pkg) }
    }

    fun doInstall() {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            needPerm = true
            return
        }
        busy = true
        scope.launch {
            val err = withContext(Dispatchers.IO) {
                try { installApkFile(ctx, f); null } catch (e: Throwable) { e.message ?: "Install failed" }
            }
            if (err != null) {
                busy = false
                vm.message = err
                // last resort: hand the file to the phone's own installer
                if (f.ext == "apk") openFile(ctx, f)
            }
        }
    }

    val m = meta
    val inst = installed
    val statusText: String = when {
        m == null -> ""
        inst == null -> "Not installed"
        m.versionCode == 0L -> "Already installed (${inst.versionName})"
        m.versionCode > inst.versionCode -> "Update available: ${inst.versionName} \u2192 ${m.versionName}"
        m.versionCode == inst.versionCode -> "Same version is already installed"
        else -> "Older than the installed version (${inst.versionName}) - Android may refuse"
    }
    val actionText: String = when {
        m == null || inst == null -> "Install"
        m.versionCode > inst.versionCode -> "Update"
        else -> "Reinstall"
    }

    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) { ViewerMenu(vm, f) }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(22.dp)).background(ApkGreen.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                val ic = m?.icon
                if (ic != null) Image(ic, null, Modifier.size(96.dp))
                else Icon(Icons.Outlined.Android, null, tint = ApkGreen, modifier = Modifier.size(56.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(m?.label ?: f.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
            if (m != null && m.pkg.isNotBlank()) {
                Text(m.pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(4.dp))
            val sub = buildString {
                if (m != null && m.versionName.isNotBlank()) append("v${m.versionName}  \u2022  ")
                append(fmtSize(f.length()))
                if (m != null && f.ext != "apk") append("  \u2022  ${m.parts} APK files")
            }
            Text(sub, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))

            if (!loaded) {
                CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
            } else if (m == null) {
                Text(
                    "This file could not be read as an app package. It may be damaged or incomplete - download it again.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.error
                )
            } else {
                Text(statusText, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(20.dp))

            if (m != null) {
                Button(
                    onClick = { doInstall() }, enabled = !busy,
                    modifier = Modifier.fillMaxWidth(0.85f)
                ) {
                    if (busy) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(Modifier.width(10.dp))
                        Text("Installing\u2026")
                    } else {
                        Icon(Icons.Outlined.FileDownload, null)
                        Spacer(Modifier.width(8.dp))
                        Text(actionText)
                    }
                }
                if (inst != null) {
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(0.85f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (inst.canOpen) OutlinedButton(
                            onClick = {
                                ctx.packageManager.getLaunchIntentForPackage(m.pkg)?.let {
                                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    try { ctx.startActivity(it) } catch (e: Exception) {}
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Open") }
                        OutlinedButton(
                            onClick = { uninstallApp(ctx, m.pkg) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Uninstall") }
                    }
                }
                if (m.perms.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    TextButton(onClick = { showPerms = !showPerms }) {
                        Text((if (showPerms) "Hide" else "Show") + " permissions (${m.perms.size})")
                    }
                    if (showPerms) {
                        m.perms.forEach {
                            Text(
                                it.substringAfterLast('.'), fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { vm.push(Screen.Details(f.path)) }) { Text("Details") }
        }
    }

    if (needPerm) {
        AlertDialog(
            onDismissRequest = { needPerm = false },
            title = { Text("Allow installing apps") },
            text = { Text("Android needs your permission before IA Manager can install apps. Turn on \"Allow from this source\" on the next screen, then come back and tap Install again.") },
            confirmButton = {
                TextButton(onClick = {
                    needPerm = false
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (e: Exception) {
                        vm.message = "Open Settings > Apps > IA Manager > Install unknown apps"
                    }
                }) { Text("Open settings") }
            },
            dismissButton = { TextButton(onClick = { needPerm = false }) { Text("Cancel") } }
        )
    }
}

fun uninstallApp(ctx: Context, pkg: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        android.widget.Toast.makeText(ctx, "Cannot uninstall this app", android.widget.Toast.LENGTH_SHORT).show()
    }
}

// =====================================================================================
//  File scanning helper
// =====================================================================================

fun scanTree(root: File, limit: Int = 20000, accept: (File) -> Boolean): List<File> {
    val out = ArrayList<File>()
    val stack = ArrayList<File>()
    stack.add(root)
    while (stack.isNotEmpty() && out.size < limit) {
        val d = stack.removeAt(stack.size - 1)
        val kids = d.listFiles() ?: continue
        for (c in kids) {
            if (c.isDirectory) {
                if (c.name.startsWith(".")) continue
                if (c.name == "Android" && d.path == root.path) continue
                stack.add(c)
            } else if (accept(c)) {
                out.add(c)
                if (out.size >= limit) break
            }
        }
    }
    return out
}

// =====================================================================================
//  Apps screen: installed apps + all APK files on the phone
// =====================================================================================

class AppEntry(
    val label: String,
    val pkg: String,
    val version: String,
    val size: Long,
    val icon: ImageBitmap?,
    val dir: String,
    val splits: List<String>,
    val system: Boolean
)

private fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0).map { ai ->
        val label = try { ai.loadLabel(pm).toString() } catch (e: Throwable) { ai.packageName }
        val ver = try { pm.getPackageInfo(ai.packageName, 0).versionName ?: "" } catch (e: Throwable) { "" }
        val icon = try { ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap() } catch (e: Throwable) { null }
        val splits = ai.splitSourceDirs?.toList() ?: emptyList()
        val size = (listOf(ai.sourceDir) + splits).sumOf { File(it).length() }
        val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
        AppEntry(label, ai.packageName, ver, size, icon, ai.sourceDir, splits, sys)
    }.sortedBy { it.label.lowercase() }
}

private fun backupApp(vm: AppViewModel, e: AppEntry): String {
    val dir = File(vm.root, "IA Manager/APK Backup")
    if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create the backup folder")
    val base = (e.label.replace(Regex("[^A-Za-z0-9._ -]"), "_") + "_" + e.version).trim()
    if (e.splits.isEmpty()) {
        val out = uniqueFile(dir, "$base.apk")
        File(e.dir).inputStream().use { i -> out.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
        return "Saved to IA Manager/APK Backup/${out.name}"
    }
    val out = uniqueFile(dir, "$base.apks")
    ZipOutputStream(out.outputStream().buffered()).use { z ->
        (listOf(e.dir) + e.splits).forEachIndexed { idx, p ->
            z.putNextEntry(ZipEntry(if (idx == 0) "base.apk" else File(p).name))
            File(p).inputStream().use { i -> i.copyTo(z, 1 shl 16) }
            z.closeEntry()
        }
    }
    return "Saved to IA Manager/APK Backup/${out.name}"
}

@Composable
fun AppsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var showSystem by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf<AppEntry?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) reload++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }

    val apps by produceState<List<AppEntry>?>(null, reload) {
        value = withContext(Dispatchers.IO) { loadApps(ctx) }
    }
    val apkFiles by produceState<List<File>?>(null, vm.tick, vm.root) {
        value = withContext(Dispatchers.IO) {
            scanTree(vm.root) { it.ext in APK_EXTS }.sortedByDescending { it.lastModified() }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (tab == 1 && vm.selected.isNotEmpty()) SelectionTop(vm, apkFiles ?: emptyList())
        else SimpleTop("Apps & APK Installer", onBack = { vm.pop() })
        ChipsRow(listOf("Installed apps", "APK files"), tab) { tab = it; vm.selected = emptySet() }

        if (tab == 0) {
            val all = apps
            if (all == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                val shown = all.filter {
                    (showSystem || !it.system) &&
                        (query.isBlank() || it.label.contains(query, true) || it.pkg.contains(query, true))
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    placeholder = { Text("Search apps") }, singleLine = true,
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                )
                Row(
                    Modifier.fillMaxWidth().clickable { showSystem = !showSystem }.padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${shown.size} apps", Modifier.weight(1f), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("System apps", fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    Switch(checked = showSystem, onCheckedChange = { showSystem = it })
                }
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
                    items(shown, key = { it.pkg }) { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { pick = a }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (a.icon != null) Image(a.icon, null, Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
                            else Icon(Icons.Outlined.Android, null, tint = ApkGreen, modifier = Modifier.size(44.dp))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                                Text(
                                    "${a.version}  \u2022  ${fmtSize(a.size)}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        } else {
            val list = apkFiles
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                FileCollection(
                    list, vm, false, onOpen = { vm.open(ctx, it) },
                    emptyText = "No APK files found on this storage", stateKey = "apkfiles|"
                )
            }
        }
    }

    val a = pick
    if (a != null) {
        AlertDialog(
            onDismissRequest = { pick = null },
            title = { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text(a.pkg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    if (ctx.packageManager.getLaunchIntentForPackage(a.pkg) != null) {
                        ActionRow(Icons.Outlined.OpenInNew, Color(0xFF1A73E8), "Open", null) {
                            pick = null
                            ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                try { ctx.startActivity(it) } catch (e: Exception) {}
                            }
                        }
                    }
                    ActionRow(Icons.Outlined.Backup, Color(0xFF1E8E3E), "Backup APK", "Save a copy in IA Manager / APK Backup") {
                        pick = null
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                try { backupApp(vm, a) } catch (e: Throwable) { "Backup failed: ${e.message}" }
                            }
                            vm.message = r
                            vm.refresh()
                        }
                    }
                    ActionRow(Icons.Outlined.Share, Color(0xFF7C4DFF), "Share APK", null) {
                        pick = null
                        shareFiles(ctx, listOf(File(a.dir)))
                    }
                    ActionRow(Icons.Outlined.Info, Color(0xFFFFA000), "App info", "System settings for this app") {
                        pick = null
                        try {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) {}
                    }
                    if (!a.system) ActionRow(Icons.Outlined.DeleteOutline, Color(0xFFE53935), "Uninstall", null) {
                        pick = null
                        uninstallApp(ctx, a.pkg)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pick = null }) { Text("Close") } }
        )
    }
}

// =====================================================================================
//  Large files finder
// =====================================================================================

@Composable
fun LargeFilesScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val steps = listOf(10, 50, 100, 500)
    var minMb by remember { mutableIntStateOf(50) }
    var loading by remember { mutableStateOf(true) }
    val files by produceState(emptyList<File>(), minMb, vm.tick, vm.root) {
        loading = true
        val limit = minMb * 1024L * 1024L
        value = withContext(Dispatchers.IO) {
            scanTree(vm.root) { it.length() >= limit }.sortedByDescending { it.length() }.take(300)
        }
        loading = false
    }
    Column(Modifier.fillMaxSize()) {
        if (vm.selected.isNotEmpty()) SelectionTop(vm, files) else SimpleTop("Large Files", onBack = { vm.pop() })
        FileCollection(
            files, vm, false, onOpen = { vm.open(ctx, it) },
            emptyText = if (loading) "Scanning\u2026" else "No files this large",
            stateKey = "large|",
            header = {
                ChipsRow(steps.map { "> $it MB" }, steps.indexOf(minMb)) { minMb = steps[it] }
            }
        )
    }
}

// =====================================================================================
//  Duplicate finder
// =====================================================================================

class DupGroup(val size: Long, val files: List<File>)

private fun hashOf(f: File, maxBytes: Long = Long.MAX_VALUE): String? = try {
    val md = MessageDigest.getInstance("SHA-1")
    f.inputStream().use { ins ->
        val buf = ByteArray(1 shl 16)
        var left = maxBytes
        while (left > 0) {
            val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) break
            md.update(buf, 0, n)
            left -= n
        }
    }
    md.digest().joinToString("") { "%02x".format(it) }
} catch (e: Throwable) { null }

private fun findDuplicates(root: File): List<DupGroup> {
    val all = scanTree(root, 40000) { it.length() > 1024 }
    val bySize = all.groupBy { it.length() }.filter { it.value.size > 1 }
    val out = ArrayList<DupGroup>()
    for ((size, same) in bySize) {
        // cheap check on the first 64 KB, then a full check only for the files that still match
        val quick = same.groupBy { hashOf(it, 65536) ?: "?${it.path}" }.filter { it.value.size > 1 }
        for ((_, cand) in quick) {
            val full = cand.groupBy { hashOf(it) ?: "?${it.path}" }.filter { it.value.size > 1 }
            for ((_, g) in full) out.add(DupGroup(size, g.sortedBy { it.lastModified() }))
        }
    }
    return out.sortedByDescending { it.size * (it.files.size - 1) }
}

@Composable
fun DuplicatesScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var scanning by remember { mutableStateOf(true) }
    val groups by produceState(emptyList<DupGroup>(), vm.tick, vm.root) {
        scanning = true
        value = withContext(Dispatchers.IO) { findDuplicates(vm.root) }
        scanning = false
    }
    val all = groups.flatMap { it.files }
    Column(Modifier.fillMaxSize()) {
        if (vm.selected.isNotEmpty()) SelectionTop(vm, all)
        else SimpleTop("Duplicate Files", onBack = { vm.pop() }) {
            if (groups.isNotEmpty()) TextButton(onClick = {
                // keep the oldest copy of every group, select the rest
                vm.selected = groups.flatMap { it.files.drop(1) }.map { it.path }.toSet()
            }) { Text("Select extras") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 96.dp)) {
            if (scanning) {
                item {
                    Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Looking for identical files\u2026")
                    }
                }
            } else if (groups.isEmpty()) {
                item { EmptyState("No duplicate files found") }
            }
            groups.forEach { g ->
                item(key = "h:" + g.files[0].path) {
                    Text(
                        "${g.files.size} identical copies  \u2022  ${fmtSize(g.size)} each",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 2.dp)
                    )
                }
                items(g.files, key = { it.path }) { f -> FileRow(f, vm) { vm.open(ctx, f) } }
            }
        }
    }
}
