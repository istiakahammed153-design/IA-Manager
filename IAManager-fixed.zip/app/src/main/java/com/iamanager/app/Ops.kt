/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.io.File

/**
 * Long file operations (copy, move, vault in/out, delete, zip ...) live HERE and not in a screen:
 *  - they run in a scope that belongs to the app process, so leaving the screen, pressing Home or even closing the
 *    app does not stop them;
 *  - a foreground service ([TransferService]) with a progress notification keeps Android from killing the process;
 *  - the half-written files of a transfer are remembered, so if the phone still kills the app (battery empty, force
 *    stop) they are removed at the next start. Originals are only removed after a verified copy exists, so nothing
 *    is ever lost.
 */
object Ops {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** The running operation (shown by the progress dialog of whichever screen is open). */
    var state by mutableStateOf<OpState?>(null)

    /** True while the main screen is in front. */
    @Volatile var visible = false

    /** The screen model that is open right now (null when the app was closed but a transfer is still running). */
    @Volatile var activeVm: AppViewModel? = null

    @Volatile private var app: Context? = null

    fun init(c: Context) {
        if (app == null) app = c.applicationContext
    }

    // ---------------- foreground service + notifications ----------------
    const val CH_PROGRESS = "ia_transfer"
    const val CH_DONE = "ia_transfer_done"
    const val ID_PROGRESS = 2001
    const val ID_DONE = 2002

    fun begin(ctx: Context) {
        try {
            ensureChannels(ctx)
            ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
        } catch (e: Exception) {
            // the transfer still runs; it is just not protected by the service
        }
    }

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "File transfers", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Transfer results", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun openAppIntent(ctx: Context): PendingIntent {
        val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent(ctx, MainActivity::class.java)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun progressNotification(ctx: Context, st: OpState?): Notification {
        ensureChannels(ctx)
        val b = NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_transfer)
            .setContentTitle(st?.title ?: "IA Manager")
            .setContentText(if (st?.secret == true) "Working..." else (st?.current?.takeIf { it.isNotEmpty() } ?: "Working..."))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent(ctx))
        if (st != null) {
            if (st.preparing) b.setProgress(0, 0, true) else b.setProgress(1000, (st.fraction * 1000).toInt(), false)
            val cancel = PendingIntent.getService(
                ctx, 1, Intent(ctx, TransferService::class.java).setAction(TransferService.ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "Cancel", cancel)
        }
        return b.build()
    }

    /** Result notification, shown only when the app is not on screen. */
    fun notifyDone(ctx: Context, title: String, text: String, failed: Boolean) {
        try {
            ensureChannels(ctx)
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(R.drawable.ic_transfer)
                .setContentTitle(if (failed) "$title: stopped" else "$title: finished")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setAutoCancel(true)
                .setContentIntent(openAppIntent(ctx))
                .build()
            ctx.getSystemService(NotificationManager::class.java)?.notify(ID_DONE, n)
        } catch (e: Exception) {
        }
    }

    // ---------------- half-written files ----------------
    private const val TMP_PREFS = "ia_tmp"
    private const val TMP_KEY = "paths"

    /** Remember a temp file / half-built folder BEFORE it is created, so it can be cleaned up after a crash. */
    @Synchronized
    fun registerTmp(f: File) {
        val c = app ?: return
        val p = c.getSharedPreferences(TMP_PREFS, Context.MODE_PRIVATE)
        val s = HashSet(p.getStringSet(TMP_KEY, emptySet()) ?: emptySet())
        if (s.add(f.path)) p.edit().putStringSet(TMP_KEY, s).commit()
    }

    @Synchronized
    fun unregisterTmp(f: File) {
        val c = app ?: return
        val p = c.getSharedPreferences(TMP_PREFS, Context.MODE_PRIVATE)
        val s = HashSet(p.getStringSet(TMP_KEY, emptySet()) ?: emptySet())
        if (s.remove(f.path)) p.edit().putStringSet(TMP_KEY, s).apply()
    }

    /** At app start (no transfer running): delete what an interrupted transfer left behind. */
    @Synchronized
    fun cleanLeftovers() {
        val c = app ?: return
        val p = c.getSharedPreferences(TMP_PREFS, Context.MODE_PRIVATE)
        val s = p.getStringSet(TMP_KEY, null) ?: return
        for (path in s) {
            try { File(path).deleteRecursively() } catch (e: Exception) { }
        }
        p.edit().remove(TMP_KEY).commit()
    }
}

/** Keeps the process alive and shows progress while a file operation runs. It stops itself when the operation ends. */
class TransferService : Service() {
    companion object {
        const val ACTION_CANCEL = "com.iamanager.app.CANCEL_OP"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            val st = Ops.state
            if (st == null) {
                finishService()
                return
            }
            try {
                getSystemService(NotificationManager::class.java)
                    ?.notify(Ops.ID_PROGRESS, Ops.progressNotification(this@TransferService, st))
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 700)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            Ops.state?.cancel()
            if (running) return START_NOT_STICKY
        }
        val n = Ops.progressNotification(this, Ops.state)
        if (Build.VERSION.SDK_INT >= 29) startForeground(Ops.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(Ops.ID_PROGRESS, n)
        running = true
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_NOT_STICKY
    }

    private fun finishService() {
        handler.removeCallbacks(tick)
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
