/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

// ---------------- DOCX / PPTX: paragraph text editing (formatting is kept) ----------------

class ParaRef(val entry: String, val ordinal: Int, val label: String, val original: String)

private fun paraRegex(pfx: String) =
    if (pfx == "w") Regex("<w:p[ >].*?</w:p>", RegexOption.DOT_MATCHES_ALL)
    else Regex("<a:p>.*?</a:p>|<a:p [^>]*>.*?</a:p>", RegexOption.DOT_MATCHES_ALL)

private fun textRegex(pfx: String) = Regex("<$pfx:t(?: [^>]*)?>(.*?)</$pfx:t>", RegexOption.DOT_MATCHES_ALL)
private fun textFullRegex(pfx: String) = Regex("<$pfx:t(?: [^>]*)?>.*?</$pfx:t>", RegexOption.DOT_MATCHES_ALL)

private fun paraEntries(z: ZipFile, ext: String): List<String> =
    if (ext == "docx") listOf("word/document.xml")
    else z.entries().toList().map { it.name }
        .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
        .sortedBy { it.filter { c -> c.isDigit() }.toInt() }

fun loadParas(f: File): List<ParaRef> {
    val pfx = if (f.ext == "docx") "w" else "a"
    val list = ArrayList<ParaRef>()
    ZipFile(f).use { z ->
        val entries = paraEntries(z, f.ext)
        if (entries.isEmpty()) throw java.io.IOException("Not a valid document")
        entries.forEachIndexed { idx, name ->
            val ze = z.getEntry(name) ?: return@forEachIndexed
            val xml = z.getInputStream(ze).bufferedReader(Charsets.UTF_8).readText()
            val label = if (f.ext == "pptx") "Slide ${idx + 1}" else ""
            var ord = 0
            for (m in paraRegex(pfx).findAll(xml)) {
                val text = textRegex(pfx).findAll(m.value).joinToString("") { xmlUnescape(it.groupValues[1]) }
                if (textRegex(pfx).containsMatchIn(m.value)) list.add(ParaRef(name, ord, label, text))
                ord++
            }
        }
    }
    return list
}

fun saveParas(src: File, out: File, edits: Map<Pair<String, Int>, String>) {
    val pfx = if (src.ext == "docx") "w" else "a"
    val editedEntries = edits.keys.map { it.first }.toSet()
    ZipFile(src).use { z ->
        ZipOutputStream(FileOutputStream(out)).use { zo ->
            for (e in z.entries().toList()) {
                var bytes = z.getInputStream(e).readBytes()
                if (e.name in editedEntries) {
                    var ord = 0
                    val xml = String(bytes, Charsets.UTF_8)
                    val full = textFullRegex(pfx)
                    val rewritten = paraRegex(pfx).replace(xml) { m ->
                        val k = ord++
                        val nt = edits[Pair(e.name, k)]
                        if (nt == null) m.value else {
                            var first = true
                            full.replace(m.value) {
                                if (first) {
                                    first = false
                                    "<$pfx:t xml:space=\"preserve\">" + xmlEscape(nt) + "</$pfx:t>"
                                } else "<$pfx:t></$pfx:t>"
                            }
                        }
                    }
                    bytes = rewritten.toByteArray(Charsets.UTF_8)
                }
                zo.putNextEntry(ZipEntry(e.name))
                zo.write(bytes)
                zo.closeEntry()
            }
        }
    }
}

// ---------------- XLSX: cell editing ----------------

class XGrid(val rowNums: List<Int>, val cells: List<List<String>>, val cols: Int)

private val X_ROW = Regex("<row[ >].*?</row>", RegexOption.DOT_MATCHES_ALL)
private val X_ROWNUM = Regex("<row[^>]*?\\sr=\"(\\d+)\"")
private val X_CELL = Regex("<c\\s([^>]*?)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL)
private val X_REF = Regex("r=\"([A-Z]+)(\\d+)\"")
private val X_TYPE = Regex("t=\"(\\w+)\"")
private val X_STYLE = Regex("\\ss=\"(\\d+)\"")
private val X_V = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL)
private val X_SI = Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL)
private val X_T = Regex("<t(?: [^>]*)?>(.*?)</t>", RegexOption.DOT_MATCHES_ALL)

private fun colIdx(letters: String): Int {
    var n = 0
    for (c in letters) n = n * 26 + (c - 'A' + 1)
    return n - 1
}

private fun colName(index: Int): String {
    var n = index + 1
    val sb = StringBuilder()
    while (n > 0) {
        val r = (n - 1) % 26
        sb.insert(0, ('A' + r))
        n = (n - 1) / 26
    }
    return sb.toString()
}

private fun sheetEntryName(z: ZipFile): String =
    z.entries().toList().map { it.name }.filter { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") }
        .minOrNull() ?: throw java.io.IOException("No worksheet found")

fun loadGrid(f: File): XGrid {
    return ZipFile(f).use { z ->
        val shared = ArrayList<String>()
        z.getEntry("xl/sharedStrings.xml")?.let { e ->
            val xml = z.getInputStream(e).bufferedReader(Charsets.UTF_8).readText()
            for (si in X_SI.findAll(xml)) shared.add(X_T.findAll(si.groupValues[1]).joinToString("") { xmlUnescape(it.groupValues[1]) })
        }
        val xml = z.getInputStream(z.getEntry(sheetEntryName(z))).bufferedReader(Charsets.UTF_8).readText()
        val nums = ArrayList<Int>()
        val rows = ArrayList<MutableList<String>>()
        var maxCols = 1
        for (row in X_ROW.findAll(xml)) {
            val rn = X_ROWNUM.find(row.value)?.groupValues?.get(1)?.toIntOrNull() ?: (nums.size + 1)
            val cells = ArrayList<String>()
            for (c in X_CELL.findAll(row.value)) {
                val attrs = c.groupValues[1]
                val body = c.groupValues[2]
                val col = X_REF.find(attrs)?.groupValues?.get(1)?.let { colIdx(it) } ?: cells.size
                if (col >= 60) continue
                while (cells.size < col) cells.add("")
                val type = X_TYPE.find(attrs)?.groupValues?.get(1)
                val v = X_V.find(body)?.groupValues?.get(1)
                val text = when (type) {
                    "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                    "inlineStr" -> X_T.findAll(body).joinToString("") { xmlUnescape(it.groupValues[1]) }
                    else -> xmlUnescape(v ?: "")
                }
                if (cells.size == col) cells.add(text) else cells[col] = text
            }
            nums.add(rn)
            rows.add(cells)
            if (cells.size > maxCols) maxCols = cells.size
            if (rows.size >= 500) break
        }
        XGrid(nums, rows.map { r -> List(maxCols) { r.getOrElse(it) { "" } } }, maxCols)
    }
}

private fun newCellXml(ref: String, style: String?, value: String): String {
    val s = if (style != null) " s=\"$style\"" else ""
    val v = value.trim()
    return when {
        value.isEmpty() -> "<c r=\"$ref\"$s/>"
        Regex("^-?\\d+(\\.\\d+)?$").matches(v) -> "<c r=\"$ref\"$s><v>$v</v></c>"
        else -> "<c r=\"$ref\"$s t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(value)}</t></is></c>"
    }
}

private fun setCellInRow(rowXml: String, rowNum: Int, col: Int, value: String): String {
    val ref = colName(col) + rowNum
    var found = false
    var result = X_CELL.replace(rowXml) { m ->
        val attrs = m.groupValues[1]
        val c = X_REF.find(attrs)?.groupValues?.get(1)?.let { colIdx(it) } ?: -1
        if (c == col) {
            found = true
            newCellXml(ref, X_STYLE.find(" $attrs")?.groupValues?.get(1), value)
        } else m.value
    }
    if (!found) {
        val cell = newCellXml(ref, null, value)
        var inserted = false
        for (m in X_CELL.findAll(result)) {
            val c = X_REF.find(m.groupValues[1])?.groupValues?.get(1)?.let { colIdx(it) } ?: -1
            if (c > col) {
                result = result.substring(0, m.range.first) + cell + result.substring(m.range.first)
                inserted = true
                break
            }
        }
        if (!inserted) {
            val end = result.lastIndexOf("</row>")
            result = if (end >= 0) result.substring(0, end) + cell + result.substring(end) else result
        }
    }
    return result
}

fun saveGrid(src: File, out: File, edits: Map<Pair<Int, Int>, String>) {
    ZipFile(src).use { z ->
        val sheetName = sheetEntryName(z)
        ZipOutputStream(FileOutputStream(out)).use { zo ->
            for (e in z.entries().toList()) {
                // calcChain lists the formula cells. A cell we replaced by a plain value would make Excel report a
                // damaged file, so the list is dropped (Excel rebuilds it) together with its two references.
                if (e.name == "xl/calcChain.xml") continue
                var bytes = z.getInputStream(e).readBytes()
                if (e.name == "[Content_Types].xml") {
                    bytes = String(bytes, Charsets.UTF_8).replace(Regex("<Override[^>]*calcChain[^>]*/>"), "").toByteArray(Charsets.UTF_8)
                } else if (e.name == "xl/_rels/workbook.xml.rels") {
                    bytes = String(bytes, Charsets.UTF_8).replace(Regex("<Relationship\\s[^>]*calcChain[^>]*/>"), "").toByteArray(Charsets.UTF_8)
                }
                if (e.name == sheetName) {
                    var xml = String(bytes, Charsets.UTF_8)
                    val byRow = edits.entries.groupBy({ it.key.first }, { it.key.second to it.value })
                    for ((rn, list) in byRow) {
                        val rx = Regex("<row[^>]*?\\sr=\"$rn\"[^>]*>.*?</row>", RegexOption.DOT_MATCHES_ALL)
                        val m = rx.find(xml) ?: continue
                        var row = m.value
                        for ((col, v) in list) row = setCellInRow(row, rn, col, v)
                        xml = xml.substring(0, m.range.first) + row + xml.substring(m.range.last + 1)
                    }
                    bytes = xml.toByteArray(Charsets.UTF_8)
                }
                zo.putNextEntry(ZipEntry(e.name))
                zo.write(bytes)
                zo.closeEntry()
            }
        }
    }
}

// ---------------- UI ----------------

@Composable
fun OfficeEditScreen(vm: AppViewModel, path: String) {
    val f = File(path)
    if (f.ext == "xlsx") SheetEditor(vm, f) else ParaEditor(vm, f)
}

@Composable
private fun ParaEditor(vm: AppViewModel, f: File) {
    val scope = rememberCoroutineScope()
    var paras by remember { mutableStateOf<List<ParaRef>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val texts = remember { mutableStateListOf<String>() }
    var saving by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    LaunchedEffect(f.path) {
        val r = withContext(Dispatchers.IO) { try { loadParas(f) } catch (e: Throwable) { error = e.message ?: "Cannot read file"; null } }
        if (r != null) {
            texts.clear()
            texts.addAll(r.map { it.original })
            paras = r
        }
    }
    val list = paras
    val dirty = list != null && list.indices.any { texts.getOrNull(it) != list[it].original }
    BackHandler(enabled = dirty) { discard = true }
    Column(Modifier.fillMaxSize()) {
        SimpleTop("Edit " + f.name, onBack = { if (dirty) discard = true else vm.pop() }) {
            TextButton(
                enabled = dirty && !saving,
                onClick = {
                    val l = list ?: return@TextButton
                    val edits = HashMap<Pair<String, Int>, String>()
                    l.forEachIndexed { i, p -> if (texts[i] != p.original) edits[Pair(p.entry, p.ordinal)] = texts[i] }
                    saving = true
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            try {
                                val out = uniqueFile(f.parentFile ?: vm.root, f.nameWithoutExtension + "_edited." + f.ext)
                                saveParas(f, out, edits)
                                out.name
                            } catch (e: Throwable) {
                                null
                            }
                        }
                        saving = false
                        vm.message = if (res != null) "Saved: $res" else "Could not save the file"
                        if (res != null) {
                            vm.refresh()
                            vm.pop()
                        }
                    }
                }
            ) { Text(if (saving) "Saving..." else "Save", fontWeight = FontWeight.Bold) }
        }
        Text(
            "Edit the text of each paragraph. Formatting, images and tables are kept. Saved as a new copy.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        when {
            error != null -> EmptyState(error ?: "")
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState("No editable text found in this file")
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(list) { i, p ->
                    Column {
                        if (p.label.isNotEmpty() && (i == 0 || list[i - 1].label != p.label)) {
                            Text(p.label, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
                        }
                        OutlinedTextField(
                            value = texts.getOrElse(i) { "" },
                            onValueChange = { if (i < texts.size) texts[i] = it },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
    if (discard) {
        AlertDialog(
            onDismissRequest = { discard = false },
            title = { Text("Discard edits?") },
            text = { Text("Your changes have not been saved.") },
            confirmButton = { TextButton(onClick = { discard = false; vm.pop() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } }
        )
    }
}

@Composable
private fun SheetEditor(vm: AppViewModel, f: File) {
    val scope = rememberCoroutineScope()
    var grid by remember { mutableStateOf<XGrid?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val edits = remember { mutableStateMapOf<Pair<Int, Int>, String>() }
    var editing by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var value by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    LaunchedEffect(f.path) {
        grid = withContext(Dispatchers.IO) { try { loadGrid(f) } catch (e: Throwable) { error = e.message ?: "Cannot read file"; null } }
    }
    val dirty = edits.isNotEmpty()
    BackHandler(enabled = dirty) { discard = true }
    Column(Modifier.fillMaxSize()) {
        SimpleTop("Edit " + f.name, onBack = { if (dirty) discard = true else vm.pop() }) {
            TextButton(
                enabled = dirty && !saving,
                onClick = {
                    val g = grid ?: return@TextButton
                    // map (rowIndex, col) -> (rowNumber, col)
                    val real = HashMap<Pair<Int, Int>, String>()
                    for ((k, v) in edits) real[Pair(g.rowNums[k.first], k.second)] = v
                    saving = true
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            try {
                                val out = uniqueFile(f.parentFile ?: vm.root, f.nameWithoutExtension + "_edited.xlsx")
                                saveGrid(f, out, real)
                                out.name
                            } catch (e: Throwable) {
                                null
                            }
                        }
                        saving = false
                        vm.message = if (res != null) "Saved: $res" else "Could not save the file"
                        if (res != null) {
                            vm.refresh()
                            vm.pop()
                        }
                    }
                }
            ) { Text(if (saving) "Saving..." else "Save", fontWeight = FontWeight.Bold) }
        }
        Text(
            "Tap a cell to change it. Saved as a new copy (first sheet only).",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        val g = grid
        when {
            error != null -> EmptyState(error ?: "")
            g == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                LazyColumn {
                    itemsIndexed(g.cells) { ri, row ->
                        Row {
                            Box(Modifier.width(36.dp).border(0.5.dp, MaterialTheme.colorScheme.outlineVariant).padding(6.dp)) {
                                Text("${g.rowNums[ri]}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            row.forEachIndexed { ci, c ->
                                val changed = edits.containsKey(Pair(ri, ci))
                                val shown = edits[Pair(ri, ci)] ?: c
                                Box(
                                    Modifier.width(120.dp).height(40.dp)
                                        .background(if (changed) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                        .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                                        .clickable { editing = Pair(ri, ci); value = shown }
                                        .padding(6.dp)
                                ) {
                                    Text(shown, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    val ed = editing
    if (ed != null) {
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Cell ${colName(ed.second)}${grid?.rowNums?.getOrNull(ed.first) ?: ""}") },
            text = { OutlinedTextField(value = value, onValueChange = { value = it }) },
            confirmButton = {
                TextButton(onClick = {
                    val orig = grid?.cells?.getOrNull(ed.first)?.getOrNull(ed.second) ?: ""
                    if (value == orig) edits.remove(ed) else edits[ed] = value
                    editing = null
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
    if (discard) {
        AlertDialog(
            onDismissRequest = { discard = false },
            title = { Text("Discard edits?") },
            text = { Text("Your changes have not been saved.") },
            confirmButton = { TextButton(onClick = { discard = false; vm.pop() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } }
        )
    }
}
