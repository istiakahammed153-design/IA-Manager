/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.io.SequenceInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.DigestInputStream
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.BadPaddingException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class WrongPassword(msg: String = "Wrong password") : Exception(msg)

/** [vpath] = virtual folder inside the vault ("" = top level), [vol] = storage root the encrypted file lives on. */
class VaultItem(
    val id: String, val name: String, val size: Long, val mtime: Long, val addedAt: Long,
    val dir: String, val vpath: String, val vol: String
)

// ---------------------------------------------------------------------------------------------
// scrypt (RFC 7914) - memory-hard password hashing, written out here so it works on every Android
// version without extra libraries. Verified against the RFC test vector (see Vault.selfTest()).
// ---------------------------------------------------------------------------------------------
private object Scrypt {
    private fun rl(a: Int, n: Int) = (a shl n) or (a ushr (32 - n))

    private fun pbkdf2c1(pw: ByteArray, salt: ByteArray, dkLen: Int): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(pw, "HmacSHA256"))
        val out = ByteArray(dkLen)
        var pos = 0
        var i = 1
        while (pos < dkLen) {
            m.update(salt)
            m.update(ByteBuffer.allocate(4).putInt(i).array())
            val t = m.doFinal()
            val n = minOf(t.size, dkLen - pos)
            System.arraycopy(t, 0, out, pos, n)
            pos += n
            i++
        }
        return out
    }

    private fun salsa8(b: IntArray) {
        val x = b.clone()
        for (round in 0 until 4) {
            x[4] = x[4] xor rl(x[0] + x[12], 7); x[8] = x[8] xor rl(x[4] + x[0], 9)
            x[12] = x[12] xor rl(x[8] + x[4], 13); x[0] = x[0] xor rl(x[12] + x[8], 18)
            x[9] = x[9] xor rl(x[5] + x[1], 7); x[13] = x[13] xor rl(x[9] + x[5], 9)
            x[1] = x[1] xor rl(x[13] + x[9], 13); x[5] = x[5] xor rl(x[1] + x[13], 18)
            x[14] = x[14] xor rl(x[10] + x[6], 7); x[2] = x[2] xor rl(x[14] + x[10], 9)
            x[6] = x[6] xor rl(x[2] + x[14], 13); x[10] = x[10] xor rl(x[6] + x[2], 18)
            x[3] = x[3] xor rl(x[15] + x[11], 7); x[7] = x[7] xor rl(x[3] + x[15], 9)
            x[11] = x[11] xor rl(x[7] + x[3], 13); x[15] = x[15] xor rl(x[11] + x[7], 18)
            x[1] = x[1] xor rl(x[0] + x[3], 7); x[2] = x[2] xor rl(x[1] + x[0], 9)
            x[3] = x[3] xor rl(x[2] + x[1], 13); x[0] = x[0] xor rl(x[3] + x[2], 18)
            x[6] = x[6] xor rl(x[5] + x[4], 7); x[7] = x[7] xor rl(x[6] + x[5], 9)
            x[4] = x[4] xor rl(x[7] + x[6], 13); x[5] = x[5] xor rl(x[4] + x[7], 18)
            x[11] = x[11] xor rl(x[10] + x[9], 7); x[8] = x[8] xor rl(x[11] + x[10], 9)
            x[9] = x[9] xor rl(x[8] + x[11], 13); x[10] = x[10] xor rl(x[9] + x[8], 18)
            x[12] = x[12] xor rl(x[15] + x[14], 7); x[13] = x[13] xor rl(x[12] + x[15], 9)
            x[14] = x[14] xor rl(x[13] + x[12], 13); x[15] = x[15] xor rl(x[14] + x[13], 18)
        }
        for (i in 0 until 16) b[i] += x[i]
    }

    private fun blockMix(b: IntArray, y: IntArray, r: Int) {
        val x = IntArray(16)
        System.arraycopy(b, (2 * r - 1) * 16, x, 0, 16)
        for (i in 0 until 2 * r) {
            for (k in 0 until 16) x[k] = x[k] xor b[i * 16 + k]
            salsa8(x)
            val dst = if (i % 2 == 0) (i / 2) * 16 else (r + i / 2) * 16
            System.arraycopy(x, 0, y, dst, 16)
        }
        System.arraycopy(y, 0, b, 0, 32 * r)
    }

    private fun roMix(b: IntArray, n: Int, r: Int) {
        val len = 32 * r
        val v = IntArray(len * n)
        val y = IntArray(len)
        for (i in 0 until n) {
            System.arraycopy(b, 0, v, i * len, len)
            blockMix(b, y, r)
        }
        for (i in 0 until n) {
            val j = b[(2 * r - 1) * 16] and (n - 1)
            for (k in 0 until len) b[k] = b[k] xor v[j * len + k]
            blockMix(b, y, r)
        }
    }

    fun derive(pw: ByteArray, salt: ByteArray, logN: Int, r: Int, p: Int, dkLen: Int): ByteArray {
        if (pw.isEmpty()) throw WrongPassword()
        val n = 1 shl logN
        val bl = 128 * r
        val b = pbkdf2c1(pw, salt, p * bl)
        for (i in 0 until p) {
            val x = IntArray(32 * r)
            val ib = ByteBuffer.wrap(b, i * bl, bl).order(ByteOrder.LITTLE_ENDIAN)
            for (k in x.indices) x[k] = ib.getInt()
            roMix(x, n, r)
            val ob = ByteBuffer.wrap(b, i * bl, bl).order(ByteOrder.LITTLE_ENDIAN)
            for (k in x.indices) ob.putInt(x[k])
        }
        val out = pbkdf2c1(pw, b, dkLen)
        b.fill(0)
        return out
    }
}

/*
 * IA MANAGER VAULT  -  design
 *
 *  Password --scrypt (N=32768, r=8, p=1: 32 MB of memory per guess, random 32-byte salt)--> KEK
 *  KEK wraps a random 256-bit Vault Master Key (VMK) with AES-256-GCM  ->  vault.hdr (+ .bak, + generation number)
 *  A one-time RECOVERY KEY (160 random bits) wraps the same VMK  ->  vault.rec
 *  Changing the password only re-wraps the VMK; the files are never re-encrypted.
 *
 *  Every file  ->  "<random>.iav": AES-256-GCM in 1 MiB chunks, a fresh key per file (HMAC(VMK, salt)),
 *  nonce = random prefix + chunk counter + "last chunk" flag, header bound as AAD. Any change, truncation,
 *  reordering or wrong key makes decryption fail. Real name, folder, size and date are stored INSIDE the
 *  encrypted stream, so the vault folder reveals nothing but random names and sizes.
 *
 *  Each storage (internal / SD card) has its OWN ".IAVault" folder holding its encrypted files, its own
 *  encrypted index and a copy of the (tiny) header. Data from the SD card therefore stays on the SD card:
 *  encrypting, viewing (temporary copy goes to the SD card's own app cache) and restoring never use
 *  internal storage, and an SD card can be moved to another phone together with its vault.
 *
 *  The password is never stored. Nothing readable is ever written to shared storage.
 */
object Vault {
    const val DIR = ".IAVault"
    internal const val CHUNK = 1 shl 20
    internal const val TAG = 16
    private const val LOGN = 15
    private const val SC_R = 8
    private const val SC_P = 1
    private const val HDR_LEN = 105
    private const val AAD_LEN = 45
    private val MAGIC_H = "IAVH".toByteArray()
    private val MAGIC_R = "IAVR".toByteArray()
    internal val MAGIC_F = "IAVF".toByteArray()
    private val rnd = SecureRandom()
    private const val ALIAS = "iamanager_vault_bio"
    private const val B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    private lateinit var prefs: SharedPreferences
    private lateinit var appCtx: Context
    @Volatile private var roots: List<File> = emptyList()
    @Volatile private var tmpRoots: List<File> = emptyList()

    var exists by mutableStateOf(false)
        private set
    var unlocked by mutableStateOf(false)
        private set
    var items by mutableStateOf<List<VaultItem>>(emptyList())
        private set
    /** Set right after a recovery key is created; the UI shows it once and then clears it. */
    var pendingRecovery by mutableStateOf<String?>(null)

    private var vmk: ByteArray? = null
    private var stoppedAt = 0L

    fun dirOf(root: File) = File(root, DIR)
    private fun primary() = roots.first()

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        prefs = appCtx.getSharedPreferences("ia_vault", Context.MODE_PRIVATE)
        roots = listOf(Environment.getExternalStorageDirectory())
        computeTmpRoots()
        wipeTemp()
        refreshExists()
    }

    /** Tell the vault which storages exist (internal first, then SD cards / USB). */
    fun setVolumes(list: List<File>) {
        if (!::appCtx.isInitialized || list.isEmpty()) return
        roots = list.distinctBy { it.path }
        computeTmpRoots()
        refreshExists()
    }

    fun refreshExists() {
        exists = roots.any { File(dirOf(it), "vault.hdr").exists() || File(dirOf(it), "vault.hdr.bak").exists() }
    }

    fun volumeOf(f: File): File =
        roots.filter { f.path == it.path || f.path.startsWith(it.path + "/") }.maxByOrNull { it.path.length } ?: primary()

    // ---------------- temp copies for viewing (always on the SAME storage as the item) ----------------
    private fun computeTmpRoots() {
        val l = ArrayList<File>()
        l += File(appCtx.cacheDir, "vaultview")
        try {
            ContextCompat.getExternalCacheDirs(appCtx).filterNotNull().forEach { l += File(it, "vaultview") }
        } catch (e: Exception) {
        }
        tmpRoots = l
    }

    private fun tempRootFor(vol: File): File {
        if (vol.path == primary().path) return File(appCtx.cacheDir, "vaultview")
        val ext = try {
            ContextCompat.getExternalCacheDirs(appCtx).filterNotNull().firstOrNull { it.path.startsWith(vol.path + "/") }
        } catch (e: Exception) {
            null
        } ?: throw IOException("Cannot open this file: the SD card's app cache is not available, and SD-card data never uses internal storage.")
        return File(ext, "vaultview")
    }

    fun isTemp(path: String) = tmpRoots.any { path.startsWith(it.path + "/") }

    fun isVaultPath(path: String): Boolean = roots.any {
        val p = dirOf(it).path
        path == p || path.startsWith("$p/")
    }

    fun wipeTemp() {
        tmpRoots.forEach { try { it.deleteRecursively() } catch (e: Exception) { } }
    }

    // ---------------- session ----------------
    fun lock() {
        vmk?.fill(0)
        vmk = null
        unlocked = false
        items = emptyList()
        wipeTemp()
        // decoded pictures of vault images must not survive in the image cache after the vault is locked
        try { if (::appCtx.isInitialized) Loader.get(appCtx).memoryCache?.clear() } catch (e: Throwable) { }
    }

    /** A private copy of the key for a background operation; the caller must zero it when done. */
    fun keyCopy(): ByteArray? = vmk?.copyOf()

    fun lockTimeoutMs(): Long = if (::prefs.isInitialized) prefs.getLong("lock_ms", 0L) else 0L
    fun setLockTimeoutMs(ms: Long) { prefs.edit().putLong("lock_ms", ms).apply() }

    /** App left the foreground: decrypted view copies are always wiped; the vault locks now or after the chosen delay. */
    /** True while the full-screen player (a separate Activity) shows a decrypted vault file: the main screen going to the
     *  background is then expected and must NOT wipe the file being played or lock the vault. The player clears it and calls
     *  [onBackground] itself if the user really leaves the app. */
    @Volatile var childActive = false

    fun onBackground() {
        if (childActive) return
        wipeTemp()
        if (lockTimeoutMs() == 0L) lock() else stoppedAt = System.currentTimeMillis()
    }

    fun onForeground() {
        if (stoppedAt > 0 && unlocked && System.currentTimeMillis() - stoppedAt > lockTimeoutMs()) lock()
        stoppedAt = 0
    }

    // ---------------- brute-force throttle ----------------
    fun lockedForMs(): Long = if (::prefs.isInitialized) maxOf(0L, prefs.getLong("until", 0L) - System.currentTimeMillis()) else 0L

    private fun recordFail() {
        val f = prefs.getInt("fails", 0) + 1
        var until = 0L
        if (f >= 5) until = System.currentTimeMillis() + (30_000L shl minOf(f - 5, 6))
        prefs.edit().putInt("fails", f).putLong("until", until).commit()
    }

    private fun recordOk() { prefs.edit().putInt("fails", 0).putLong("until", 0L).commit() }

    // ---------------- helpers ----------------
    private fun hmac(key: ByteArray, vararg parts: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        parts.forEach { m.update(it) }
        return m.doFinal()
    }

    private fun rndBytes(n: Int) = ByteArray(n).also { rnd.nextBytes(it) }
    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun readFully(i: InputStream, b: ByteArray, len: Int = b.size): Int {
        var n = 0
        while (n < len) {
            val r = i.read(b, n, len - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun writeAtomic(target: File, data: ByteArray) {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".tmp")
        FileOutputStream(tmp).use { it.write(data); it.fd.sync() }
        if (!tmp.renameTo(target)) {
            target.delete()
            if (!tmp.renameTo(target)) throw IOException("Could not write ${target.name}")
        }
    }

    // ---------------- recovery key text ----------------
    private fun b32enc(b: ByteArray): String {
        val sb = StringBuilder()
        var buf = 0
        var bits = 0
        for (x in b) {
            buf = (buf shl 8) or (x.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(B32[(buf ushr (bits - 5)) and 31])
                bits -= 5
            }
            buf = buf and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(B32[(buf shl (5 - bits)) and 31])
        return sb.toString()
    }

    private fun b32dec(s: String): ByteArray? {
        val out = ByteArrayOutputStream()
        var buf = 0
        var bits = 0
        for (c in s) {
            val v = B32.indexOf(c)
            if (v < 0) return null
            buf = (buf shl 5) or v
            bits += 5
            if (bits >= 8) {
                out.write((buf ushr (bits - 8)) and 0xFF)
                bits -= 8
            }
            buf = buf and ((1 shl bits) - 1)
        }
        return out.toByteArray()
    }

    private fun formatRecovery(k: ByteArray) = b32enc(k).chunked(4).joinToString("-")

    private fun parseRecovery(s: String): ByteArray? {
        val clean = s.uppercase().filter { it in B32 }
        val b = b32dec(clean) ?: return null
        return if (b.size == 20 && clean.length == 32) b else null
    }

    fun generatePassword(): String {
        val alpha = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val chars = (0 until 20).map { alpha[rnd.nextInt(alpha.length)] }.joinToString("")
        return chars.chunked(5).joinToString("-")
    }

    // ---------------- header (password) ----------------
    private class Hdr(val bytes: ByteArray, val gen: Int)

    private fun parseHdr(d: ByteArray): Hdr? {
        if (d.size != HDR_LEN || !d.copyOfRange(0, 4).contentEquals(MAGIC_H) || d[4].toInt() != 2 || d[5].toInt() != 3) return null
        val logN = d[10].toInt()
        val r = d[11].toInt()
        val p = d[12].toInt()
        if (logN !in 10..20 || r !in 1..16 || p !in 1..4) return null
        if (128L * r * (1L shl logN) > (128L shl 20)) return null   // refuse absurd memory use from a tampered header
        return Hdr(d, ByteBuffer.wrap(d, 6, 4).int)
    }

    private fun readHdrFile(f: File): Hdr? = try {
        if (f.exists()) parseHdr(f.readBytes()) else null
    } catch (e: Exception) {
        null
    }

    /** The header with the highest generation across all storages (old copies on an SD card can never win). */
    private fun bestHeader(): Hdr? = roots.flatMap { r ->
        listOf(readHdrFile(File(dirOf(r), "vault.hdr")), readHdrFile(File(dirOf(r), "vault.hdr.bak")))
    }.filterNotNull().maxByOrNull { it.gen }

    private fun buildHeader(master: ByteArray, password: String, gen: Int): ByteArray {
        val salt = rndBytes(32)
        val head = ByteBuffer.allocate(AAD_LEN).put(MAGIC_H).put(2.toByte()).put(3.toByte()).putInt(gen)
            .put(LOGN.toByte()).put(SC_R.toByte()).put(SC_P.toByte()).put(salt).array()
        val kek = Scrypt.derive(password.toByteArray(Charsets.UTF_8), salt, LOGN, SC_R, SC_P, 32)
        val nonce = rndBytes(12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(kek, "AES"), GCMParameterSpec(128, nonce))
        c.updateAAD(head)
        val wrapped = c.doFinal(master)
        kek.fill(0)
        return head + nonce + wrapped
    }

    private fun openHeader(h: Hdr, password: String): ByteArray {
        val d = h.bytes
        val salt = d.copyOfRange(13, 45)
        val nonce = d.copyOfRange(45, 57)
        val wrapped = d.copyOfRange(57, 105)
        val kek = Scrypt.derive(password.toByteArray(Charsets.UTF_8), salt, d[10].toInt(), d[11].toInt(), d[12].toInt(), 32)
        try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(kek, "AES"), GCMParameterSpec(128, nonce))
            c.updateAAD(d, 0, AAD_LEN)
            return c.doFinal(wrapped)
        } catch (e: BadPaddingException) {
            throw WrongPassword()
        } finally {
            kek.fill(0)
        }
    }

    /** Volumes that already hold a vault folder (the internal one is always included). */
    private fun presentRoots(): List<File> = roots.filter { it.path == primary().path || dirOf(it).isDirectory }

    private fun writeHeaders(bytes: ByteArray) {
        for (r in presentRoots()) {
            try {
                val d = dirOf(r)
                writeAtomic(File(d, "vault.hdr"), bytes)
                writeAtomic(File(d, "vault.hdr.bak"), bytes)
                try { File(d, ".nomedia").createNewFile() } catch (e: Exception) { }
            } catch (e: IOException) {
                if (r.path == primary().path) throw e   // an unplugged / read-only SD card is not fatal
            }
        }
    }

    // ---------------- recovery wrap ----------------
    private fun recKek(key: ByteArray) = SecretKeySpec(hmac(key, "IAV recovery kek".toByteArray()), "AES")

    private fun buildRec(master: ByteArray, key: ByteArray): ByteArray {
        val nonce = rndBytes(12)
        val head = MAGIC_R + byteArrayOf(1)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, recKek(key), GCMParameterSpec(128, nonce))
        c.updateAAD(head)
        return head + nonce + c.doFinal(master)
    }

    private fun openRec(d: ByteArray, key: ByteArray): ByteArray? {
        if (d.size != 65 || !d.copyOfRange(0, 4).contentEquals(MAGIC_R)) return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, recKek(key), GCMParameterSpec(128, d, 5, 12))
            c.updateAAD(d, 0, 5)
            c.doFinal(d, 17, 48)
        } catch (e: Exception) {
            null
        }
    }

    private fun writeRec(bytes: ByteArray) {
        for (r in presentRoots()) {
            try { writeAtomic(File(dirOf(r), "vault.rec"), bytes) } catch (e: IOException) { if (r.path == primary().path) throw e }
        }
    }

    private fun allRecs(): List<ByteArray> = roots.mapNotNull { r ->
        try { File(dirOf(r), "vault.rec").takeIf { it.exists() }?.readBytes() } catch (e: Exception) { null }
    }

    private fun newestRec(): ByteArray? = roots.map { File(dirOf(it), "vault.rec") }.filter { it.exists() }
        .maxByOrNull { it.lastModified() }?.let { try { it.readBytes() } catch (e: Exception) { null } }

    // ---------------- create / unlock / password / recovery ----------------
    /** Runs known-answer tests of the KDF and the file format on THIS device. Returns null if everything is fine. */
    fun selfTest(): String? {
        try {
            val dk = Scrypt.derive("password".toByteArray(), "NaCl".toByteArray(), 10, 8, 16, 64)
            if (hex(dk) != "fdbabe1c9d3472007856e7190d01e9fe7c6ad7cbc8237830e77376634b3731622eaf30d92e22a3886ff109279d9830dac727afb94a83ee6d8360cbdfa2cc0640") {
                return "Key-derivation self-test failed"
            }
            val master = ByteArray(32) { it.toByte() }
            val metaJson = JSONObject().put("n", "t").put("s", 0L).put("m", 0L).put("t", 0L).put("d", "").put("r", "").toString().toByteArray()
            val metaBlock = ByteBuffer.allocate(4 + metaJson.size).putInt(metaJson.size).put(metaJson).array()
            for (size in intArrayOf(0, 1, CHUNK - 1, CHUNK, CHUNK + 1, 2 * CHUNK + 5)) {
                val data = rndBytes(size)
                val enc = ByteArrayOutputStream()
                encryptStream(master, SequenceInputStream(ByteArrayInputStream(metaBlock), ByteArrayInputStream(data)), enc)
                val encBytes = enc.toByteArray()
                val out = ByteArrayOutputStream()
                decryptStream(master, ByteArrayInputStream(encBytes), out, null, null)
                if (!out.toByteArray().contentEquals(data)) return "Encryption self-test failed (size $size)"
                if (size == CHUNK || size == 1) {
                    val bad = encBytes.copyOf()
                    bad[bad.size / 2] = (bad[bad.size / 2].toInt() xor 1).toByte()
                    try { decryptStream(master, ByteArrayInputStream(bad), null, null, null); return "Tamper test failed" } catch (e: IOException) { }
                    val cut = encBytes.copyOf(encBytes.size - 1)
                    try { decryptStream(master, ByteArrayInputStream(cut), null, null, null); return "Truncation test failed" } catch (e: IOException) { }
                }
            }
            return null
        } catch (e: Throwable) {
            return "Self-test error: ${e.message}"
        }
    }

    fun create(password: String) {
        if (exists) throw IOException("A vault already exists")
        selfTest()?.let { throw IOException("$it. The Vault was NOT created on this device.") }
        val master = rndBytes(32)
        val recKey = rndBytes(20)
        try {
            primary().let { dirOf(it).mkdirs() }
            writeHeaders(buildHeader(master, password, 1))
            writeRec(buildRec(master, recKey))
            saveIndex(primary(), master, emptyList())
        } catch (e: Throwable) {
            master.fill(0)
            throw e
        }
        exists = true
        vmk = master
        items = emptyList()
        unlocked = true
        recordOk()
        pendingRecovery = formatRecovery(recKey)
        recKey.fill(0)
    }

    fun unlock(password: String) {
        if (lockedForMs() > 0) throw IOException("Too many attempts. Please wait.")
        val h = bestHeader() ?: throw IOException("Vault header not found or damaged")
        val master = try {
            openHeader(h, password)
        } catch (e: WrongPassword) {
            recordFail()
            throw e
        }
        recordOk()
        finishUnlock(master)
    }

    private fun finishUnlock(master: ByteArray) {
        vmk = master
        items = loadAll(master)
        unlocked = true
        try { syncVolumes() } catch (e: Exception) { }
    }

    /** Copies the newest header / recovery file to every storage that has a vault folder. */
    private fun syncVolumes() {
        val best = bestHeader() ?: return
        val rec = newestRec()
        for (r in presentRoots()) {
            val d = dirOf(r)
            val cur = readHdrFile(File(d, "vault.hdr"))
            if (cur == null || cur.gen < best.gen) {
                writeAtomic(File(d, "vault.hdr"), best.bytes)
                writeAtomic(File(d, "vault.hdr.bak"), best.bytes)
            }
            if (rec != null) {
                val rf = File(d, "vault.rec")
                if (!rf.exists() || !rf.readBytes().contentEquals(rec)) writeAtomic(rf, rec)
            }
        }
    }

    fun changePassword(old: String, new: String) {
        val h = bestHeader() ?: throw IOException("Vault header not found")
        val master = try {
            openHeader(h, old)
        } catch (e: WrongPassword) {
            recordFail()
            throw e
        }
        try {
            writeHeaders(buildHeader(master, new, h.gen + 1))
        } finally {
            master.fill(0)
        }
    }

    /** Forgot the password: the recovery key opens the vault and sets a new password. */
    fun resetWithRecovery(code: String, newPassword: String) {
        if (lockedForMs() > 0) throw IOException("Too many attempts. Please wait.")
        val key = parseRecovery(code) ?: throw WrongPassword("That is not a valid recovery key")
        var master: ByteArray? = null
        for (r in allRecs()) {
            master = openRec(r, key)
            if (master != null) break
        }
        key.fill(0)
        if (master == null) {
            recordFail()
            throw WrongPassword("Wrong recovery key")
        }
        val gen = (bestHeader()?.gen ?: 0) + 1
        try {
            writeHeaders(buildHeader(master, newPassword, gen))
        } catch (e: Throwable) {
            master.fill(0)
            throw e
        }
        recordOk()
        finishUnlock(master)
    }

    /** While unlocked: makes a NEW recovery key (the old one stops working) and queues it for display. */
    fun newRecoveryKey() {
        val m = vmk ?: throw IOException("Unlock the vault first")
        val key = rndBytes(20)
        writeRec(buildRec(m, key))
        pendingRecovery = formatRecovery(key)
        key.fill(0)
    }

    /** Permanently erases the vault on every storage (used when both password and recovery key are lost). */
    fun destroy() {
        lock()
        roots.forEach { r ->
            val d = dirOf(r)
            d.listFiles()?.forEach { it.delete() }
            d.delete()
        }
        clearBio()
        exists = false
    }

    // ---------------- index (one per storage) ----------------
    private fun idxKey(master: ByteArray) = SecretKeySpec(hmac(master, "IAV index key".toByteArray()), "AES")

    private fun toJson(list: List<VaultItem>): ByteArray {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("i", it.id).put("n", it.name).put("s", it.size).put("m", it.mtime)
                    .put("t", it.addedAt).put("d", it.dir).put("r", it.vpath)
            )
        }
        return a.toString().toByteArray(Charsets.UTF_8)
    }

    private fun fromJson(b: ByteArray, vol: String): List<VaultItem> {
        val a = JSONArray(String(b, Charsets.UTF_8))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            VaultItem(o.getString("i"), o.getString("n"), o.getLong("s"), o.getLong("m"), o.getLong("t"), o.optString("d", ""), o.optString("r", ""), vol)
        }
    }

    @Synchronized
    private fun saveIndex(root: File, master: ByteArray, list: List<VaultItem>) {
        val nonce = rndBytes(12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, idxKey(master), GCMParameterSpec(128, nonce))
        c.updateAAD("IAV-INDEX".toByteArray())
        val data = nonce + c.doFinal(toJson(list))
        val d = dirOf(root)
        d.mkdirs()
        val idx = File(d, "vault.idx")
        val bak = File(d, "vault.idx.bak")
        val tmp = File(d, "vault.idx.tmp")
        FileOutputStream(tmp).use { it.write(data); it.fd.sync() }
        if (idx.exists()) { bak.delete(); idx.renameTo(bak) }
        if (!tmp.renameTo(idx)) throw IOException("Could not save the vault index")
    }

    private fun readIndexFile(f: File, master: ByteArray, vol: String): List<VaultItem>? = try {
        if (!f.exists()) {
            null
        } else {
            val d = f.readBytes()
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, idxKey(master), GCMParameterSpec(128, d, 0, 12))
            c.updateAAD("IAV-INDEX".toByteArray())
            fromJson(c.doFinal(d, 12, d.size - 12), vol)
        }
    } catch (e: Exception) {
        null
    }

    /** Loads one storage's index and reconciles it with the .iav files really on that storage (crash / damage safe). */
    @Synchronized
    private fun loadIndex(root: File, master: ByteArray, skipId: String? = null): List<VaultItem> {
        val d = dirOf(root)
        val onDisk = (d.listFiles() ?: emptyArray())
            .filter { it.isFile && it.name.endsWith(".iav") && !it.name.startsWith(".") }
            .associateBy { it.name.removeSuffix(".iav") }
        var list = readIndexFile(File(d, "vault.idx"), master, root.path)
            ?: readIndexFile(File(d, "vault.idx.bak"), master, root.path)
            ?: emptyList()
        var changed = false
        val known = list.map { it.id }.toHashSet()
        list = list.filter { (it.id in onDisk).also { ok -> if (!ok) changed = true } }
        val extra = ArrayList<VaultItem>()
        for ((id, f) in onDisk) {
            if (id in known || id == skipId) continue   // skipId = the file being added right now (its entry is added by the caller)
            val m = try { readMeta(master, f) } catch (e: Exception) { null } ?: continue
            extra += VaultItem(id, m.name, m.size, m.mtime, m.addedAt, m.dir, m.vpath, root.path)
            changed = true
        }
        list = (list + extra).sortedByDescending { it.addedAt }
        if (changed) try { saveIndex(root, master, list) } catch (e: Exception) { }
        return list
    }

    private fun loadAll(master: ByteArray): List<VaultItem> =
        roots.filter { dirOf(it).isDirectory }.flatMap { loadIndex(it, master) }.sortedByDescending { it.addedAt }

    /** Re-reads every storage (e.g. after an SD card was inserted). Call off the main thread. */
    fun reload() {
        val m = keyCopy() ?: return
        try {
            val l = loadAll(m)
            if (unlocked) items = l
        } finally {
            m.fill(0)
        }
    }

    @Synchronized
    private fun indexAdd(master: ByteArray, item: VaultItem) {
        val root = File(item.vol)
        val cur = loadIndex(root, master, item.id).filter { it.id != item.id }
        saveIndex(root, master, (cur + item).sortedByDescending { it.addedAt })
        if (unlocked) items = (items.filter { it.id != item.id } + item).sortedByDescending { it.addedAt }
    }

    @Synchronized
    private fun indexRemove(master: ByteArray, item: VaultItem) {
        val root = File(item.vol)
        saveIndex(root, master, loadIndex(root, master).filter { it.id != item.id })
        if (unlocked) items = items.filter { it.id != item.id }
    }

    // ---------------- file encryption ----------------
    internal fun fileKey(master: ByteArray, salt: ByteArray) = SecretKeySpec(hmac(master, "IAV file key".toByteArray(), salt), "AES")

    internal fun nonceFor(prefix: ByteArray, idx: Int, last: Boolean): ByteArray {
        val n = ByteArray(12)
        System.arraycopy(prefix, 0, n, 0, 7)
        n[7] = (idx ushr 24).toByte(); n[8] = (idx ushr 16).toByte(); n[9] = (idx ushr 8).toByte(); n[10] = idx.toByte()
        n[11] = if (last) 1 else 0
        return n
    }

    private fun encryptStream(master: ByteArray, plain: InputStream, out: OutputStream) {
        val salt = rndBytes(16)
        val prefix = rndBytes(7)
        val head = ByteBuffer.allocate(32).put(MAGIC_F).put(1.toByte()).put(salt).put(prefix).putInt(CHUNK).array()
        out.write(head)
        val key = fileKey(master, salt)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        var cur = ByteArray(CHUNK)
        var nxt = ByteArray(CHUNK)
        var n = readFully(plain, cur)
        var idx = 0
        while (true) {
            val m = if (n == CHUNK) readFully(plain, nxt) else 0
            val last = n < CHUNK || m == 0
            c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonceFor(prefix, idx, last)))
            c.updateAAD(head)
            out.write(c.doFinal(cur, 0, n))
            if (last) break
            idx++
            val t = cur; cur = nxt; nxt = t
            n = m
        }
        cur.fill(0); nxt.fill(0)
    }

    internal class Meta(val name: String, val size: Long, val mtime: Long, val addedAt: Long, val dir: String, val vpath: String)

    internal fun parseMeta(plain: ByteArray): Pair<Meta, Int> {
        if (plain.size < 4) throw IOException("Vault file is damaged")
        val ml = ByteBuffer.wrap(plain, 0, 4).int
        if (ml < 0 || ml > 65536 || 4 + ml > plain.size) throw IOException("Vault file is damaged")
        val o = JSONObject(String(plain, 4, ml, Charsets.UTF_8))
        return Pair(Meta(o.getString("n"), o.getLong("s"), o.getLong("m"), o.optLong("t", 0L), o.optString("d", ""), o.optString("r", "")), 4 + ml)
    }

    /**
     * Decrypts a whole .iav file. The first bytes of the plain stream are the (encrypted) metadata,
     * the rest is the file content, which goes to [out] (may be null) and into [md] (may be null).
     */
    private fun decryptStream(master: ByteArray, inp: InputStream, out: OutputStream?, md: MessageDigest?, op: OpState?): Meta {
        val head = ByteArray(32)
        if (readFully(inp, head) != 32 || !head.copyOfRange(0, 4).contentEquals(MAGIC_F)) throw IOException("Not a vault file")
        val salt = head.copyOfRange(5, 21)
        val prefix = head.copyOfRange(21, 28)
        if (ByteBuffer.wrap(head, 28, 4).int != CHUNK) throw IOException("Unsupported vault file")
        val key = fileKey(master, salt)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        val full = CHUNK + TAG
        var cur = ByteArray(full)
        var nxt = ByteArray(full)
        var n = readFully(inp, cur)
        var idx = 0
        var meta: Meta? = null
        while (true) {
            op?.checkCancel()
            if (n < TAG) throw IOException("Vault file is damaged")
            val m = if (n == full) readFully(inp, nxt) else 0
            val last = n < full || m == 0
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonceFor(prefix, idx, last)))
            c.updateAAD(head)
            val plain = try {
                c.doFinal(cur, 0, n)
            } catch (e: BadPaddingException) {
                throw IOException("Vault file is damaged or the key is wrong")
            }
            var off = 0
            if (idx == 0) {
                val (mm, o) = parseMeta(plain)
                meta = mm
                off = o
            }
            val len = plain.size - off
            if (len > 0) {
                out?.write(plain, off, len)
                md?.update(plain, off, len)
                op?.addBytes(len.toLong())
            }
            plain.fill(0)
            if (last) break
            idx++
            val t = cur; cur = nxt; nxt = t
            n = m
        }
        cur.fill(0); nxt.fill(0)
        return meta ?: throw IOException("Vault file is damaged")
    }

    /** Reads only the metadata (first chunk) of a .iav file. */
    private fun readMeta(master: ByteArray, f: File): Meta {
        val head = ByteArray(32)
        FileInputStream(f).use { inp ->
            if (readFully(inp, head) != 32 || !head.copyOfRange(0, 4).contentEquals(MAGIC_F)) throw IOException("Not a vault file")
            val first = ByteArray(CHUNK + TAG)
            val n = readFully(inp, first)
            val last = f.length() - 32 <= CHUNK + TAG
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(
                Cipher.DECRYPT_MODE, fileKey(master, head.copyOfRange(5, 21)),
                GCMParameterSpec(128, nonceFor(head.copyOfRange(21, 28), 0, last))
            )
            c.updateAAD(head)
            return parseMeta(c.doFinal(first, 0, n)).first
        }
    }

    private class CountIn(val i: InputStream, val op: OpState?) : InputStream() {
        override fun read(): Int { val b = ByteArray(1); return if (read(b, 0, 1) < 0) -1 else b[0].toInt() and 0xFF }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            op?.checkCancel()
            val n = i.read(b, off, len)
            if (n > 0) op?.addBytes(n.toLong())
            return n
        }
        override fun close() = i.close()
    }

    private fun ensureVolume(vol: File) {
        val d = dirOf(vol)
        d.mkdirs()
        if (!d.isDirectory) throw IOException("Cannot write to ${vol.name}")
        try { File(d, ".nomedia").createNewFile() } catch (e: Exception) { }
        if (vol.path != primary().path) {
            val best = bestHeader()
            val cur = readHdrFile(File(d, "vault.hdr"))
            if (best != null && (cur == null || cur.gen < best.gen)) {
                writeAtomic(File(d, "vault.hdr"), best.bytes)
                writeAtomic(File(d, "vault.hdr.bak"), best.bytes)
            }
            val rec = newestRec()
            if (rec != null && !File(d, "vault.rec").exists()) writeAtomic(File(d, "vault.rec"), rec)
        }
    }

    /**
     * Encrypts [src] into the vault of the storage it lives on, then DECRYPTS IT AGAIN and compares a SHA-256 with
     * the original. Only a verified copy is kept; on any problem the temp file is removed and the original is untouched.
     */
    fun addFile(master: ByteArray, src: File, vpath: String, op: OpState?): VaultItem {
        if (!src.isFile) throw IOException("${src.name} is not a file")
        val vol = volumeOf(src)
        ensureVolume(vol)
        val d = dirOf(vol)
        val free = d.usableSpace
        if (free > 0 && free < src.length() + (16L shl 20)) throw IOException("Not enough free space on ${vol.name} for ${src.name}")
        val id = hex(rndBytes(16))
        val dest = File(d, "$id.iav")
        val tmp = File(d, ".$id.iapart")
        val size = src.length()
        val now = System.currentTimeMillis()
        val parent = src.parentFile?.path ?: ""
        val meta = JSONObject().put("n", src.name).put("s", size).put("m", src.lastModified()).put("t", now)
            .put("d", parent).put("r", vpath).toString().toByteArray(Charsets.UTF_8)
        val metaBlock = ByteBuffer.allocate(4 + meta.size).putInt(meta.size).put(meta).array()
        Ops.registerTmp(tmp)   // removed at the next start if the phone kills the app half way
        try {
            op?.phase = "Encrypting"
            val md = MessageDigest.getInstance("SHA-256")
            FileInputStream(src).use { fin ->
                val plain = SequenceInputStream(ByteArrayInputStream(metaBlock), CountIn(DigestInputStream(fin, md), op))
                FileOutputStream(tmp).use { fos ->
                    encryptStream(master, plain, fos)
                    fos.fd.sync()
                }
            }
            if (src.length() != size) throw IOException("${src.name} changed while it was being encrypted")
            val want = md.digest()
            val md2 = MessageDigest.getInstance("SHA-256")
            op?.phase = "Verifying"
            FileInputStream(tmp).use { decryptStream(master, it, null, md2, op) }
            if (!want.contentEquals(md2.digest())) throw IOException("Verification failed for ${src.name}. Nothing was changed.")
            if (!tmp.renameTo(dest)) throw IOException("Could not finish writing the vault file")
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            Ops.unregisterTmp(tmp)
        }
        val item = VaultItem(id, src.name, size, src.lastModified(), now, parent, vpath, vol.path)
        indexAdd(master, item)
        return item
    }

    /** Overwrites the original with random data, then deletes it. (Best effort: flash storage may keep old blocks.) */
    fun shred(f: File, op: OpState? = null) {
        try {
            RandomAccessFile(f, "rw").use { raf ->
                val blk = rndBytes(1 shl 20)
                var left = raf.length()
                raf.seek(0)
                while (left > 0) {
                    val n = minOf(left, blk.size.toLong()).toInt()
                    raf.write(blk, 0, n)
                    left -= n
                    op?.addBytes(n.toLong())   // the wipe is part of the progress, so the bar does not "freeze" at the end
                }
                raf.fd.sync()
            }
        } catch (e: Exception) {
        }
        if (!f.delete() && f.exists()) throw IOException("The encrypted copy is safe in the vault, but the original ${f.name} could not be deleted")
    }

    private fun safeName(n: String) = n.replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_").ifBlank { "file" }

    private fun fileOf(item: VaultItem) = File(dirOf(File(item.vol)), item.id + ".iav")

    /** Decrypts [item] into the app cache OF THE SAME STORAGE (SD card items never touch internal storage). */
    fun decryptToTemp(master: ByteArray, item: VaultItem, op: OpState?): File {
        val src = fileOf(item)
        if (!src.exists()) throw IOException("Vault file is missing (is the SD card inserted?)")
        val root = tempRootFor(File(item.vol))
        val d = File(root, hex(rndBytes(6)))
        d.mkdirs()
        val free = d.usableSpace
        if (free > 0 && free < item.size + (16L shl 20)) { d.deleteRecursively(); throw IOException("Not enough free space to open this file") }
        val out = File(d, safeName(item.name))
        try {
            FileInputStream(src).use { i -> FileOutputStream(out).use { o -> decryptStream(master, i, o, null, op) } }
        } catch (e: Throwable) {
            d.deleteRecursively()
            throw e
        }
        return out
    }

    /** Decrypts [item] back into [destDir] (temp file, size check, then rename). */
    fun exportFile(master: ByteArray, item: VaultItem, destDir: File, op: OpState?): File {
        val src = fileOf(item)
        if (!src.exists()) throw IOException("Vault file is missing (is the SD card inserted?)")
        destDir.mkdirs()
        val free = destDir.usableSpace
        if (free > 0 && free < item.size + (16L shl 20)) throw IOException("Not enough free space in ${destDir.name}")
        val dest = uniqueFile(destDir, safeName(item.name))
        val tmp = File(destDir, "." + dest.name + ".iapart")
        Ops.registerTmp(tmp)
        try {
            op?.phase = "Decrypting"
            var meta: Meta? = null
            FileInputStream(src).use { i -> FileOutputStream(tmp).use { o -> meta = decryptStream(master, i, o, null, op); o.fd.sync() } }
            val m = meta ?: throw IOException("Vault file is damaged")
            if (tmp.length() != m.size) throw IOException("Restored size does not match for ${item.name}")
            if (!tmp.renameTo(dest)) throw IOException("Could not finish writing ${dest.name}")
            dest.setLastModified(m.mtime)
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        } finally {
            Ops.unregisterTmp(tmp)
        }
        return dest
    }

    /** Fully decrypts (and so authenticates) an item without writing anything. Throws if it is damaged. */
    fun verifyItem(master: ByteArray, item: VaultItem, op: OpState?) {
        val f = fileOf(item)
        if (!f.exists()) throw IOException("file is missing")
        FileInputStream(f).use { decryptStream(master, it, null, null, op) }
    }

    fun deleteItem(master: ByteArray, item: VaultItem) {
        val f = fileOf(item)
        if (f.exists() && !f.delete() && f.exists()) throw IOException("Could not delete ${item.name}")
        indexRemove(master, item)
    }

    // ---------------- streaming (video / audio): decrypted in memory only, never written to disk ----------------
    /**
     * Random-access reader over one ".iav" file. It decrypts only the 1 MiB chunk that is asked for and keeps that
     * single chunk in memory, so a movie starts at once, seeking is instant, and no readable copy ever touches the disk.
     * Every chunk is authenticated (AES-GCM), so a damaged or tampered file fails instead of playing garbage.
     */
    class StreamReader internal constructor(file: File, master: ByteArray) : java.io.Closeable {
        private val raf = RandomAccessFile(file, "r")
        private val head = ByteArray(32)
        private var key = SecretKeySpec(ByteArray(32), "AES")
        private var prefix = ByteArray(7)
        private var fileLen = 0L
        private var nChunks = 1
        private var dataOff = 0
        private val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        private var curIdx = -1
        private var cur = ByteArray(0)

        /** Size of the real file content (without the hidden metadata). */
        var size = 0L
            private set

        init {
            try {
                fileLen = raf.length()
                if (fileLen < 32 + Vault.TAG) throw IOException("Vault file is damaged")
                raf.readFully(head)
                if (!head.copyOfRange(0, 4).contentEquals(Vault.MAGIC_F) || ByteBuffer.wrap(head, 28, 4).int != Vault.CHUNK) {
                    throw IOException("Not a vault file")
                }
                key = Vault.fileKey(master, head.copyOfRange(5, 21))
                prefix = head.copyOfRange(21, 28)
                val full = (Vault.CHUNK + Vault.TAG).toLong()
                nChunks = (((fileLen - 32) + full - 1) / full).toInt()
                val plainTotal = (fileLen - 32) - nChunks.toLong() * Vault.TAG
                val first = load(0)
                dataOff = Vault.parseMeta(first).second
                size = plainTotal - dataOff
                if (size < 0) throw IOException("Vault file is damaged")
                cur = first
                curIdx = 0
            } catch (e: Throwable) {
                try { raf.close() } catch (x: Exception) { }
                cur.fill(0)
                throw e
            }
        }

        private fun load(idx: Int): ByteArray {
            val full = (Vault.CHUNK + Vault.TAG).toLong()
            val start = 32L + idx.toLong() * full
            val n = minOf(full, fileLen - start).toInt()
            if (n < Vault.TAG) throw IOException("Vault file is damaged")
            val buf = ByteArray(n)
            raf.seek(start)
            raf.readFully(buf)
            cipher.init(
                Cipher.DECRYPT_MODE, key,
                GCMParameterSpec(128, Vault.nonceFor(prefix, idx, idx == nChunks - 1))
            )
            cipher.updateAAD(head)
            return try {
                cipher.doFinal(buf)
            } catch (e: BadPaddingException) {
                throw IOException("Vault file is damaged or the key is wrong")
            }
        }

        /** Copies up to [len] bytes of the content starting at [pos]; returns the count, or -1 at the end. */
        @Synchronized
        fun read(pos: Long, dst: ByteArray, off: Int, len: Int): Int {
            if (pos < 0 || pos >= size || len <= 0) return -1
            val p = pos + dataOff
            val idx = (p / Vault.CHUNK).toInt()
            val inChunk = (p % Vault.CHUNK).toInt()
            if (idx != curIdx) {
                curIdx = -1
                cur.fill(0)
                cur = load(idx)
                curIdx = idx
            }
            val left = minOf(size - pos, Int.MAX_VALUE.toLong()).toInt()
            val n = minOf(len, cur.size - inChunk, left)
            if (n <= 0) return -1
            System.arraycopy(cur, inChunk, dst, off, n)
            return n
        }

        @Synchronized
        override fun close() {
            try { raf.close() } catch (e: Exception) { }
            cur.fill(0)
            cur = ByteArray(0)
            curIdx = -1
        }
    }

    /** Opens a streaming reader for an item of the UNLOCKED vault; null while the vault is locked or the id is unknown. */
    fun openStream(id: String): StreamReader? {
        val m = keyCopy() ?: return null
        try {
            val item = items.firstOrNull { it.id == id } ?: return null
            val f = fileOf(item)
            if (!f.exists()) throw IOException("Vault file is missing (is the SD card inserted?)")
            return StreamReader(f, m)
        } finally {
            m.fill(0)
        }
    }

    /** Address the player uses for a vault item. It holds only the random id and the extension, never the real name. */
    fun streamUri(item: VaultItem): String {
        val ext = item.name.substringAfterLast('.', "").lowercase().filter { it.isLetterOrDigit() }.take(8)
        return "iavault://" + item.id + "/f" + (if (ext.isEmpty()) "" else ".$ext")
    }

    // ---------------- optional fingerprint unlock (Android Keystore) ----------------
    fun bioEnabled() = ::prefs.isInitialized && prefs.contains("bio_ct")

    fun bioAvailable(ctx: Context) =
        BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

    fun clearBio() {
        prefs.edit().remove("bio_iv").remove("bio_ct").commit()
        try { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS) } catch (e: Exception) { }
    }

    private fun newBioKey(): SecretKey {
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true)
                .build()
        )
        return kg.generateKey()
    }

    private fun prompt(act: FragmentActivity, cipher: Cipher, title: String, ok: (Cipher) -> Unit, fail: (String) -> Unit) {
        val p = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val c = result.cryptoObject?.cipher
                if (c != null) ok(c) else fail("Fingerprint failed")
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { fail(errString.toString()) }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Use password")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        p.authenticate(info, BiometricPrompt.CryptoObject(cipher))
    }

    /** Must be called while unlocked: protects a copy of the master key with a fingerprint-bound key. */
    fun enableBio(act: FragmentActivity, done: (String?) -> Unit) {
        val master = keyCopy() ?: return done("Unlock the vault first")
        try {
            val key = newBioKey()
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key)
            prompt(act, c, "Enable fingerprint unlock", { cc ->
                try {
                    val ct = cc.doFinal(master)
                    prefs.edit().putString("bio_iv", Base64.encodeToString(cc.iv, Base64.NO_WRAP))
                        .putString("bio_ct", Base64.encodeToString(ct, Base64.NO_WRAP)).commit()
                    done(null)
                } catch (e: Exception) {
                    clearBio(); done(e.message ?: "Failed")
                } finally {
                    master.fill(0)
                }
            }, { msg -> master.fill(0); clearBio(); done(msg) })
        } catch (e: Exception) {
            master.fill(0)
            clearBio()
            done(e.message ?: "Fingerprint is not available")
        }
    }

    fun unlockBio(act: FragmentActivity, done: (String?) -> Unit) {
        try {
            if (lockedForMs() > 0) return done("Too many attempts. Please wait.")
            val iv = Base64.decode(prefs.getString("bio_iv", "") ?: "", Base64.NO_WRAP)
            val ct = Base64.decode(prefs.getString("bio_ct", "") ?: "", Base64.NO_WRAP)
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = ks.getKey(ALIAS, null) as? SecretKey ?: run { clearBio(); return done("Fingerprint unlock was reset. Use your password.") }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            prompt(act, c, "Unlock Vault", { cc ->
                try {
                    val master = cc.doFinal(ct)
                    finishUnlock(master)
                    recordOk()
                    done(null)
                } catch (e: Exception) {
                    done("Fingerprint unlock failed. Use your password.")
                }
            }, { msg -> done(msg) })
        } catch (e: KeyPermanentlyInvalidatedException) {
            clearBio()
            done("Your fingerprints changed, so fingerprint unlock was turned off. Use your password.")
        } catch (e: Exception) {
            done("Fingerprint unlock is not available. Use your password.")
        }
    }
}
