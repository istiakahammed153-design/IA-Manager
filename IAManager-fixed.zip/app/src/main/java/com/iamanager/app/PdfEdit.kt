/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class PgState(val src: Int, val rot: Int = 0, val shapes: List<Shape> = emptyList())

fun rotateBitmap(b: Bitmap, deg: Int): Bitmap {
    val d = ((deg % 360) + 360) % 360
    if (d == 0) return b
    val m = Matrix()
    m.postRotate(d.toFloat())
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

private fun addOverlay(d: PDDocument, pg: PDPage, shapes: List<Shape>) {
    val cb = pg.cropBox
    val r = ((pg.rotation % 360) + 360) % 360
    val cw = cb.width
    val ch = cb.height
    val dw = if (r % 180 == 0) cw else ch
    val dh = if (r % 180 == 0) ch else cw
    val k = 1600f / maxOf(dw, dh)
    val ow = (dw * k).toInt().coerceAtLeast(1)
    val oh = (dh * k).toInt().coerceAtLeast(1)
    val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
    drawShapes(Canvas(bmp), ow.toFloat(), oh.toFloat(), shapes)
    val upright = rotateBitmap(bmp, (360 - r) % 360)
    val img = LosslessFactory.createFromImage(d, upright)
    val cs = PDPageContentStream(d, pg, PDPageContentStream.AppendMode.APPEND, true, true)
    try {
        cs.drawImage(img, cb.lowerLeftX, cb.lowerLeftY, cb.width, cb.height)
    } finally {
        cs.close()
    }
}

fun savePdfEdits(ctx: Context, src: File, pages: List<PgState>, out: File) {
    PDFBoxResourceLoader.init(ctx.applicationContext)
    val d = PDDocument.load(src)
    try {
        val n = d.numberOfPages
        val all = (0 until n).map { d.getPage(it) }
        for (i in n - 1 downTo 0) d.removePage(i)
        for (p in pages) {
            val pg = all[p.src]
            pg.rotation = ((pg.rotation + p.rot) % 360 + 360) % 360
            d.addPage(pg)
            if (p.shapes.isNotEmpty()) addOverlay(d, pg, p.shapes)
        }
        d.save(out)
    } finally {
        d.close()
    }
}

@Composable
private fun PdfThumb(doc: PdfDoc, pg: PgState, number: Int, selected: Boolean, onClick: () -> Unit) {
    var bmp by remember(pg.src) { mutableStateOf(doc.cached(pg.src, 260)) }
    LaunchedEffect(pg.src) {
        if (bmp == null) bmp = withContext(Dispatchers.IO) { try { doc.render(pg.src, 260) } catch (e: Exception) { null } }
    }
    val shown = remember(bmp, pg.rot) { bmp?.let { rotateBitmap(it, pg.rot) } }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().aspectRatioBox()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFEEEEEE))
                .border(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else Color(0xFFBBBBBB), RoundedCornerShape(8.dp))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (shown != null) {
                Image(shown.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            } else {
                CircularProgressIndicator(Modifier.size(24.dp))
            }
            if (pg.shapes.isNotEmpty()) {
                Icon(
                    Icons.Outlined.Brush, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(18.dp)
                )
            }
        }
        Text("$number", fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

private fun Modifier.aspectRatioBox(): Modifier = this.then(Modifier.height(170.dp))

@Composable
private fun PdfAct(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    val c = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = c, modifier = Modifier.size(24.dp))
        Text(label, fontSize = 11.sp, color = c)
    }
}

@Composable
fun PdfEditScreen(vm: AppViewModel, path: String) {
    val f = File(path)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val doc = remember(path) { try { PdfDoc(f) } catch (e: Exception) { null } }
    DisposableEffect(path) { onDispose { doc?.close() } }
    if (doc == null) {
        UnsupportedViewer(vm, f, "This PDF could not be opened for editing (it may be protected or damaged).")
        return
    }
    val pages = remember {
        mutableStateListOf<PgState>().apply { for (i in 0 until doc.pageCount) add(PgState(i)) }
    }
    var sel by remember { mutableIntStateOf(0) }
    var annotBase by remember { mutableStateOf<Bitmap?>(null) }
    var saving by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    val dirty = pages.size != doc.pageCount || pages.withIndex().any { (i, p) -> p.src != i || p.rot != 0 || p.shapes.isNotEmpty() }
    BackHandler(enabled = dirty && annotBase == null) { discard = true }
    val cur = pages.getOrNull(sel)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            SimpleTop("Edit PDF", onBack = { if (dirty) discard = true else vm.pop() }) {
                TextButton(
                    enabled = dirty && !saving,
                    onClick = {
                        saving = true
                        val list = pages.toList()
                        scope.launch {
                            val res = withContext(Dispatchers.IO) {
                                try {
                                    val out = uniqueFile(f.parentFile ?: vm.root, f.nameWithoutExtension + "_edited.pdf")
                                    savePdfEdits(ctx, f, list, out)
                                    out.name
                                } catch (e: Throwable) {
                                    null
                                }
                            }
                            saving = false
                            vm.message = if (res != null) "Saved: $res" else "Could not save the PDF"
                            if (res != null) {
                                vm.refresh()
                                vm.pop()
                            }
                        }
                    }
                ) { Text(if (saving) "Saving..." else "Save", fontWeight = FontWeight.Bold) }
            }
            Text(
                "Tap a page, then use the tools below. Edits are saved as a new copy.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(pages, key = { _, p -> p.src }) { i, p ->
                    PdfThumb(doc, p, i + 1, i == sel) { sel = i }
                }
            }
            Surface(tonalElevation = 3.dp) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceAround) {
                    PdfAct(Icons.Outlined.RotateRight, "Rotate", cur != null) {
                        val p = pages[sel]
                        pages[sel] = p.copy(rot = (p.rot + 90) % 360, shapes = p.shapes.map { it.rotated90() })
                    }
                    PdfAct(Icons.Outlined.ArrowBack, "Earlier", sel > 0) {
                        val t = pages[sel]; pages[sel] = pages[sel - 1]; pages[sel - 1] = t; sel -= 1
                    }
                    PdfAct(Icons.Outlined.ChevronRight, "Later", sel < pages.size - 1) {
                        val t = pages[sel]; pages[sel] = pages[sel + 1]; pages[sel + 1] = t; sel += 1
                    }
                    PdfAct(Icons.Outlined.Brush, "Annotate", cur != null) {
                        val p = pages[sel]
                        scope.launch {
                            val b = withContext(Dispatchers.IO) {
                                try {
                                    val r = rotateBitmap(doc.render(p.src, 1100), p.rot)
                                    val copy = r.copy(Bitmap.Config.ARGB_8888, true) ?: r
                                    drawShapes(Canvas(copy), copy.width.toFloat(), copy.height.toFloat(), p.shapes)
                                    copy
                                } catch (e: Throwable) {
                                    null
                                }
                            }
                            if (b != null) annotBase = b else vm.message = "Could not open this page for drawing"
                        }
                    }
                    PdfAct(Icons.Outlined.DeleteOutline, "Delete", pages.size > 1) {
                        pages.removeAt(sel)
                        if (sel >= pages.size) sel = pages.size - 1
                    }
                }
            }
        }
        val base = annotBase
        if (base != null) {
            MarkupEditor(
                base = base,
                onCancel = { annotBase = null },
                onDone = { shapes ->
                    if (shapes.isNotEmpty() && sel in pages.indices) {
                        val p = pages[sel]
                        pages[sel] = p.copy(shapes = p.shapes + shapes)
                    }
                    annotBase = null
                }
            )
        }
    }
    if (discard) {
        AlertDialog(
            onDismissRequest = { discard = false },
            title = { Text("Discard edits?") },
            text = { Text("Your changes have not been saved.") },
            confirmButton = { TextButton(onClick = { discard = false; vm.pop() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } }
        )
    }
}
