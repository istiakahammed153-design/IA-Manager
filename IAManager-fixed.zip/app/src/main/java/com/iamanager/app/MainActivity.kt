/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : FragmentActivity() {
    override fun onStart() {
        super.onStart()
        Ops.visible = true
    }

    override fun onStop() {
        Ops.visible = false   // a finished transfer now reports itself with a notification
        super.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) Vault.lock()   // a running transfer keeps its own copy of the key and carries on
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ops.init(applicationContext)
        Vault.init(applicationContext)
        setContent {
            val vm: AppViewModel = viewModel()
            val ok = remember { Owner.verify(this@MainActivity) }
            IATheme(vm.theme, homeBars = vm.current == Screen.Home) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Box(Modifier.fillMaxSize()) {
                        if (ok) Root(vm) else TamperScreen { finish() }
                        if (ok) StartupSplash(vm)   // animated start-up screen, fades away when the app is ready
                    }
                }
            }
        }
    }
}

@Composable
fun TamperScreen(onExit: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Outlined.Info, null, tint = Color(0xFFE53935), modifier = Modifier.size(72.dp))
        Spacer(Modifier.height(16.dp))
        Text("Unauthorized copy", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "This app has been modified without permission. IA Manager is the work of Istiak Ahammed and " +
                "may not be copied, changed or redistributed under another name.",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onExit) { Text("Close") }
    }
}

fun hasAccess(ctx: Context): Boolean =
    if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root(vm: AppViewModel) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAccess(ctx)) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                granted = hasAccess(ctx)
                if (granted) vm.onResume(ctx)
            }
            // Vault locks (and decrypted view copies are wiped) when you leave the app - but not on screen rotation
            if (e == Lifecycle.Event.ON_STOP && (ctx as? android.app.Activity)?.isChangingConfigurations != true) Vault.onBackground()
        }
        lifecycle.addObserver(o)
        onDispose { lifecycle.removeObserver(o) }
    }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (hasAccess(ctx)) vm.updateStorages(ctx)
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_REMOVED)
            addAction(Intent.ACTION_MEDIA_EJECT)
            addDataScheme("file")
        }
        try {
            ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        } catch (e: Exception) {
        }
        onDispose { try { ctx.unregisterReceiver(receiver) } catch (e: Exception) { } }
    }
    // New downloads / photos / files from other apps: refresh automatically.
    DisposableEffect(granted) {
        var obs: android.database.ContentObserver? = null
        if (granted) {
            obs = object : android.database.ContentObserver(android.os.Handler(android.os.Looper.getMainLooper())) {
                override fun onChange(selfChange: Boolean) { vm.dirChanged() }
            }
            try {
                ctx.contentResolver.registerContentObserver(
                    android.provider.MediaStore.Files.getContentUri("external"), true, obs
                )
            } catch (e: Exception) {
            }
        }
        onDispose { obs?.let { try { ctx.contentResolver.unregisterContentObserver(it) } catch (e: Exception) { } } }
    }
    LaunchedEffect(granted) {
        if (granted) {
            vm.updateStorages(ctx)
            vm.refresh()
        }
    }
    // Transfers go on in the background and report in a notification: ask once for the notification permission.
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(vm.op != null) {
        if (vm.op != null && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val p = ctx.getSharedPreferences("ia_prefs", Context.MODE_PRIVATE)
            if (!p.getBoolean("asked_notif", false)) {
                p.edit().putBoolean("asked_notif", true).apply()
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
    if (granted) MainShell(vm) else PermissionScreen()
}

@Composable
fun PermissionScreen() {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Outlined.Folder, null, tint = FolderYellow, modifier = Modifier.size(80.dp))
        Spacer(Modifier.height(16.dp))
        Text("IA Manager", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "To browse and manage the files on your phone, please allow access to all files.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 30) {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    )
                } catch (e: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                launcher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
            }
        }) { Text("Grant Access") }
    }
}

@Composable
fun BottomBar(vm: AppViewModel, openDrawer: () -> Unit) {
    val s = vm.current
    val idx = when (s) {
        is Screen.Files, is Screen.Category, Screen.Search, Screen.Trash -> 1
        Screen.Shared, Screen.Recent, Screen.Starred -> 2
        else -> 0
    }
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(selected = idx == 0, onClick = { vm.goTab(Screen.Home) }, icon = { Icon(Icons.Outlined.Home, null) }, label = { Text("Home") })
        NavigationBarItem(selected = idx == 1, onClick = { vm.goTab(Screen.Files(vm.root.path)) }, icon = { Icon(Icons.Outlined.Folder, null) }, label = { Text("Files") })
        NavigationBarItem(selected = idx == 2, onClick = { vm.goTab(Screen.Shared) }, icon = { Icon(Icons.Outlined.People, null) }, label = { Text("Shared") })
        NavigationBarItem(selected = false, onClick = openDrawer, icon = { Icon(Icons.Outlined.Menu, null) }, label = { Text("More") })
    }
}

@Composable
fun DrawerContent(vm: AppViewModel, close: () -> Unit) {
    ModalDrawerSheet {
      // Scrollable + padded above the system navigation bar, so the last items (Settings) are never cut off.
      Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Folder, null, tint = Blue, modifier = Modifier.size(36.dp))
                Spacer(Modifier.width(12.dp))
                // The Vault is not listed in the menu (privacy). Press and hold this title to open it.
                Column(Modifier.pointerInput(Unit) { detectTapGestures(onLongPress = { close(); vm.push(Screen.Vault) }) }) {
                    Text("IA Manager", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Manage your files, easily", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(12.dp))
            StorageCard(vm, onClick = {
                close()
                if (vm.storages.size > 1) vm.showStoragePicker = true else vm.goTab(Screen.Files(vm.root.path))
            })
        }
        @Composable
        fun item(label: String, icon: ImageVector, selected: Boolean = false, onClick: () -> Unit) {
            NavigationDrawerItem(
                label = { Text(label) }, icon = { Icon(icon, null) }, selected = selected,
                onClick = { close(); onClick() },
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
        item("Home", Icons.Outlined.Home, vm.current == Screen.Home) { vm.goTab(Screen.Home) }
        item("Recent", Icons.Outlined.History) { vm.push(Screen.Recent) }
        item("Starred", Icons.Outlined.Star) { vm.push(Screen.Starred) }
        item("Shared", Icons.Outlined.People) { vm.push(Screen.Shared) }
        item("Recycle Bin", Icons.Outlined.DeleteOutline) { vm.push(Screen.Trash) }
        HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 16.dp))
        Text("Tools", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 28.dp, bottom = 4.dp))
        item("Create / Convert Files", Icons.Outlined.AutoAwesome) { vm.push(Screen.Create(vm.root.path)) }
        item("ZIP & Extract", Icons.Outlined.FolderZip) { vm.push(Screen.Category(Cat.ARCHIVES)) }
        item("Apps & APK Installer", Icons.Outlined.Android) { vm.push(Screen.Apps) }
        item("Large Files", Icons.Outlined.Storage) { vm.push(Screen.LargeFiles) }
        item("Duplicate Files", Icons.Outlined.ContentCopy) { vm.push(Screen.Duplicates) }
        item("FTP", Icons.Outlined.Cloud) { vm.push(Screen.Ftp) }
        NavigationDrawerItem(
            label = { Text("Hidden Files") }, icon = { Icon(Icons.Outlined.Visibility, null) }, selected = false,
            badge = { Switch(checked = vm.showHidden, onCheckedChange = null) },
            onClick = { vm.setHidden(!vm.showHidden) },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        item("Settings", Icons.Outlined.Settings) { vm.push(Screen.Settings) }
        Spacer(Modifier.navigationBarsPadding().height(16.dp))
      }
    }
}

@Composable
fun MainShell(vm: AppViewModel) {
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val snack = remember { SnackbarHostState() }
    val screen = vm.current
    val holder = rememberSaveableStateHolder()
    val openDrawer: () -> Unit = { scope.launch { drawer.open() } }

    // Vault: stays unlocked only while you are inside it; screenshots / recent-apps preview are blocked there.
    val inVault = screen is Screen.Vault || (screen is Screen.Viewer && Vault.isTemp(screen.path))
    // Safety net: locks at once (no delay) if the vault is ever unlocked while you are outside it.
    // "Move to Vault" is safe: its key is copied synchronously before this runs.
    LaunchedEffect(inVault, Vault.unlocked, vm.vaultPending) {
        if (!inVault && Vault.unlocked && vm.vaultPending == null) Vault.lock()
    }
    val activity = LocalContext.current as? android.app.Activity
    val secure = inVault || vm.vaultPending != null
    DisposableEffect(secure) {
        if (secure) activity?.window?.setFlags(
            android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE
        )
        onDispose { activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE) }
    }

    BackHandler(enabled = vm.stack.size > 1) { vm.pop() }
    BackHandler(enabled = vm.selected.isNotEmpty()) { vm.selected = emptySet() }
    BackHandler(enabled = drawer.isOpen) { scope.launch { drawer.close() } }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }

    val showBar = screen !is Screen.Details && screen !is Screen.Editor && screen !is Screen.Create &&
        screen !is Screen.Settings && screen !is Screen.Viewer && screen !is Screen.Pick &&
        screen !is Screen.PdfEdit && screen !is Screen.OfficeEdit && screen !is Screen.Ftp && screen !is Screen.Vault

    ModalNavigationDrawer(
        drawerState = drawer,
        gesturesEnabled = drawer.isOpen,
        drawerContent = { DrawerContent(vm) { scope.launch { drawer.close() } } }
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = {
                if (vm.selected.isNotEmpty()) {
                    if (screen !is Screen.Details && screen !is Screen.Viewer) SelectionBottom(vm)
                } else if (showBar) {
                    BottomBar(vm, openDrawer)
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                holder.SaveableStateProvider(screen.toString()) {
                    when (screen) {
                        Screen.Home -> HomeScreen(vm, openDrawer)
                        is Screen.Files -> FilesScreen(vm, screen.path, openDrawer)
                        is Screen.Category -> CategoryScreen(vm, screen.cat, screen.pickEdit)
                        Screen.Search -> SearchScreen(vm)
                        is Screen.Details -> DetailsScreen(vm, screen.path)
                        is Screen.Editor -> EditorScreen(vm, screen.path)
                        is Screen.Create -> CreateScreen(vm, screen.dir)
                        Screen.Settings -> SettingsScreen(vm)
                        Screen.Shared -> PathListScreen(vm, "Shared", vm.shared, "Files you share will appear here")
                        Screen.Recent -> PathListScreen(vm, "Recent Files", vm.recent, "No recent files yet")
                        Screen.Starred -> PathListScreen(vm, "Starred", vm.starred, "No starred files yet")
                        Screen.Trash -> TrashScreen(vm)
                        is Screen.Viewer -> ViewerScreen(vm, screen.path)
                        is Screen.Pick -> PickScreen(vm, screen.conv, screen.dir)
                        is Screen.PdfEdit -> PdfEditScreen(vm, screen.path)
                        is Screen.OfficeEdit -> OfficeEditScreen(vm, screen.path)
                        Screen.Ftp -> FtpScreen(vm)
                        Screen.Vault -> VaultScreen(vm)
                        Screen.Apps -> AppsScreen(vm)
                        Screen.LargeFiles -> LargeFilesScreen(vm)
                        Screen.Duplicates -> DuplicatesScreen(vm)
                    }
                }
            }
        }
    }

    // ---- global dialogs ----
    if (vm.showStoragePicker) {
        AlertDialog(
            onDismissRequest = { vm.showStoragePicker = false },
            title = { Text("Choose storage") },
            text = {
                Column {
                    vm.storages.forEach { v ->
                        val st = storageStats(v.root)
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { vm.showStoragePicker = false; vm.selectStorage(v) }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (v.root.path == vm.internalRoot.path) Icons.Outlined.Storage else Icons.Outlined.SdCard,
                                null, tint = Blue, modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(v.name, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${fmtSize(st.first)} / ${fmtSize(st.second)}" + if (v.root.path == vm.root.path) "  \u2022  current" else "",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { vm.showStoragePicker = false }) { Text("Cancel") } }
        )
    }
    vm.pickerMove?.let { FolderPicker(vm, it) }
    vm.op?.let { OpDialog(it) }
    vm.vaultPending?.let { VaultUnlockDialog(vm, it) }

    if (vm.confirmDelete) {
        AlertDialog(
            onDismissRequest = { vm.dismissDialogs() },
            title = { Text("Delete") },
            text = { Text("Move ${vm.selected.size} item(s) to the Recycle Bin?") },
            confirmButton = {
                TextButton(onClick = { vm.confirmDelete = false; vm.deleteSelected() }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialogs() }) { Text("Cancel") } }
        )
    }

    vm.renameTarget?.let { target ->
        var name by remember(target) { mutableStateOf(File(target).name) }
        AlertDialog(
            onDismissRequest = { vm.dismissDialogs() },
            title = { Text("Rename") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.renameTarget = null; vm.rename(target, name) }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { vm.dismissDialogs() }) { Text("Cancel") } }
        )
    }
}
