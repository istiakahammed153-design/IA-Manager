# IA Manager

Android file manager (Kotlin + Jetpack Compose).

## APK তৈরি (GitHub Actions)
1. এই প্রজেক্টের সব ফাইল (লুকানো `.github` ফোল্ডারসহ) একটি নতুন GitHub repository-র root-এ আপলোড করুন (branch: `main`).
2. Repository → **Actions** ট্যাব → "Build APK" workflow চলবে (না চললে "Run workflow" চাপুন).
3. শেষ হলে run-এর নিচে **Artifacts → IAManager-apk** ডাউনলোড করুন, zip খুলে `app-debug.apk` ফোনে ইন্সটল করুন.
4. প্রথমবার অ্যাপ খুললে "All files access" পারমিশন দিন।
