# IA Manager

Android file manager (Kotlin + Jetpack Compose).

## APK তৈরি (GitHub Actions)
1. এই zip ফাইলটি (বা প্রজেক্টের ফাইলগুলো) GitHub repo-র root-এ আপলোড করুন।
2. repo-তে `.github/workflows/build.yml` রাখুন (zip আপলোড করলে workflow নিজে zip খুলে বিল্ড করবে)।
3. Actions ট্যাবে "Build APK" চলবে → শেষে **Artifacts → IAManager-apk** নামিয়ে `app-debug.apk` ইন্সটল করুন।
4. প্রথমবার অ্যাপ খুললে "All files access" পারমিশন দিন।
