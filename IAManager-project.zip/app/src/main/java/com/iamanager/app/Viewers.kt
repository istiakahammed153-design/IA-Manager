@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

val TEXT_EXTS = setOf(
    "txt", "md", "json", "xml", "csv", "tsv", "html", "htm", "log", "ini", "conf", "java", "kt", "py", "js",
    "css", "yml", "yaml", "properties", "gradle", "sh", "srt", "vcf", "kts", "c", "cpp", "h"
)

fun convertExtras(vm: AppViewModel, f: File): List<Pair<String, () -> Unit>> {
    val dir = f.parentFile ?: vm.root
    return when {
        f.cat() == Cat.IMAGES -> listOf(
            "Convert to PDF" to { vm.convert(Conv.IMG_TO_PDF, listOf(f), dir) }
        )
        f.ext == "pdf" -> listOf(
            "Convert to Word (.docx)" to { vm.convert(Conv.PDF_TO_DOCX, listOf(f), dir) },
            "Save pages as images" to { vm.convert(Conv.PDF_TO_IMG, listOf(f), dir) }
        )
        f.ext in setOf("docx", "pptx", "txt", "md") -> listOf(
            "Convert to PDF" to { vm.convert(Conv.DOC_TO_PDF, listOf(f), dir) }
        )
        f.ext == "xlsx" -> listOf(
            "Export as CSV" to { vm.convert(Conv.XLSX_TO_CSV, listOf(f), dir) }
        )
        else -> emptyList()
    }
}

@Composable
fun ViewerMenu(
    vm: AppViewModel,
    f: File,
    tint: Color = LocalContentColor.current,
    extras: List<Pair<String, () -> Unit>> = emptyList()
) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    IconButton(onClick = { vm.share(ctx, listOf(f)) }) { Icon(Icons.Outlined.Share, "Share", tint = tint) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Outlined.MoreVert, "More", tint = tint) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            extras.forEach { (label, act) ->
                DropdownMenuItem(text = { Text(label) }, onClick = { open = false; act() })
            }
            DropdownMenuItem(text = { Text("Details") }, onClick = { open = false; vm.push(Screen.Details(f.path)) })
            DropdownMenuItem(
                text = { Text(if (f.path in vm.starred) "Remove star" else "Add star") },
                onClick = { open = false; vm.toggleStar(f.path) }
            )
            DropdownMenuItem(text = { Text("Rename") }, onClick = { open = false; vm.selected = setOf(f.path); vm.renameTarget = f.path })
            DropdownMenuItem(text = { Text("Move") }, onClick = { open = false; vm.selected = setOf(f.path); vm.pickerMove = true })
            DropdownMenuItem(text = { Text("Copy") }, onClick = { open = false; vm.selected = setOf(f.path); vm.pickerMove = false })
            DropdownMenuItem(text = { Text("Open with another app") }, onClick = { open = false; openFile(ctx, f) })
            DropdownMenuItem(text = { Text("Delete") }, onClick = { open = false; vm.selected = setOf(f.path); vm.confirmDelete = true })
        }
    }
}

@Composable
fun ViewerScreen(vm: AppViewModel, path: String) {
    val f = File(path)
    if (!f.exists()) {
        LaunchedEffect(path) { vm.pop() }
        return
    }
    when {
        f.cat() == Cat.IMAGES -> ImageViewer(vm, f)
        f.cat() == Cat.VIDEOS -> VideoViewer(vm, f)
        f.cat() == Cat.AUDIO -> AudioViewer(vm, f)
        f.ext == "pdf" -> PdfViewer(vm, f)
        f.ext in setOf("docx", "pptx", "xlsx") -> OfficeViewer(vm, f)
        f.ext == "zip" -> ZipViewer(vm, f)
        f.ext in TEXT_EXTS -> TextViewer(vm, f)
        else -> UnsupportedViewer(vm, f)
    }
}

// ---------------- IMAGE VIEWER ----------------
@Composable
private fun ZoomableImage(f: File, onTap: () -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val ctx = LocalContext.current
    fun clamp(o: Offset, s: Float): Offset {
        val mx = size.width * (s - 1f) / 2f
        val my = size.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = {
                        if (scale > 1f) {
                            scale = 1f
                            offset = Offset.Zero
                        } else {
                            scale = 2.5f
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val pressed = ev.changes.count { it.pressed }
                        if (pressed >= 2 || scale > 1f) {
                            val zoom = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            val ns = (scale * zoom).coerceIn(1f, 5f)
                            scale = ns
                            offset = if (ns > 1f) clamp(offset + pan, ns) else Offset.Zero
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(f).size(2560).crossfade(true).build(),
            imageLoader = Loader.get(ctx),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer(
                scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y
            )
        )
    }
}

@Composable
private fun ViewerAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(24.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun ImageViewer(vm: AppViewModel, f: File) {
    val images = remember(f.path, vm.tick) {
        val sibs = (f.parentFile?.listFiles() ?: emptyArray())
            .filter { it.isFile && it.cat() == Cat.IMAGES && (vm.showHidden || !it.name.startsWith(".")) }
            .sortedByDescending { it.lastModified() }
        if (sibs.any { it.path == f.path }) sibs else listOf(f)
    }
    val startIdx = remember(f.path) { images.indexOfFirst { it.path == f.path }.coerceAtLeast(0) }
    val pager = rememberPagerState(initialPage = startIdx) { images.size }
    var bars by remember { mutableStateOf(true) }
    val cur = images.getOrNull(pager.currentPage) ?: f
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            ZoomableImage(images[page]) { bars = !bars }
        }
        if (bars) {
            Row(
                Modifier.fillMaxWidth().align(Alignment.TopStart).background(Color(0x99000000)).padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.pop() }) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(cur.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text("${pager.currentPage + 1} / ${images.size}", color = Color(0xFFCCCCCC), fontSize = 11.sp)
                }
                ViewerMenu(vm, cur, Color.White, convertExtras(vm, cur))
            }
            Row(
                Modifier.fillMaxWidth().align(Alignment.BottomStart).background(Color(0x99000000)).padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ViewerAction(Icons.Outlined.Edit, "Edit") { vm.push(Screen.Editor(cur.path)) }
                ViewerAction(Icons.Outlined.Info, "Details") { vm.push(Screen.Details(cur.path)) }
                ViewerAction(Icons.Outlined.PictureAsPdf, "To PDF") {
                    vm.convert(Conv.IMG_TO_PDF, listOf(cur), cur.parentFile ?: vm.root)
                }
                ViewerAction(Icons.Outlined.DeleteOutline, "Delete") { vm.selected = setOf(cur.path); vm.confirmDelete = true }
            }
        }
    }
}

// ---------------- VIDEO ----------------
@Composable
fun VideoViewer(vm: AppViewModel, f: File) {
    var view by remember { mutableStateOf<VideoView?>(null) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(f.path) {
        onDispose {
            try { controller?.hide() } catch (e: Exception) { }
            try { view?.stopPlayback() } catch (e: Exception) { }
        }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val frame = FrameLayout(ctx)
                val vv = VideoView(ctx)
                val mc = MediaController(ctx)
                mc.setAnchorView(vv)
                vv.setMediaController(mc)
                vv.setVideoURI(Uri.fromFile(f))
                vv.setOnPreparedListener { it.isLooping = false; vv.start() }
                frame.addView(
                    vv,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER)
                )
                view = vv
                controller = mc
                frame
            }
        )
        Row(
            Modifier.fillMaxWidth().align(Alignment.TopStart).background(Color(0x66000000)).padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.pop() }) { Icon(Icons.Outlined.ArrowBack, "Back", tint = Color.White) }
            Text(f.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            ViewerMenu(vm, f, Color.White)
        }
    }
}

// ---------------- AUDIO ----------------
private fun fmtTime(ms: Int): String {
    val s = ms / 1000
    return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
}

@Composable
fun AudioViewer(vm: AppViewModel, f: File) {
    val player = remember { MediaPlayer() }
    var ready by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(0) }
    DisposableEffect(f.path) {
        try {
            player.setDataSource(f.path)
            player.setOnPreparedListener { mp ->
                dur = mp.duration
                ready = true
                mp.start()
                playing = true
            }
            player.setOnCompletionListener { mp ->
                playing = false
                pos = 0
                mp.seekTo(0)
            }
            player.prepareAsync()
        } catch (e: Exception) {
        }
        onDispose {
            try { player.stop() } catch (e: Exception) { }
            player.release()
        }
    }
    LaunchedEffect(playing) {
        while (playing) {
            pos = try { player.currentPosition } catch (e: Exception) { 0 }
            delay(300)
        }
    }
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) { ViewerMenu(vm, f) }
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(180.dp).background(catColor(Cat.AUDIO).copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Outlined.MusicNote, null, tint = catColor(Cat.AUDIO), modifier = Modifier.size(90.dp)) }
            Spacer(Modifier.height(24.dp))
            Text(f.nameWithoutExtension, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(20.dp))
            Slider(
                value = pos.toFloat().coerceAtMost(dur.coerceAtLeast(1).toFloat()),
                onValueChange = { pos = it.toInt(); try { player.seekTo(it.toInt()) } catch (e: Exception) { } },
                valueRange = 0f..dur.coerceAtLeast(1).toFloat(),
                enabled = ready
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmtTime(pos), fontSize = 12.sp)
                Text(fmtTime(dur), fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                IconButton(onClick = {
                    if (ready) { val n = (player.currentPosition - 10000).coerceAtLeast(0); player.seekTo(n); pos = n }
                }) { Icon(Icons.Outlined.Replay10, "Back 10s", modifier = Modifier.size(32.dp)) }
                FilledIconButton(
                    onClick = {
                        if (ready) {
                            if (playing) { player.pause(); playing = false } else { player.start(); playing = true }
                        }
                    },
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, "Play/Pause", modifier = Modifier.size(36.dp))
                }
                IconButton(onClick = {
                    if (ready) { val n = (player.currentPosition + 10000).coerceAtMost(dur); player.seekTo(n); pos = n }
                }) { Icon(Icons.Outlined.Forward10, "Forward 10s", modifier = Modifier.size(32.dp)) }
            }
        }
    }
}

// ---------------- PDF ----------------
class PdfDoc(file: File) {
    private val pfd: ParcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(pfd)
    private val lock = Any()
    val pageCount: Int = renderer.pageCount

    fun render(i: Int, widthPx: Int): Bitmap = synchronized(lock) {
        val page = renderer.openPage(i)
        try {
            val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(AColor.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
        } finally {
            page.close()
        }
    }

    fun close() = synchronized(lock) {
        try { renderer.close() } catch (e: Exception) { }
        try { pfd.close() } catch (e: Exception) { }
    }
}

@Composable
fun PdfViewer(vm: AppViewModel, f: File) {
    val doc = remember(f.path) { try { PdfDoc(f) } catch (e: Exception) { null } }
    DisposableEffect(f.path) { onDispose { doc?.close() } }
    if (doc == null) {
        UnsupportedViewer(vm, f, "This PDF could not be opened (it may be protected or damaged).")
        return
    }
    val ls = rememberLazyListState()
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) { ViewerMenu(vm, f, extras = convertExtras(vm, f)) }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val wpx = (constraints.maxWidth * 1.5f).toInt()
            LazyColumn(
                state = ls,
                modifier = Modifier.fillMaxSize().background(Color(0xFF3A3F47)),
                contentPadding = PaddingValues(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(count = doc.pageCount) { i ->
                    var bmp by remember(i) { mutableStateOf<Bitmap?>(null) }
                    LaunchedEffect(i) {
                        bmp = withContext(Dispatchers.IO) { try { doc.render(i, wpx) } catch (e: Exception) { null } }
                    }
                    val b = bmp
                    if (b != null) {
                        Image(b.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    } else {
                        Box(Modifier.fillMaxWidth().height(420.dp).background(Color.White), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }
                }
            }
            Text(
                "${ls.firstVisibleItemIndex + 1} / ${doc.pageCount}",
                color = Color.White, fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp)
                    .background(Color(0x99000000), CircleShape).padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
    }
}

// ---------------- TEXT (viewer + editor) ----------------
@Composable
fun TextViewer(vm: AppViewModel, f: File) {
    val scope = rememberCoroutineScope()
    val tooBig = f.length() > 2_000_000
    var text by remember { mutableStateOf<String?>(null) }
    var orig by remember { mutableStateOf("") }
    var discard by remember { mutableStateOf(false) }
    LaunchedEffect(f.path) {
        val t = withContext(Dispatchers.IO) { if (tooBig) "" else try { f.readText() } catch (e: Exception) { "" } }
        text = t
        orig = t
    }
    val dirty = text != null && text != orig
    BackHandler(enabled = dirty) { discard = true }
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { if (dirty) discard = true else vm.pop() }) {
            if (dirty) {
                TextButton(onClick = {
                    val t = text ?: ""
                    scope.launch {
                        val ok = withContext(Dispatchers.IO) { try { f.writeText(t); true } catch (e: Exception) { false } }
                        if (ok) { orig = t; vm.tick++; vm.message = "Saved" } else vm.message = "Could not save"
                    }
                }) { Text("Save", fontWeight = FontWeight.Bold) }
            }
            ViewerMenu(vm, f, extras = convertExtras(vm, f))
        }
        if (tooBig) {
            EmptyState("This file is too large to preview (${fmtSize(f.length())}).")
        } else if (text == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            val mono = f.ext in setOf("json", "xml", "csv", "tsv", "html", "htm", "log", "kt", "java", "py", "js", "css", "yml", "yaml", "gradle", "sh", "kts", "c", "cpp", "h")
            TextField(
                value = text ?: "",
                onValueChange = { text = it },
                modifier = Modifier.fillMaxSize(),
                textStyle = TextStyle(fontSize = 14.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                )
            )
        }
    }
    if (discard) {
        AlertDialog(
            onDismissRequest = { discard = false },
            title = { Text("Unsaved changes") },
            text = { Text("Leave without saving your changes?") },
            confirmButton = { TextButton(onClick = { discard = false; vm.pop() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } }
        )
    }
}

// ---------------- OFFICE (docx / pptx / xlsx) ----------------
data class OfficeData(val text: String? = null, val rows: List<List<String>>? = null, val error: String? = null)

@Composable
fun OfficeViewer(vm: AppViewModel, f: File) {
    val data by produceState<OfficeData?>(null, f.path) {
        value = withContext(Dispatchers.IO) {
            try {
                when (f.ext) {
                    "xlsx" -> OfficeData(rows = xlsxRows(f))
                    "docx" -> OfficeData(text = docxText(f))
                    else -> OfficeData(text = pptxText(f))
                }
            } catch (e: Throwable) {
                OfficeData(error = e.message ?: "Could not read this file")
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) { ViewerMenu(vm, f, extras = convertExtras(vm, f)) }
        Text(
            "Simplified preview: text and tables only (formatting and images are not shown)",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        val d = data
        when {
            d == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            d.error != null -> EmptyState(d.error)
            d.rows != null -> {
                Box(Modifier.fillMaxSize().horizontalScroll(rememberScrollState())) {
                    LazyColumn {
                        items(d.rows) { r ->
                            Row {
                                r.forEach { c ->
                                    Box(Modifier.width(120.dp).border(0.5.dp, MaterialTheme.colorScheme.outlineVariant).padding(6.dp)) {
                                        Text(c, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                SelectionContainer {
                    Text(
                        (d.text ?: "").ifBlank { "(empty document)" },
                        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

// ---------------- ZIP ----------------
@Composable
fun ZipViewer(vm: AppViewModel, f: File) {
    val entries by produceState(emptyList<Pair<String, Long>>(), f.path) {
        value = withContext(Dispatchers.IO) {
            try {
                ZipFile(f).use { z -> z.entries().toList().map { it.name to it.size } }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) {
            TextButton(onClick = { vm.extract(f.path, stay = true) }) { Text("Extract", fontWeight = FontWeight.Bold) }
            ViewerMenu(vm, f)
        }
        Text(
            "${entries.size} item(s)  \u2022  ${fmtSize(f.length())}",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(Modifier.fillMaxSize()) {
            items(entries) { e ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (e.first.endsWith("/")) Icons.Outlined.Folder else Icons.Outlined.InsertDriveFile, null,
                        tint = if (e.first.endsWith("/")) FolderYellow else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(e.first, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    if (!e.first.endsWith("/")) Text(fmtSize(e.second.coerceAtLeast(0)), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ---------------- FALLBACK ----------------
@Composable
fun UnsupportedViewer(vm: AppViewModel, f: File, msg: String = "Preview isn't available inside the app for this file type.") {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        SimpleTop(f.name, onBack = { vm.pop() }) { ViewerMenu(vm, f) }
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            FileThumb(f, Modifier.size(96.dp), 48.dp)
            Spacer(Modifier.height(16.dp))
            Text(f.name, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(fmtSize(f.length()), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Text(msg, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
            Button(onClick = { openFile(ctx, f) }) { Text("Open with another app") }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.push(Screen.Details(f.path)) }) { Text("Details") }
        }
    }
}
