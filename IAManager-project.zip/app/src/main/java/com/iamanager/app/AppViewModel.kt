package com.iamanager.app

import android.app.Application
import android.content.Context
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("ia_prefs", Context.MODE_PRIVATE)
    private fun readLines(k: String): List<String> =
        (sp.getString(k, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeLines(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("\n")).apply()
    }

    val root: File = Environment.getExternalStorageDirectory()
    val trashDir: File = File(root, ".IATrash")

    // navigation
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()
    var selected by mutableStateOf<Set<String>>(emptySet())

    // settings
    var theme by mutableIntStateOf(sp.getInt("theme", 0))
    var showHidden by mutableStateOf(sp.getBoolean("hidden", false))
    var gridView by mutableStateOf(sp.getBoolean("grid", false))
    var sortBy by mutableIntStateOf(sp.getInt("sort", 0))

    // persisted lists
    var starred by mutableStateOf(readLines("starred"))
    var recent by mutableStateOf(readLines("recent"))
    var shared by mutableStateOf(readLines("shared"))
    var trash by mutableStateOf(readLines("trash"))
    var searches by mutableStateOf(readLines("searches"))

    // scan results
    var allFiles by mutableStateOf<List<File>>(emptyList())
    var allDirs by mutableStateOf<List<File>>(emptyList())
    var catSizes by mutableStateOf<Map<Cat, Long>>(emptyMap())
    var scanning by mutableStateOf(false)
    var tick by mutableIntStateOf(0)

    // ui state
    var message by mutableStateOf<String?>(null)
    var pickerMove by mutableStateOf<Boolean?>(null)
    var confirmDelete by mutableStateOf(false)
    var renameTarget by mutableStateOf<String?>(null)

    fun changeTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun setGrid(v: Boolean) { gridView = v; sp.edit().putBoolean("grid", v).apply() }
    fun setSort(v: Int) { sortBy = v; sp.edit().putInt("sort", v).apply() }
    fun setHidden(v: Boolean) { showHidden = v; sp.edit().putBoolean("hidden", v).apply(); refresh() }

    // ---- navigation ----
    fun push(s: Screen) { selected = emptySet(); stack.add(s) }
    fun pop() { selected = emptySet(); if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun goTab(s: Screen) { selected = emptySet(); stack.clear(); stack.add(s) }

    fun toggleSelect(p: String) { selected = if (p in selected) selected - p else selected + p }

    fun dismissDialogs() {
        pickerMove = null
        confirmDelete = false
        renameTarget = null
        if (current is Screen.Details) selected = emptySet()
    }

    // ---- scanning ----
    fun refresh() { tick++; scan() }

    fun scan() {
        viewModelScope.launch(Dispatchers.IO) {
            scanning = true
            val files = ArrayList<File>()
            val dirs = ArrayList<File>()
            val sizes = HashMap<Cat, Long>()
            val hidden = showHidden
            try {
                root.walkTopDown()
                    .onEnter { d ->
                        d == root || ((hidden || !d.name.startsWith(".")) && !(d.parentFile == root && d.name == "Android"))
                    }
                    .forEach { f ->
                        if (f.isDirectory) {
                            if (f != root) dirs.add(f)
                        } else if (hidden || !f.name.startsWith(".")) {
                            files.add(f)
                            val c = f.cat()
                            if (c != null) sizes[c] = (sizes[c] ?: 0L) + f.length()
                        }
                    }
            } catch (e: Exception) {
            }
            allFiles = files
            allDirs = dirs
            catSizes = sizes
            scanning = false
        }
    }

    // ---- recents / stars / shares ----
    fun toggleStar(p: String) {
        starred = if (p in starred) starred - p else starred + p
        writeLines("starred", starred)
    }

    fun starSelected() {
        val all = selected.all { it in starred }
        starred = if (all) starred - selected else (starred + selected).distinct()
        writeLines("starred", starred)
        selected = emptySet()
    }

    fun addRecent(p: String) {
        recent = (listOf(p) + recent.filter { it != p }).take(50)
        writeLines("recent", recent)
    }

    fun addSearch(q: String) {
        if (q.isBlank()) return
        searches = (listOf(q.trim()) + searches.filter { it != q.trim() }).take(8)
        writeLines("searches", searches)
    }

    fun clearSearches() { searches = emptyList(); writeLines("searches", searches) }

    fun open(ctx: Context, f: File) {
        if (f.isDirectory) push(Screen.Files(f.path)) else {
            addRecent(f.path)
            openFile(ctx, f)
        }
    }

    fun share(ctx: Context, files: List<File>) {
        shareFiles(ctx, files)
        shared = (files.filter { it.isFile }.map { it.path } + shared).distinct().take(100)
        writeLines("shared", shared)
        selected = emptySet()
    }

    // ---- file operations ----
    private fun launchOp(okMsg: String, work: () -> Unit) {
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try { work(); null } catch (e: Exception) { e.message ?: "Operation failed" }
            }
            message = err ?: okMsg
            selected = emptySet()
            refresh()
            if (err == null && (current is Screen.Details || current is Screen.Create)) pop()
        }
    }

    fun copyMove(dest: File, move: Boolean) {
        val files = selected.map { File(it) }
        launchOp((if (move) "Moved " else "Copied ") + files.size + " item(s)") {
            files.forEach { if (move) moveItem(it, dest) else copyItem(it, dest) }
        }
    }

    fun deleteSelected() {
        val files = selected.map { File(it) }
        launchOp("Moved ${files.size} item(s) to Recycle Bin") {
            val entries = files.map { moveToTrash(it, trashDir) }
            trash = trash + entries
            writeLines("trash", trash)
        }
    }

    fun rename(path: String, newName: String) {
        launchOp("Renamed") {
            val f = File(path)
            val t = File(f.parentFile, newName)
            if (newName.isBlank() || newName.contains("/")) throw IOException("Invalid name")
            if (t.exists()) throw IOException("A file with that name already exists")
            if (!f.renameTo(t)) throw IOException("Rename failed")
        }
    }

    fun createItem(dir: String, kind: String, ext: String, name: String) {
        launchOp("Created") {
            val clean = name.trim().ifEmpty { "New" }
            val full = if (ext.isNotEmpty() && !clean.endsWith(".$ext", true)) "$clean.$ext" else clean
            createNewItem(uniqueFile(File(dir), full), kind)
        }
    }

    fun compress() {
        val files = selected.map { File(it) }
        if (files.isEmpty()) return
        launchOp("Compressed to ZIP") {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val parent = files[0].parentFile ?: root
            zipFiles(files, uniqueFile(parent, "Archive_$stamp.zip"))
        }
    }

    fun extract(path: String) {
        val z = File(path)
        launchOp("Extracted") {
            unzip(z, uniqueFile(z.parentFile ?: root, z.nameWithoutExtension))
        }
    }

    fun restore(entry: String) {
        launchOp("Restored") {
            val src = File(trashDir, entry.substringBefore('\t'))
            val orig = File(entry.substringAfter('\t'))
            val parent = orig.parentFile ?: root
            parent.mkdirs()
            val dest = uniqueFile(parent, orig.name)
            if (!src.renameTo(dest)) {
                if (src.isDirectory) src.copyRecursively(dest) else src.copyTo(dest)
                src.deleteRecursively()
            }
            trash = trash - entry
            writeLines("trash", trash)
        }
    }

    fun deleteForever(entry: String) {
        launchOp("Deleted permanently") {
            File(trashDir, entry.substringBefore('\t')).deleteRecursively()
            trash = trash - entry
            writeLines("trash", trash)
        }
    }

    fun emptyTrash() {
        launchOp("Recycle Bin emptied") {
            trashDir.listFiles()?.forEach { it.deleteRecursively() }
            trash = emptyList()
            writeLines("trash", trash)
        }
    }
}
