/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DriveFileMove
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Slideshow
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.TextSnippet
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.RowScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import java.io.File

object Loader {
    @Volatile
    private var l: ImageLoader? = null
    fun get(ctx: Context): ImageLoader = l ?: synchronized(this) {
        l ?: ImageLoader.Builder(ctx.applicationContext)
            .components { add(VideoFrameDecoder.Factory()) }
            .crossfade(true)
            .build().also { l = it }
    }
}

val FolderYellow = Color(0xFFFFC107)

fun catColor(c: Cat?): Color = when (c) {
    Cat.IMAGES -> Color(0xFF34A853)
    Cat.VIDEOS -> Color(0xFF7C4DFF)
    Cat.AUDIO -> Color(0xFFFFA000)
    Cat.DOCS -> Blue
    Cat.ARCHIVES -> Color(0xFFE91E63)
    null -> Color(0xFF7A8699)
}

fun fileTint(f: File, isDir: Boolean = false): Color = when {
    isDir -> FolderYellow
    f.ext == "pdf" -> Color(0xFFE53935)
    f.ext in setOf("doc", "docx", "odt", "rtf") -> Color(0xFF1A73E8)
    f.ext in setOf("xls", "xlsx", "csv") -> Color(0xFF1E8E3E)
    f.ext in setOf("ppt", "pptx") -> Color(0xFFF4511E)
    else -> catColor(f.cat())
}

fun iconFor(f: File, isDir: Boolean = false): ImageVector = when {
    isDir -> Icons.Outlined.Folder
    f.ext == "pdf" -> Icons.Outlined.PictureAsPdf
    f.ext in setOf("doc", "docx", "odt", "rtf") -> Icons.Outlined.Description
    f.ext in setOf("xls", "xlsx", "csv") -> Icons.Outlined.TableChart
    f.ext in setOf("ppt", "pptx") -> Icons.Outlined.Slideshow
    f.ext in setOf("txt", "md") -> Icons.Outlined.TextSnippet
    f.cat() == Cat.ARCHIVES -> Icons.Outlined.FolderZip
    f.cat() == Cat.IMAGES -> Icons.Outlined.Image
    f.cat() == Cat.VIDEOS -> Icons.Outlined.Videocam
    f.cat() == Cat.AUDIO -> Icons.Outlined.MusicNote
    else -> Icons.Outlined.InsertDriveFile
}

class FMeta(val isDir: Boolean, val size: Long, val mtime: Long, val items: Int) {
    fun subtitle(): String =
        if (isDir) "$items items  \u2022  ${fmtDate(mtime)}" else "${fmtSize(size)}  \u2022  ${fmtDate(mtime)}"
}

@Composable
fun rememberMeta(f: File, tick: Int): FMeta = remember(f.path, tick) {
    val d = f.isDirectory
    FMeta(d, if (d) 0L else f.length(), f.lastModified(), if (d) (f.list()?.size ?: 0) else 0)
}

@Composable
fun FileThumb(f: File, modifier: Modifier, iconSize: Dp = 26.dp, isDir: Boolean = f.isDirectory) {
    val c = f.cat()
    val tint = fileTint(f, isDir)
    if (isDir) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Folder, null, tint = FolderYellow, modifier = Modifier.size(iconSize * 1.4f))
        }
    } else if (c == Cat.IMAGES || c == Cat.VIDEOS) {
        AsyncImage(
            model = f,
            imageLoader = Loader.get(LocalContext.current),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(RoundedCornerShape(10.dp)).background(tint.copy(alpha = 0.15f))
        )
    } else {
        Box(
            modifier.clip(RoundedCornerShape(10.dp)).background(tint.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { Icon(iconFor(f, false), null, tint = tint, modifier = Modifier.size(iconSize)) }
    }
}

@Composable
fun FileRow(f: File, vm: AppViewModel, onClick: () -> Unit) {
    val meta = rememberMeta(f, vm.tick)
    val sel = f.path in vm.selected
    val selecting = vm.selected.isNotEmpty()
    Row(
        Modifier.fillMaxWidth()
            .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(
                onClick = { if (selecting) vm.toggleSelect(f.path) else onClick() },
                onLongClick = { vm.toggleSelect(f.path) }
            )
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) {
            Checkbox(checked = sel, onCheckedChange = null)
            Spacer(Modifier.width(12.dp))
        }
        FileThumb(f, Modifier.size(46.dp), 26.dp, meta.isDir)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(
                meta.subtitle(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (f.path in vm.starred) Icon(Icons.Outlined.Star, null, tint = Color(0xFFFFB300), modifier = Modifier.size(18.dp))
        if (meta.isDir && !selecting) Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun FileGridCell(f: File, vm: AppViewModel, onClick: () -> Unit) {
    val meta = rememberMeta(f, vm.tick)
    val sel = f.path in vm.selected
    val selecting = vm.selected.isNotEmpty()
    Column(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .combinedClickable(
                onClick = { if (selecting) vm.toggleSelect(f.path) else onClick() },
                onLongClick = { vm.toggleSelect(f.path) }
            )
            .padding(4.dp)
    ) {
        Box {
            FileThumb(f, Modifier.fillMaxWidth().aspectRatio(1.15f), 36.dp, meta.isDir)
            if (selecting) Checkbox(checked = sel, onCheckedChange = null, modifier = Modifier.align(Alignment.TopStart))
        }
        Spacer(Modifier.height(4.dp))
        Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Text(
            (if (meta.isDir) "${meta.items} items" else fmtSize(meta.size)) + "  \u2022  " + fmtDay(meta.mtime),
            fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun FileCollection(
    files: List<File>,
    vm: AppViewModel,
    grid: Boolean,
    onOpen: (File) -> Unit,
    modifier: Modifier = Modifier,
    emptyText: String = "Nothing here",
    header: @Composable () -> Unit = {}
) {
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    if (grid) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            state = gridState,
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    header()
                    if (files.isEmpty()) EmptyState(emptyText)
                }
            }
            items(files, key = { it.path }) { f -> FileGridCell(f, vm) { onOpen(f) } }
        }
    } else {
        LazyColumn(modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 96.dp)) {
            item {
                Column {
                    header()
                    if (files.isEmpty()) EmptyState(emptyText)
                }
            }
            items(files, key = { it.path }) { f -> FileRow(f, vm) { onOpen(f) } }
        }
    }
}

@Composable
fun SimpleTop(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, "Back") }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
    )
}

@Composable
fun ChipsRow(labels: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        labels.forEachIndexed { i, l ->
            FilterChip(selected = i == sel, onClick = { onSel(i) }, label = { Text(l) }, shape = RoundedCornerShape(20.dp))
        }
    }
}

@Composable
fun SelMoreMenu(vm: AppViewModel, all: List<File>?, expanded: Boolean, onDismiss: () -> Unit) {
    DropdownMenu(expanded, onDismiss) {
        if (all != null) {
            DropdownMenuItem(text = { Text("Select all") }, onClick = {
                vm.selected = all.map { it.path }.toSet(); onDismiss()
            })
        }
        if (vm.selected.size == 1) {
            DropdownMenuItem(text = { Text("Details") }, onClick = {
                val p = vm.selected.first(); onDismiss(); vm.push(Screen.Details(p))
            })
            DropdownMenuItem(text = { Text("Rename") }, onClick = {
                vm.renameTarget = vm.selected.first(); onDismiss()
            })
        }
        DropdownMenuItem(text = { Text("Compress (ZIP)") }, onClick = { onDismiss(); vm.compress() })
        DropdownMenuItem(
            text = { Text(if (vm.selected.all { it in vm.starred }) "Remove star" else "Add star") },
            onClick = { onDismiss(); vm.starSelected() }
        )
    }
}

@Composable
fun SelectionTop(vm: AppViewModel, all: List<File>) {
    var menu by remember { mutableStateOf(false) }
    TopAppBar(
        title = { Text("${vm.selected.size} selected", fontWeight = FontWeight.SemiBold) },
        navigationIcon = { IconButton(onClick = { vm.selected = emptySet() }) { Icon(Icons.Outlined.Close, "Cancel") } },
        actions = {
            IconButton(onClick = { vm.confirmDelete = true }) { Icon(Icons.Outlined.DeleteOutline, "Delete") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "More") }
                SelMoreMenu(vm, all, menu) { menu = false }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
    )
}

@Composable
private fun BarBtn(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, modifier = Modifier.size(22.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun SelectionBottom(vm: AppViewModel) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Surface(tonalElevation = 3.dp, color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceAround) {
            BarBtn(Icons.Outlined.ContentCopy, "Copy") { vm.pickerMove = false }
            BarBtn(Icons.Outlined.DriveFileMove, "Move") { vm.pickerMove = true }
            BarBtn(Icons.Outlined.Share, "Share") { vm.share(ctx, vm.selected.map { File(it) }) }
            BarBtn(Icons.Outlined.DeleteOutline, "Delete") { vm.confirmDelete = true }
            Box {
                BarBtn(Icons.Outlined.MoreVert, "More") { menu = true }
                SelMoreMenu(vm, null, menu) { menu = false }
            }
        }
    }
}

@Composable
fun FolderPicker(vm: AppViewModel, move: Boolean) {
    var vol by remember { mutableStateOf(vm.root) }
    var dir by remember { mutableStateOf(vm.root) }
    val kids = remember(dir, vm.tick) { listDir(dir, vm.showHidden, 0).filter { it.isDirectory } }
    val volName = vm.storages.firstOrNull { it.root.path == vol.path }?.name ?: "Storage"
    AlertDialog(
        onDismissRequest = { vm.dismissDialogs() },
        title = { Text(if (move) "Move to" else "Copy to") },
        text = {
            Column {
                if (vm.storages.size > 1) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        vm.storages.forEach { v ->
                            FilterChip(
                                selected = vol.path == v.root.path,
                                onClick = { vol = v.root; dir = v.root },
                                label = { Text(v.name, maxLines = 1) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Text(relPath(vol, volName, dir), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    if (dir.path != vol.path) {
                        item {
                            Row(
                                Modifier.fillMaxWidth().clickable { dir = dir.parentFile ?: vol }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.ArrowBack, null, modifier = Modifier.size(22.dp))
                                Spacer(Modifier.width(12.dp)); Text("..")
                            }
                        }
                    }
                    items(kids, key = { it.path }) { k ->
                        Row(
                            Modifier.fillMaxWidth().clickable { dir = k }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Folder, null, tint = FolderYellow, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(12.dp)); Text(k.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.pickerMove = null
                vm.copyMove(dir, move)
            }) { Text("Select this folder") }
        },
        dismissButton = { TextButton(onClick = { vm.dismissDialogs() }) { Text("Cancel") } }
    )
}

@Composable
fun StorageCard(vm: AppViewModel, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val st = remember(vm.tick) { storageStats(vm.root) }
    val p = if (st.second > 0) st.first.toFloat() / st.second else 0f
    Card(
        onClick = onClick, modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { p }, modifier = Modifier.fillMaxSize(), strokeWidth = 7.dp,
                    color = Color(0xFF1DB9A6), trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Text("${(p * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(vm.rootName, fontWeight = FontWeight.SemiBold)
                Text(
                    "${fmtSize(st.first)} / ${fmtSize(st.second)}",
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                if (vm.storages.size > 1) Icons.Outlined.SwapHoriz else Icons.Outlined.ChevronRight, null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ActionRow(icon: ImageVector, tint: Color, title: String, sub: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Outlined.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
