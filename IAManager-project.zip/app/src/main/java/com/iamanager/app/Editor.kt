@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class EditParams(
    val rot: Int = 0,
    val flip: Boolean = false,
    val filter: Int = 0,
    val bright: Float = 0f,
    val contrast: Float = 1f,
    val sat: Float = 1f,
    val crop: Int = 0
)

val FILTER_NAMES = listOf("Original", "Vivid", "Warm", "Cool", "B&W")
val CROP_NAMES = listOf("Free", "1:1", "4:3", "16:9", "3:4")

fun decodeScaled(f: File, max: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val deg = try {
        when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90
            3 -> 180
            8 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }
    if (deg == 0) return bmp
    val m = Matrix()
    m.postRotate(deg.toFloat())
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

private fun contrastM(c: Float, b: Float = 0f): ColorMatrix {
    val t = (-0.5f * c + 0.5f) * 255f + b
    return ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f))
}

fun colorMatrixFor(p: EditParams): ColorMatrix {
    val cm = ColorMatrix()
    when (p.filter) {
        1 -> {
            val s = ColorMatrix(); s.setSaturation(1.45f)
            cm.postConcat(s); cm.postConcat(contrastM(1.1f))
        }
        2 -> cm.postConcat(ColorMatrix(floatArrayOf(1.12f, 0f, 0f, 0f, 8f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0.85f, 0f, -8f, 0f, 0f, 0f, 1f, 0f)))
        3 -> cm.postConcat(ColorMatrix(floatArrayOf(0.88f, 0f, 0f, 0f, -6f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.15f, 0f, 10f, 0f, 0f, 0f, 1f, 0f)))
        4 -> {
            val s = ColorMatrix(); s.setSaturation(0f)
            cm.postConcat(s)
        }
    }
    val s = ColorMatrix(); s.setSaturation(p.sat)
    cm.postConcat(s)
    cm.postConcat(contrastM(p.contrast, p.bright * 2.55f))
    return cm
}

fun renderEdit(src: Bitmap, p: EditParams): Bitmap {
    var b = src
    if (p.rot % 360 != 0 || p.flip) {
        val m = Matrix()
        m.postRotate(p.rot.toFloat())
        if (p.flip) m.postScale(-1f, 1f)
        b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    val ratio = when (p.crop) {
        1 -> 1f
        2 -> 4f / 3f
        3 -> 16f / 9f
        4 -> 3f / 4f
        else -> 0f
    }
    if (ratio > 0f) {
        val w = b.width
        val h = b.height
        var cw = w
        var ch = (w / ratio).toInt()
        if (ch > h) {
            ch = h
            cw = (h * ratio).toInt()
        }
        cw = cw.coerceIn(1, w)
        ch = ch.coerceIn(1, h)
        b = Bitmap.createBitmap(b, (w - cw) / 2, (h - ch) / 2, cw, ch)
    }
    val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(colorMatrixFor(p))
    Canvas(out).drawBitmap(b, 0f, 0f, paint)
    return out
}

@Composable
private fun ToolBtn(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(22.dp))
                .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
        }
        Text(label, fontSize = 11.sp, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun EditorScreen(vm: AppViewModel, path: String) {
    val file = File(path)
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf<Bitmap?>(null) }
    var params by remember { mutableStateOf(EditParams()) }
    var tool by remember { mutableIntStateOf(1) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(path) { src = withContext(Dispatchers.IO) { decodeScaled(file, 1280) } }
    LaunchedEffect(src, params) {
        val s = src ?: return@LaunchedEffect
        preview = withContext(Dispatchers.Default) { renderEdit(s, params) }
    }
    val thumbs = remember(src) {
        val s = src
        if (s == null) emptyList() else {
            val h = (96f * s.height / s.width).toInt().coerceAtLeast(1)
            val small = Bitmap.createScaledBitmap(s, 96, h, true)
            FILTER_NAMES.indices.map { renderEdit(small, EditParams(filter = it)) }
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
        SimpleTop("Edit Photo", onBack = { vm.pop() }) {
            TextButton(
                enabled = !saving && src != null,
                onClick = {
                    saving = true
                    scope.launch {
                        val res = withContext(Dispatchers.IO) {
                            try {
                                val full = decodeScaled(file, 3072) ?: throw IllegalStateException("decode")
                                val out = renderEdit(full, params)
                                val target = uniqueFile(file.parentFile ?: vm.root, file.nameWithoutExtension + "_edited.jpg")
                                FileOutputStream(target).use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                                target.name
                            } catch (e: Throwable) {
                                null
                            }
                        }
                        saving = false
                        vm.message = if (res != null) "Saved: $res" else "Could not save image"
                        if (res != null) {
                            vm.refresh()
                            vm.pop()
                        }
                    }
                }
            ) { Text(if (saving) "Saving..." else "Save", fontWeight = FontWeight.Bold) }
        }
        Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
            val pv = preview
            if (pv != null) {
                Image(bitmap = pv.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                CircularProgressIndicator()
            }
        }
        // option panel
        Box(Modifier.fillMaxWidth().heightIn(min = 96.dp).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            when (tool) {
                0 -> Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CROP_NAMES.forEachIndexed { i, n ->
                        FilterChip(selected = params.crop == i, onClick = { params = params.copy(crop = i) }, label = { Text(n) })
                    }
                }
                1 -> LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(FILTER_NAMES) { i, n ->
                        Column(
                            Modifier.clickable { params = params.copy(filter = i) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val t = thumbs.getOrNull(i)
                            Box(
                                Modifier.size(60.dp).clip(RoundedCornerShape(8.dp))
                                    .border(
                                        if (params.filter == i) 2.dp else 0.dp,
                                        MaterialTheme.colorScheme.primary,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                if (t != null) Image(t.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            Text(
                                n, fontSize = 11.sp,
                                color = if (params.filter == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                2 -> Column(Modifier.padding(horizontal = 20.dp)) {
                    Text("Brightness", fontSize = 12.sp)
                    Slider(value = params.bright, onValueChange = { params = params.copy(bright = it) }, valueRange = -100f..100f)
                    Text("Contrast", fontSize = 12.sp)
                    Slider(value = params.contrast, onValueChange = { params = params.copy(contrast = it) }, valueRange = 0.5f..1.5f)
                    Text("Saturation", fontSize = 12.sp)
                    Slider(value = params.sat, onValueChange = { params = params.copy(sat = it) }, valueRange = 0f..2f)
                }
                else -> Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    OutlinedButton(onClick = { params = params.copy(flip = !params.flip) }) {
                        Icon(Icons.Outlined.Flip, null); Spacer(Modifier.width(6.dp)); Text("Flip")
                    }
                    OutlinedButton(onClick = { params = EditParams() }) {
                        Icon(Icons.Outlined.Undo, null); Spacer(Modifier.width(6.dp)); Text("Reset all")
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
            ToolBtn(Icons.Outlined.Crop, "Crop", tool == 0) { tool = 0 }
            ToolBtn(Icons.Outlined.RotateRight, "Rotate", false) { params = params.copy(rot = (params.rot + 90) % 360) }
            ToolBtn(Icons.Outlined.AutoAwesome, "Filter", tool == 1) { tool = 1 }
            ToolBtn(Icons.Outlined.Tune, "Adjust", tool == 2) { tool = 2 }
            ToolBtn(Icons.Outlined.MoreHoriz, "More", tool == 3) { tool = 3 }
        }
    }
}
