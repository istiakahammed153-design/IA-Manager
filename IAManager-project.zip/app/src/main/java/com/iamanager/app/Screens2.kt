/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.iamanager.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------------- DETAILS ----------------
@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Column {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(value, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DetailAction(icon: ImageVector, label: String, tint: Color = MaterialTheme.colorScheme.onSurface, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(18.dp))
        Text(label, color = tint)
    }
}

@Composable
fun DetailsScreen(vm: AppViewModel, path: String) {
    val ctx = LocalContext.current
    val f = File(path)
    if (!f.exists()) {
        LaunchedEffect(path) { vm.pop() }
        return
    }
    val cat = f.cat()
    val res = remember(path) { if (cat == Cat.IMAGES) imageSize(f) else null }
    val size by produceState(f.length(), path) {
        value = withContext(Dispatchers.IO) { dirSize(f) }
    }
    val card = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    Column(Modifier.fillMaxSize()) {
        SimpleTop("File Details", onBack = { vm.pop() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            FileThumb(f, Modifier.size(96.dp), 48.dp)
            Spacer(Modifier.height(10.dp))
            Text(f.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
            Text(
                fmtSize(size) + if (f.isDirectory) "" else "  \u2022  " + f.ext.uppercase().ifEmpty { "FILE" },
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = card) {
                InfoRow(Icons.Outlined.Folder, "Location", relPath(vm.root, vm.rootName, f.parentFile ?: vm.root))
                InfoRow(Icons.Outlined.InsertDriveFile, "Size", fmtSize(size))
                if (f.isDirectory) InfoRow(Icons.Outlined.Description, "Items", "${f.list()?.size ?: 0}")
                if (res != null) InfoRow(Icons.Outlined.Image, "Resolution", res)
                InfoRow(Icons.Outlined.Info, "Created", fmtDate(createdTime(f)))
                InfoRow(Icons.Outlined.Edit, "Modified", fmtDate(f.lastModified()))
            }
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = card) {
                if (f.isFile) {
                    DetailAction(Icons.Outlined.OpenInNew, "Open") { vm.open(ctx, f) }
                    DetailAction(Icons.Outlined.OpenInNew, "Open with another app") { openFile(ctx, f) }
                    DetailAction(Icons.Outlined.Share, "Share") { vm.share(ctx, listOf(f)) }
                }
                if (cat == Cat.IMAGES) DetailAction(Icons.Outlined.Edit, "Edit (Photo Editor)") { vm.push(Screen.Editor(path)) }
                if (f.ext == "zip") DetailAction(Icons.Outlined.FolderZip, "Extract here") { vm.extract(path) }
                DetailAction(
                    if (path in vm.starred) Icons.Outlined.Star else Icons.Outlined.StarBorder,
                    if (path in vm.starred) "Remove star" else "Add star"
                ) { vm.toggleStar(path) }
                DetailAction(Icons.Outlined.DriveFileRenameOutline, "Rename") { vm.selected = setOf(path); vm.renameTarget = path }
                DetailAction(Icons.Outlined.DriveFileMove, "Move") { vm.selected = setOf(path); vm.pickerMove = true }
                DetailAction(Icons.Outlined.ContentCopy, "Copy") { vm.selected = setOf(path); vm.pickerMove = false }
                DetailAction(Icons.Outlined.DeleteOutline, "Delete", Color(0xFFE53935)) { vm.selected = setOf(path); vm.confirmDelete = true }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ---------------- CREATE NEW ----------------
private data class NewKind(val label: String, val icon: ImageVector, val tint: Color, val ext: String, val key: String, val defName: String)

private val NEW_KINDS = listOf(
    NewKind("Folder", Icons.Outlined.Folder, FolderYellow, "", "dir", "New Folder"),
    NewKind("Text File", Icons.Outlined.TextSnippet, Color(0xFF1A73E8), "txt", "txt", "New Text File")
)

private val CONV_ICONS = mapOf(
    Conv.IMG_TO_PDF to Pair(Icons.Outlined.PictureAsPdf, Color(0xFFE53935)),
    Conv.PDF_TO_IMG to Pair(Icons.Outlined.Image, Color(0xFF34A853)),
    Conv.PDF_TO_DOCX to Pair(Icons.Outlined.Description, Color(0xFF1A73E8)),
    Conv.DOC_TO_PDF to Pair(Icons.Outlined.PictureAsPdf, Color(0xFFF4511E)),
    Conv.XLSX_TO_CSV to Pair(Icons.Outlined.TableChart, Color(0xFF1E8E3E)),
    Conv.IMG_FORMAT to Pair(Icons.Outlined.AutoAwesome, Color(0xFF7C4DFF))
)

@Composable
fun CreateScreen(vm: AppViewModel, dir: String) {
    var pending by remember { mutableStateOf<NewKind?>(null) }
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        SimpleTop("Create New", onBack = { vm.pop() })
        Text(
            relPath(vm.root, vm.rootName, File(dir)), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        Column(Modifier.verticalScroll(rememberScrollState())) {
            NEW_KINDS.forEach { k ->
                ActionRow(k.icon, k.tint, k.label, "Empty " + k.label.lowercase()) { pending = k; name = k.defName }
            }
            Text(
                "Create from your files", fontWeight = FontWeight.Bold, fontSize = 16.sp,
                modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp)
            )
            Text(
                "Pick files already on your phone and convert them. The new file is saved in this folder.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Conv.values().forEach { c ->
                val ic = CONV_ICONS[c] ?: Pair(Icons.Outlined.InsertDriveFile, Color.Gray)
                ActionRow(ic.first, ic.second, c.title, c.sub) { vm.push(Screen.Pick(c, dir)) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    val p = pending
    if (p != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("New ${p.label}") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = {
                TextButton(onClick = { pending = null; vm.createItem(dir, p.key, p.ext, name) }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun PickScreen(vm: AppViewModel, conv: Conv, dir: String) {
    val candidates = remember(vm.allFiles, conv) {
        vm.allFiles.filter { it.ext in conv.exts }.sortedByDescending { it.lastModified() }
    }
    var sel by remember { mutableStateOf(listOf<String>()) }
    var fmtDlg by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        SimpleTop(conv.title, onBack = { vm.pop() })
        Text(
            if (conv.multi) "Select one or more files" else "Select a file",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        if (candidates.isEmpty()) {
            if (vm.scanning) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else EmptyState("No matching files found on this storage", Modifier.weight(1f))
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(candidates, key = { it.path }) { f ->
                    val on = f.path in sel
                    val order = sel.indexOf(f.path) + 1
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                sel = if (conv.multi) (if (on) sel - f.path else sel + f.path) else listOf(f.path)
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (conv.multi) Checkbox(checked = on, onCheckedChange = null) else RadioButton(selected = on, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        FileThumb(f, Modifier.size(46.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(
                                fmtSize(f.length()) + "  \u2022  " + fmtDay(f.lastModified()),
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (conv == Conv.IMG_TO_PDF && on) Text("#$order", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Surface(tonalElevation = 3.dp) {
            Button(
                onClick = {
                    if (conv == Conv.IMG_FORMAT) fmtDlg = true
                    else vm.convert(conv, sel.map { File(it) }, File(dir))
                },
                enabled = sel.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) { Text(if (sel.isEmpty()) "Select files" else "Create (${sel.size})") }
        }
    }
    if (fmtDlg) {
        val opts = listOf("PNG", "JPG", "WEBP")
        ChoiceDialog("Convert to", opts, -1, { i ->
            fmtDlg = false
            vm.convert(conv, sel.map { File(it) }, File(dir), opts[i].lowercase())
        }) { fmtDlg = false }
    }
}

// ---------------- SETTINGS ----------------
@Composable
private fun ChoiceDialog(title: String, options: List<String>, selected: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEachIndexed { i, o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(i) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = i == selected, onClick = null)
                        Spacer(Modifier.width(12.dp)); Text(o)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, value: String?, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(16.dp))
        Text(title, modifier = Modifier.weight(1f))
        if (value != null) Text(value, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        trailing()
    }
}

@Composable
private fun GroupTitle(t: String) {
    Text(t, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
}

fun cacheSize(ctx: android.content.Context): Long = ctx.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var dlg by remember { mutableIntStateOf(0) }
    var cache by remember { mutableLongStateOf(cacheSize(ctx)) }
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0" } catch (e: Exception) { "1.0.0" } }
    val themes = listOf("System Default", "Light", "Dark")
    val views = listOf("List View", "Grid View")
    val sorts = listOf("Name", "Date", "Size")
    Column(Modifier.fillMaxSize()) {
        SimpleTop("Settings", onBack = { vm.pop() })
        Column(Modifier.verticalScroll(rememberScrollState())) {
            GroupTitle("General")
            SettingRow(Icons.Outlined.Palette, "Theme", themes[vm.theme], { dlg = 1 })
            SettingRow(Icons.Outlined.Visibility, "Show Hidden Files", null, { vm.setHidden(!vm.showHidden) }) {
                Switch(checked = vm.showHidden, onCheckedChange = { vm.setHidden(it) })
            }
            SettingRow(Icons.Outlined.ViewList, "Default View", views[if (vm.gridView) 1 else 0], { dlg = 2 })
            SettingRow(Icons.Outlined.Sort, "Sort By", sorts[vm.sortBy], { dlg = 3 })
            GroupTitle("Storage")
            SettingRow(Icons.Outlined.Storage, "Storage Info", null, { dlg = 4 })
            SettingRow(Icons.Outlined.CleaningServices, "Clear Cache", fmtSize(cache), {
                ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                Loader.get(ctx).memoryCache?.clear()
                cache = cacheSize(ctx)
                vm.message = "Cache cleared"
            })
            GroupTitle("About")
            SettingRow(Icons.Outlined.Info, "App Version", version, {})
            SettingRow(Icons.Outlined.Person, "Developer", Owner.name, {})
            Text(
                Owner.notice + "\nUnauthorized copying, modification or redistribution of this app or its source code is prohibited.",
                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
        }
    }
    when (dlg) {
        1 -> ChoiceDialog("Theme", themes, vm.theme, { vm.changeTheme(it); dlg = 0 }) { dlg = 0 }
        2 -> ChoiceDialog("Default View", views, if (vm.gridView) 1 else 0, { vm.setGrid(it == 1); dlg = 0 }) { dlg = 0 }
        3 -> ChoiceDialog("Sort By", sorts, vm.sortBy, { vm.setSort(it); dlg = 0 }) { dlg = 0 }
        4 -> {
            val st = remember { storageStats(vm.root) }
            AlertDialog(
                onDismissRequest = { dlg = 0 },
                title = { Text("Storage Info") },
                text = {
                    Column {
                        Text("Total: ${fmtSize(st.second)}")
                        Text("Used: ${fmtSize(st.first)}")
                        Text("Free: ${fmtSize(st.second - st.first)}")
                        Spacer(Modifier.height(8.dp))
                        Cat.values().forEach { Text("${it.title}: ${fmtSize(vm.catSizes[it] ?: 0L)}", fontSize = 13.sp) }
                    }
                },
                confirmButton = { TextButton(onClick = { dlg = 0 }) { Text("OK") } }
            )
        }
    }
}
