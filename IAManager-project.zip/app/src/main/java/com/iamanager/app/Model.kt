package com.iamanager.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.StatFs
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class Cat(val title: String, val exts: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")),
    VIDEOS("Videos", setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "wmv", "m4v")),
    AUDIO("Audio", setOf("mp3", "wav", "aac", "m4a", "ogg", "flac", "opus", "amr", "wma")),
    DOCS("Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "md", "json", "xml", "html", "epub")),
    ARCHIVES("Archives", setOf("zip", "rar", "7z", "tar", "gz"))
}

sealed interface Screen {
    data object Home : Screen
    data class Files(val path: String) : Screen
    data class Category(val cat: Cat, val pickEdit: Boolean = false) : Screen
    data object Search : Screen
    data class Details(val path: String) : Screen
    data class Editor(val path: String) : Screen
    data class Create(val dir: String) : Screen
    data object Settings : Screen
    data object Shared : Screen
    data object Recent : Screen
    data object Starred : Screen
    data object Trash : Screen
}

val File.ext: String get() = extension.lowercase(Locale.ROOT)

fun File.cat(): Cat? = if (isDirectory) null else Cat.values().firstOrNull { ext in it.exts }

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < u.size - 1) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, u[i])
}

fun fmtDate(ms: Long): String = SimpleDateFormat("MMM d, yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
fun fmtDay(ms: Long): String = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ms))

fun createdTime(f: File): Long = try {
    if (Build.VERSION.SDK_INT >= 26) {
        java.nio.file.Files.readAttributes(f.toPath(), java.nio.file.attribute.BasicFileAttributes::class.java)
            .creationTime().toMillis()
    } else f.lastModified()
} catch (e: Exception) {
    f.lastModified()
}

fun relPath(root: File, f: File): String {
    val parts = f.path.removePrefix(root.path).split("/").filter { it.isNotEmpty() }
    return (listOf("Internal Storage") + parts).joinToString(" \u203A ")
}

fun storageStats(root: File): Pair<Long, Long> {
    return try {
        val s = StatFs(root.path)
        val total = s.totalBytes
        Pair(total - s.availableBytes, total)
    } catch (e: Exception) {
        Pair(0L, 0L)
    }
}

fun imageSize(f: File): String? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    return if (o.outWidth > 0) "${o.outWidth} \u00D7 ${o.outHeight}" else null
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = name.substringBeforeLast('.', name)
    val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
    var i = 1
    do {
        f = File(dir, "$base ($i)$ext")
        i++
    } while (f.exists())
    return f
}

fun sortFiles(list: List<File>, sortBy: Int): List<File> {
    val cmp: Comparator<File> = when (sortBy) {
        1 -> compareByDescending<File> { it.lastModified() }
        2 -> compareByDescending<File> { if (it.isDirectory) 0L else it.length() }
        else -> compareBy<File> { it.name.lowercase() }
    }
    return list.sortedWith(compareBy<File> { !it.isDirectory }.then(cmp))
}

fun listDir(dir: File, showHidden: Boolean, sortBy: Int): List<File> {
    val kids = (dir.listFiles() ?: emptyArray()).filter { showHidden || !it.name.startsWith(".") }
    return sortFiles(kids, sortBy)
}

fun dirSize(f: File): Long = if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

fun copyItem(src: File, destDir: File): File {
    val dest = uniqueFile(destDir, src.name)
    if (src.isDirectory) {
        if ((dest.path + "/").startsWith(src.path + "/")) throw IOException("Cannot copy a folder into itself")
        src.copyRecursively(dest)
    } else {
        src.copyTo(dest)
    }
    return dest
}

fun moveItem(src: File, destDir: File): File {
    if (src.parentFile == destDir) return src
    val dest = uniqueFile(destDir, src.name)
    if (src.isDirectory && (dest.path + "/").startsWith(src.path + "/")) throw IOException("Cannot move a folder into itself")
    if (!src.renameTo(dest)) {
        if (src.isDirectory) src.copyRecursively(dest) else src.copyTo(dest)
        src.deleteRecursively()
    }
    return dest
}

/** Returns trash entry "storedName<TAB>originalPath" */
fun moveToTrash(f: File, trashDir: File): String {
    trashDir.mkdirs()
    val t = uniqueFile(trashDir, f.name)
    if (!f.renameTo(t)) {
        if (f.isDirectory) f.copyRecursively(t) else f.copyTo(t)
        f.deleteRecursively()
    }
    return t.name + "\t" + f.path
}

fun zipFiles(files: List<File>, out: File) {
    ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
        fun add(f: File, prefix: String) {
            if (f.isDirectory) {
                val kids = f.listFiles() ?: return
                if (kids.isEmpty()) {
                    z.putNextEntry(ZipEntry(prefix + f.name + "/"))
                    z.closeEntry()
                }
                kids.forEach { add(it, prefix + f.name + "/") }
            } else {
                z.putNextEntry(ZipEntry(prefix + f.name))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        files.forEach { add(it, "") }
    }
}

fun unzip(zip: File, dest: File) {
    dest.mkdirs()
    val canon = dest.canonicalPath
    ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zi ->
        var e = zi.nextEntry
        while (e != null) {
            val out = File(dest, e.name)
            if (!out.canonicalPath.startsWith(canon + File.separator)) throw IOException("Invalid zip entry")
            if (e.isDirectory) {
                out.mkdirs()
            } else {
                out.parentFile?.mkdirs()
                FileOutputStream(out).use { zi.copyTo(it) }
            }
            zi.closeEntry()
            e = zi.nextEntry
        }
    }
}

// ---------- Creating new files ----------

private fun writeZipText(out: File, entries: List<Pair<String, String>>) {
    ZipOutputStream(FileOutputStream(out)).use { z ->
        for ((name, text) in entries) {
            z.putNextEntry(ZipEntry(name))
            z.write(text.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }
}

private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
private const val REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
private const val OD_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

fun createNewItem(target: File, kind: String) {
    when (kind) {
        "dir" -> if (!target.mkdirs()) throw IOException("Could not create folder")
        "txt" -> target.writeText("")
        "pdf" -> {
            val sb = StringBuilder("%PDF-1.4\n")
            val offs = ArrayList<Int>()
            val objs = listOf(
                "<</Type/Catalog/Pages 2 0 R>>",
                "<</Type/Pages/Kids[3 0 R]/Count 1>>",
                "<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]>>"
            )
            objs.forEachIndexed { i, o ->
                offs.add(sb.length)
                sb.append("${i + 1} 0 obj\n$o\nendobj\n")
            }
            val x = sb.length
            sb.append("xref\n0 4\n0000000000 65535 f \n")
            offs.forEach { sb.append(String.format(Locale.US, "%010d 00000 n \n", it)) }
            sb.append("trailer\n<</Size 4/Root 1 0 R>>\nstartxref\n$x\n%%EOF\n")
            target.writeBytes(sb.toString().toByteArray(Charsets.ISO_8859_1))
        }
        "docx" -> writeZipText(
            target, listOf(
                "[Content_Types].xml" to "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>",
                "_rels/.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/officeDocument\" Target=\"word/document.xml\"/></Relationships>",
                "word/document.xml" to "$XML<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body><w:p/></w:body></w:document>"
            )
        )
        "xlsx" -> writeZipText(
            target, listOf(
                "[Content_Types].xml" to "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>",
                "_rels/.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
                "xl/workbook.xml" to "$XML<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$OD_REL\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>",
                "xl/_rels/workbook.xml.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>",
                "xl/worksheets/sheet1.xml" to "$XML<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData/></worksheet>"
            )
        )
        "zip" -> {
            val b = ByteArray(22)
            b[0] = 0x50; b[1] = 0x4B; b[2] = 0x05; b[3] = 0x06
            target.writeBytes(b)
        }
        else -> throw IOException("Unknown type")
    }
}

// ---------- Open / share ----------

fun mimeOf(f: File): String = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.ext) ?: "*/*"

fun uriOf(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)

fun openFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriOf(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open file", Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(ctx: Context, files: List<File>) {
    val fs = files.filter { it.isFile }
    if (fs.isEmpty()) {
        Toast.makeText(ctx, "Folders cannot be shared", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val i = if (fs.size == 1) {
            Intent(Intent.ACTION_SEND).setType(mimeOf(fs[0])).putExtra(Intent.EXTRA_STREAM, uriOf(ctx, fs[0]))
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(fs.map { uriOf(ctx, it) }))
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot share", Toast.LENGTH_SHORT).show()
    }
}
