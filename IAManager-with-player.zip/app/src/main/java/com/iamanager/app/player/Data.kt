package com.iamanager.app.player

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.io.OutputStream
import java.util.Locale

data class VideoItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val path: String? = null,
    val dateAdded: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val isSdCard: Boolean = false,
    val isAudio: Boolean = false,
    val mime: String = ""
) {
    /** The key under which favorites, resume positions and bookmarks are remembered. */
    val prefKey: String
        get() = uri.toString()
}

private val AUDIO_EXTENSIONS = setOf(
    "mp3", "m4a", "aac", "wav", "flac", "ogg", "oga", "opus", "amr", "awb", "wma",
    "mka", "mid", "midi", "ac3", "eac3", "ec3", "dts", "ape", "aif", "aiff", "caf"
)

/** True if the file name looks like an audio file (by extension or registered MIME type). */
fun isAudioName(name: String): Boolean {
    val dot = name.lastIndexOf('.')
    if (dot < 0) return false
    val ext = name.substring(dot + 1).lowercase(Locale.ROOT)
    if (AUDIO_EXTENSIONS.contains(ext)) return true
    val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
    return mime != null && mime.startsWith("audio/")
}

/** Hands the playlist from the list screen to the player screen without going through Intent extras. */
object PlaylistHolder {
    var items: List<VideoItem> = emptyList()
    var index: Int = 0
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun formatTime(ms: Long): String {
    val total = if (ms < 0) 0L else ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) {
        String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%02d:%02d", m, s)
    }
}

fun formatSize(bytes: Long): String {
    if (bytes <= 0) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    return when {
        mb >= 1024 -> String.format(Locale.US, "%.2f GB", mb / 1024.0)
        mb >= 1 -> String.format(Locale.US, "%.0f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb)
    }
}

fun resolutionLabel(w: Int, h: Int): String {
    if (w <= 0 || h <= 0) return ""
    val side = minOf(w, h)
    return when {
        side >= 2000 -> "4K"
        side >= 1400 -> "2K"
        else -> side.toString() + "p"
    }
}

fun queryName(context: Context, uri: Uri): String {
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getString(0)
                if (!n.isNullOrBlank()) return n
            }
        }
    } catch (e: Exception) {
        // fall through to the path-based name
    }
    return uri.lastPathSegment ?: "Video"
}

/** Favorites, bookmarks, resume positions and all settings, kept in SharedPreferences. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("player_prefs", Context.MODE_PRIVATE)

    fun getInt(c: Context, key: String, def: Int): Int = sp(c).getInt(key, def)
    fun putInt(c: Context, key: String, v: Int) {
        sp(c).edit().putInt(key, v).apply()
    }

    fun getBool(c: Context, key: String, def: Boolean): Boolean = sp(c).getBoolean(key, def)
    fun putBool(c: Context, key: String, v: Boolean) {
        sp(c).edit().putBoolean(key, v).apply()
    }

    fun getStr(c: Context, key: String, def: String): String = sp(c).getString(key, def) ?: def
    fun putStr(c: Context, key: String, v: String) {
        sp(c).edit().putString(key, v).apply()
    }

    fun remove(c: Context, key: String) {
        sp(c).edit().remove(key).apply()
    }

    fun sortMode(c: Context): Int = getInt(c, "sort_mode", 0)
    fun showStatus(c: Context): Boolean = getBool(c, "show_status", true)

    fun favorites(c: Context): Set<String> = sp(c).getStringSet("fav", emptySet()) ?: emptySet()

    fun isFavorite(c: Context, id: String): Boolean = favorites(c).contains(id)

    /** Returns true if the item is now a favorite, false if it was removed. */
    fun toggleFavorite(c: Context, id: String): Boolean {
        val set = favorites(c).toMutableSet()
        val added = if (set.contains(id)) {
            set.remove(id)
            false
        } else {
            set.add(id)
            true
        }
        sp(c).edit().putStringSet("fav", set).apply()
        return added
    }

    fun resume(c: Context, id: String): Long = sp(c).getLong("pos_$id", 0L)

    fun setResume(c: Context, id: String, positionMs: Long) {
        sp(c).edit().putLong("pos_$id", positionMs).apply()
    }

    fun bookmarks(c: Context, id: String): List<Long> {
        val raw = sp(c).getString("bm_$id", "") ?: ""
        return raw.split(",").mapNotNull { it.toLongOrNull() }.sorted()
    }

    fun addBookmark(c: Context, id: String, positionMs: Long) {
        val list = bookmarks(c, id).toMutableList()
        if (!list.contains(positionMs)) list.add(positionMs)
        sp(c).edit().putString("bm_$id", list.joinToString(",")).apply()
    }

    fun clearBookmarks(c: Context, id: String) {
        sp(c).edit().remove("bm_$id").apply()
    }

    /** Removes everything we remember about a video (after it was deleted or moved). */
    fun forget(c: Context, id: String) {
        val set = favorites(c).toMutableSet()
        set.remove(id)
        sp(c).edit()
            .putStringSet("fav", set)
            .remove("pos_$id")
            .remove("bm_$id")
            .apply()
    }
}

/** Saves a finished file (clip, audio, screenshot, restored file) into the public media folders. */
object MediaSaver {
    enum class Kind(val base29: String, val legacyDir: String) {
        VIDEO("Movies", Environment.DIRECTORY_MOVIES),
        AUDIO("Music", Environment.DIRECTORY_MUSIC),
        IMAGE("Pictures", Environment.DIRECTORY_PICTURES),
        FILE("Download", Environment.DIRECTORY_DOWNLOADS)
    }

    /** Returns a short folder description such as "Movies/VideoPlayer", or null if saving failed. */
    fun saveFile(
        ctx: Context,
        src: File,
        displayName: String,
        mime: String,
        kind: Kind,
        folder: String = "IAManager"
    ): String? = saveStream(ctx, displayName, mime, kind, folder) { out ->
        src.inputStream().use { it.copyTo(out) }
    }

    /**
     * Creates the public file and lets [writer] fill it. If writing fails, the half-written file is removed
     * again (it used to stay behind as an empty "pending" entry).
     */
    fun saveStream(
        ctx: Context,
        displayName: String,
        mime: String,
        kind: Kind,
        folder: String = "IAManager",
        writer: (OutputStream) -> Unit
    ): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val collection = when (kind) {
                    Kind.VIDEO -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    Kind.AUDIO -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    Kind.IMAGE -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                    Kind.FILE -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }
                val rel = kind.base29 + "/" + folder
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                values.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val resolver = ctx.contentResolver
                val dest = resolver.insert(collection, values)
                if (dest == null) {
                    null
                } else {
                    try {
                        val out = resolver.openOutputStream(dest) ?: throw java.io.IOException("No output stream")
                        out.use { writer(it) }
                    } catch (e: Exception) {
                        try {
                            resolver.delete(dest, null, null)
                        } catch (x: Exception) {
                            // ignore
                        }
                        throw e
                    }
                    val done = ContentValues()
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(dest, done, null, null)
                    rel
                }
            } else {
                val canWrite = ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED
                val root = if (canWrite) {
                    Environment.getExternalStoragePublicDirectory(kind.legacyDir)
                } else {
                    ctx.getExternalFilesDir(kind.legacyDir)
                }
                if (root == null) {
                    null
                } else {
                    val dir = File(root, folder)
                    dir.mkdirs()
                    val dot = displayName.lastIndexOf('.')
                    val b = if (dot > 0) displayName.substring(0, dot) else displayName
                    val x = if (dot > 0) displayName.substring(dot) else ""
                    var target = File(dir, displayName)
                    var i = 1
                    while (target.exists()) {
                        target = File(dir, b + " (" + i + ")" + x)
                        i++
                    }
                    try {
                        java.io.FileOutputStream(target).use { writer(it) }
                    } catch (e: Exception) {
                        target.delete()
                        throw e
                    }
                    MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), null, null)
                    kind.base29 + "/" + folder
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap, displayName: String): String? {
        val tmp = File(ctx.cacheDir, "shot_" + System.currentTimeMillis() + ".png")
        return try {
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            saveFile(ctx, tmp, displayName, "image/png", Kind.IMAGE, "IAManager")
        } catch (e: Exception) {
            null
        } finally {
            tmp.delete()
        }
    }
}
