/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.Build
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

// ---------------- Reading Office documents (simple text extraction) ----------------

fun xmlUnescape(s: String): String = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
    .replace("&apos;", "'").replace("&amp;", "&")

fun xmlEscape(s: String): String {
    val sb = StringBuilder()
    for (c in s) {
        when {
            c == '&' -> sb.append("&amp;")
            c == '<' -> sb.append("&lt;")
            c == '>' -> sb.append("&gt;")
            c == '\t' || c == '\n' || c >= ' ' -> sb.append(c)
        }
    }
    return sb.toString()
}

private fun zipText(f: File, name: String): String? = ZipFile(f).use { z ->
    z.getEntry(name)?.let { e -> z.getInputStream(e).bufferedReader(Charsets.UTF_8).readText() }
}

private val RX_DOCX_P = Regex("<w:p[ >].*?</w:p>", RegexOption.DOT_MATCHES_ALL)
private val RX_DOCX_T = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>", RegexOption.DOT_MATCHES_ALL)

fun docxText(f: File): String {
    val xml = zipText(f, "word/document.xml") ?: throw IOException("Not a valid .docx file")
    val sb = StringBuilder()
    for (p in RX_DOCX_P.findAll(xml)) {
        for (m in RX_DOCX_T.findAll(p.value)) {
            when {
                m.value == "<w:tab/>" -> sb.append('\t')
                m.value == "<w:br/>" -> sb.append('\n')
                else -> sb.append(xmlUnescape(m.groupValues[1]))
            }
        }
        sb.append('\n')
    }
    return sb.toString().trimEnd()
}

private val RX_A_P = Regex("<a:p>.*?</a:p>|<a:p [^>]*>.*?</a:p>", RegexOption.DOT_MATCHES_ALL)
private val RX_A_T = Regex("<a:t(?: [^>]*)?>(.*?)</a:t>", RegexOption.DOT_MATCHES_ALL)

fun pptxText(f: File): String {
    val sb = StringBuilder()
    ZipFile(f).use { z ->
        val slides = z.entries().toList()
            .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it.name) }
            .sortedBy { it.name.filter { c -> c.isDigit() }.toInt() }
        if (slides.isEmpty()) throw IOException("Not a valid .pptx file")
        slides.forEachIndexed { i, e ->
            sb.append("\u2014 Slide ${i + 1} \u2014\n")
            val xml = z.getInputStream(e).bufferedReader(Charsets.UTF_8).readText()
            for (p in RX_A_P.findAll(xml)) {
                val line = RX_A_T.findAll(p.value).joinToString("") { xmlUnescape(it.groupValues[1]) }
                if (line.isNotBlank()) sb.append(line).append('\n')
            }
            sb.append('\n')
        }
    }
    return sb.toString().trimEnd()
}

private val RX_SI = Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL)
private val RX_T = Regex("<t(?: [^>]*)?>(.*?)</t>", RegexOption.DOT_MATCHES_ALL)
private val RX_ROW = Regex("<row[ >].*?</row>", RegexOption.DOT_MATCHES_ALL)
private val RX_CELL = Regex("<c\\s([^>]*?)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL)
private val RX_REF = Regex("r=\"([A-Z]+)\\d+\"")
private val RX_TYPE = Regex("t=\"(\\w+)\"")
private val RX_V = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL)

private fun colIndex(letters: String): Int {
    var n = 0
    for (c in letters) n = n * 26 + (c - 'A' + 1)
    return n - 1
}

fun xlsxRows(f: File): List<List<String>> {
    return ZipFile(f).use { z ->
        val shared = ArrayList<String>()
        z.getEntry("xl/sharedStrings.xml")?.let { e ->
            val xml = z.getInputStream(e).bufferedReader(Charsets.UTF_8).readText()
            for (si in RX_SI.findAll(xml)) {
                shared.add(RX_T.findAll(si.groupValues[1]).joinToString("") { xmlUnescape(it.groupValues[1]) })
            }
        }
        val sheet = z.entries().toList().filter { it.name.startsWith("xl/worksheets/sheet") && it.name.endsWith(".xml") }
            .minByOrNull { it.name } ?: throw IOException("No worksheet found")
        val xml = z.getInputStream(sheet).bufferedReader(Charsets.UTF_8).readText()
        val rows = ArrayList<List<String>>()
        for (row in RX_ROW.findAll(xml)) {
            val cells = ArrayList<String>()
            for (c in RX_CELL.findAll(row.value)) {
                val attrs = c.groupValues[1]
                val body = c.groupValues[2]
                val col = RX_REF.find(attrs)?.groupValues?.get(1)?.let { colIndex(it) } ?: cells.size
                while (cells.size < col) cells.add("")
                val type = RX_TYPE.find(attrs)?.groupValues?.get(1)
                val v = RX_V.find(body)?.groupValues?.get(1)
                val text = when (type) {
                    "s" -> v?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                    "inlineStr" -> RX_T.findAll(body).joinToString("") { xmlUnescape(it.groupValues[1]) }
                    else -> xmlUnescape(v ?: "")
                }
                if (cells.size == col) cells.add(text) else cells[col] = text
                if (cells.size > 60) break
            }
            rows.add(cells)
            if (rows.size >= 1000) break
        }
        rows
    }
}

// ---------------- Writing ----------------

fun writeDocx(out: File, text: String) {
    val body = text.replace("\r", "").split("\n").joinToString("") {
        "<w:p><w:r><w:t xml:space=\"preserve\">${xmlEscape(it)}</w:t></w:r></w:p>"
    }
    writeZipText(
        out, listOf(
            "[Content_Types].xml" to "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>",
            "_rels/.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/officeDocument\" Target=\"word/document.xml\"/></Relationships>",
            "word/document.xml" to "$XML<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body</w:body></w:document>"
        )
    )
}

fun textToPdf(text: String, out: File) {
    val pw = 595
    val ph = 842
    val m = 40f
    val paint = Paint().apply {
        textSize = 12f
        isAntiAlias = true
        color = Color.BLACK
    }
    val maxW = pw - 2 * m
    val lines = ArrayList<String>()
    for (para in text.replace("\r", "").split("\n")) {
        if (para.isEmpty()) {
            lines.add("")
            continue
        }
        var rest = para.replace("\t", "    ")
        while (rest.isNotEmpty()) {
            val n = paint.breakText(rest, true, maxW, null).coerceAtLeast(1)
            var cut = n
            if (n < rest.length) {
                val sp = rest.lastIndexOf(' ', n - 1)
                if (sp > 0) cut = sp + 1
            }
            lines.add(rest.substring(0, cut).trimEnd())
            rest = rest.substring(cut)
        }
    }
    val doc = PdfDocument()
    try {
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var y = 0f
        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
            y = m + 12f
        }
        newPage()
        for (l in lines) {
            if (y > ph - m) newPage()
            page!!.canvas.drawText(l, m, y, paint)
            y += 16f
        }
        page?.let { doc.finishPage(it) }
        FileOutputStream(out).use { doc.writeTo(it) }
    } finally {
        doc.close()
    }
}

fun imagesToPdf(files: List<File>, out: File) {
    val doc = PdfDocument()
    try {
        var n = 0
        for (f in files) {
            val bmp = decodeScaled(f, 2000) ?: continue
            val scale = if (bmp.width > 1240) 1240f / bmp.width else 1f
            val w = (bmp.width * scale).toInt().coerceAtLeast(1)
            val h = (bmp.height * scale).toInt().coerceAtLeast(1)
            n++
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
            val c: Canvas = page.canvas
            c.drawColor(Color.WHITE)
            val scaled = if (scale < 1f) Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
            c.drawBitmap(scaled, 0f, 0f, null)
            doc.finishPage(page)
        }
        if (n == 0) throw IOException("No images could be read")
        FileOutputStream(out).use { doc.writeTo(it) }
    } finally {
        doc.close()
    }
}

fun pdfToImages(pdf: File, outDir: File) {
    outDir.mkdirs()
    val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
    val r = PdfRenderer(pfd)
    try {
        for (i in 0 until r.pageCount) {
            val p = r.openPage(i)
            try {
                val b = Bitmap.createBitmap(p.width * 2, p.height * 2, Bitmap.Config.ARGB_8888)
                b.eraseColor(Color.WHITE)
                p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                FileOutputStream(File(outDir, String.format(Locale.US, "page_%03d.jpg", i + 1))).use {
                    b.compress(Bitmap.CompressFormat.JPEG, 92, it)
                }
                b.recycle()
            } finally {
                p.close()
            }
        }
    } finally {
        r.close()
        pfd.close()
    }
}

fun pdfText(ctx: Context, pdf: File): String {
    PDFBoxResourceLoader.init(ctx.applicationContext)
    val d = PDDocument.load(pdf)
    try {
        return PDFTextStripper().getText(d)
    } finally {
        d.close()
    }
}

private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

fun doConvert(ctx: Context, kind: Conv, files: List<File>, dir: File, option: String): String {
    val first = files.first()
    return when (kind) {
        Conv.IMG_TO_PDF -> {
            val out = uniqueFile(dir, (if (files.size == 1) first.nameWithoutExtension else "Images_" + stamp()) + ".pdf")
            imagesToPdf(files, out)
            "Created ${out.name}"
        }
        Conv.PDF_TO_IMG -> {
            val out = uniqueFile(dir, first.nameWithoutExtension + "_images")
            pdfToImages(first, out)
            "Saved pages in folder ${out.name}"
        }
        Conv.PDF_TO_DOCX -> {
            val text = pdfText(ctx, first)
            if (text.isBlank()) throw IOException("No selectable text found in this PDF (it may be a scanned document)")
            val out = uniqueFile(dir, first.nameWithoutExtension + ".docx")
            writeDocx(out, text)
            "Created ${out.name}"
        }
        Conv.DOC_TO_PDF -> {
            val text = when (first.ext) {
                "docx" -> docxText(first)
                "pptx" -> pptxText(first)
                else -> first.readText()
            }
            val out = uniqueFile(dir, first.nameWithoutExtension + ".pdf")
            textToPdf(text, out)
            "Created ${out.name}"
        }
        Conv.XLSX_TO_CSV -> {
            val rows = xlsxRows(first)
            val csv = rows.joinToString("\n") { r ->
                r.joinToString(",") { c ->
                    if (c.contains(',') || c.contains('"') || c.contains('\n')) "\"" + c.replace("\"", "\"\"") + "\"" else c
                }
            }
            val out = uniqueFile(dir, first.nameWithoutExtension + ".csv")
            out.writeText(csv)
            "Created ${out.name}"
        }
        Conv.IMG_FORMAT -> {
            val fmt = option.ifEmpty { "png" }
            for (f in files) {
                val bmp = decodeScaled(f, 4096) ?: continue
                val out = uniqueFile(dir, f.nameWithoutExtension + "." + fmt)
                var src = bmp
                if (fmt == "jpg") {
                    src = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                    val c = Canvas(src)
                    c.drawColor(Color.WHITE)
                    c.drawBitmap(bmp, 0f, 0f, null)
                }
                val cf = when (fmt) {
                    "jpg" -> Bitmap.CompressFormat.JPEG
                    "webp" -> if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP
                    else -> Bitmap.CompressFormat.PNG
                }
                FileOutputStream(out).use { src.compress(cf, 95, it) }
            }
            "Converted ${files.size} image(s) to ${fmt.uppercase()}"
        }
    }
}
