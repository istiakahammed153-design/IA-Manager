package com.iamanager.app.player

import android.app.Activity
import android.app.AlertDialog
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.view.Gravity
import android.webkit.MimeTypeMap
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * File operations shared by the video list and the player: rename, delete, share, details,
 * hide into the private vault and restore from it. Android 10+ asks the user to confirm changes to
 * files owned by other apps, so those calls finish in [onActivityResult].
 */
class MediaActions(private val act: Activity) {

    interface Listener {
        fun onPlay(item: VideoItem) {}
        fun onDeleted(item: VideoItem) {}
        fun onRenamed(old: VideoItem, updated: VideoItem) {}
        fun onHiddenChanged(item: VideoItem) {}
        fun onFavoriteChanged(item: VideoItem) {}
        fun onVaultChanged() {}
    }

    companion object {
        const val REQ_DELETE = 9101
        const val REQ_WRITE = 9102
    }

    private val ui = Handler(Looper.getMainLooper())

    private var pendingDelete: VideoItem? = null
    private var deleteDone: ((Boolean) -> Unit)? = null
    private var pendingRenameItem: VideoItem? = null
    private var pendingRenameName: String = ""
    private var renameDone: ((VideoItem?) -> Unit)? = null

    private fun toast(s: String) {
        Toast.makeText(act, s, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ long-press menu

    fun showMenu(item: VideoItem, showPlay: Boolean, listener: Listener) {
        val labels = ArrayList<String>()
        val runs = ArrayList<() -> Unit>()
        fun add(label: String, run: () -> Unit) {
            labels.add(label)
            runs.add(run)
        }

        if (showPlay) add("Play") { listener.onPlay(item) }
        add("Rename") { promptRename(item, listener) }
        add("Delete") { confirmDelete(item, listener) }
        add("Share") { share(item) }
        val id = item.prefKey
        val fav = Prefs.isFavorite(act, id)
        add(if (fav) "Remove from favorites" else "Add to favorites") {
            Prefs.toggleFavorite(act, id)
            listener.onFavoriteChanged(item)
        }
        add("Details") { showDetails(item) }

        AlertDialog.Builder(act)
            .setTitle(item.name)
            .setItems(labels.toTypedArray()) { _, which -> runs[which]() }
            .show()
    }

    // ------------------------------------------------------------------ delete

    private fun confirmDelete(item: VideoItem, listener: Listener) {
        AlertDialog.Builder(act)
            .setTitle("Delete this file?")
            .setMessage(item.name + "\n\nThis cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                delete(item) { ok ->
                    if (ok) {
                        Prefs.forget(act, item.prefKey)
                        listener.onDeleted(item)
                        toast("Deleted")
                    } else {
                        toast("Could not delete this file")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun delete(item: VideoItem, done: (Boolean) -> Unit) {
        if (item.uri.scheme == "file") {
            val ok = try { File(item.uri.path ?: "").delete() } catch (e: Exception) { false }
            if (ok) try { MediaScannerConnection.scanFile(act, arrayOf(item.uri.path), null, null) } catch (e: Exception) { }
            done(ok)
            return
        }
        val uri = item.uri
        if (uri.authority != MediaStore.AUTHORITY) {
            val ok = try {
                DocumentsContract.deleteDocument(act.contentResolver, uri)
            } catch (e: Exception) {
                false
            }
            done(ok)
            return
        }
        deleteDone = done
        pendingDelete = item
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(act.contentResolver, listOf(uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } else {
                val rows = act.contentResolver.delete(uri, null, null)
                finishDelete(rows > 0)
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_DELETE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishDelete(false)
                }
            } else {
                finishDelete(false)
            }
        } catch (e: Exception) {
            finishDelete(false)
        }
    }

    private fun finishDelete(ok: Boolean) {
        val cb = deleteDone
        deleteDone = null
        pendingDelete = null
        cb?.invoke(ok)
    }

    // ------------------------------------------------------------------ rename

    private fun sanitize(s: String): String {
        val cleaned = s.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        return cleaned
    }

    private fun promptRename(item: VideoItem, listener: Listener) {
        val dot = item.name.lastIndexOf('.')
        val ext = if (dot > 0) item.name.substring(dot) else ""
        val base = if (dot > 0) item.name.substring(0, dot) else item.name

        val input = EditText(act)
        input.setText(base)
        input.setSingleLine()
        input.setSelectAllOnFocus(true)
        val box = LinearLayout(act)
        box.setPadding(act.dp(22), act.dp(8), act.dp(22), act.dp(4))
        box.addView(
            input,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        AlertDialog.Builder(act)
            .setTitle("Rename")
            .setView(box)
            .setPositiveButton("Rename") { _, _ ->
                val nn = sanitize(input.text.toString())
                if (nn.isEmpty()) {
                    toast("Name cannot be empty")
                } else {
                    rename(item, nn + ext) { updated ->
                        if (updated != null) {
                            listener.onRenamed(item, updated)
                            toast("Renamed")
                        } else {
                            toast("Could not rename this file")
                        }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun rename(item: VideoItem, newName: String, done: (VideoItem?) -> Unit) {
        if (item.uri.scheme == "file") {
            val src = File(item.uri.path ?: "")
            val dst = File(src.parentFile, newName)
            val ok = try { !dst.exists() && src.renameTo(dst) } catch (e: Exception) { false }
            if (ok) {
                try { MediaScannerConnection.scanFile(act, arrayOf(src.path, dst.path), null, null) } catch (e: Exception) { }
                done(item.copy(uri = Uri.fromFile(dst), path = dst.path, name = newName))
            } else done(null)
            return
        }
        if (item.uri.authority != MediaStore.AUTHORITY) {
            val nu = try {
                DocumentsContract.renameDocument(act.contentResolver, item.uri, newName)
            } catch (e: Exception) {
                null
            }
            done(if (nu != null) item.copy(uri = nu, name = newName) else null)
            return
        }
        renameDone = done
        pendingRenameItem = item
        pendingRenameName = newName
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createWriteRequest(act.contentResolver, listOf(item.uri))
                act.startIntentSenderForResult(pi.intentSender, REQ_WRITE, null, 0, 0, 0)
            } else {
                finishRename(doRename())
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                } catch (x: Exception) {
                    finishRename(false)
                }
            } else {
                finishRename(false)
            }
        } catch (e: Exception) {
            finishRename(false)
        }
    }

    private fun doRename(): Boolean {
        val item = pendingRenameItem ?: return false
        return try {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, pendingRenameName)
            act.contentResolver.update(item.uri, v, null, null) > 0
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                try {
                    act.startIntentSenderForResult(
                        e.userAction.actionIntent.intentSender, REQ_WRITE, null, 0, 0, 0
                    )
                    // finishRename() will be called from onActivityResult
                    pendingRetryRename = true
                } catch (x: Exception) {
                    // give up
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }

    private var pendingRetryRename = false

    private fun finishRename(ok: Boolean) {
        if (pendingRetryRename && !ok) {
            // a permission prompt is on screen; the result arrives in onActivityResult
            return
        }
        val item = pendingRenameItem
        val cb = renameDone
        val name = pendingRenameName
        pendingRenameItem = null
        renameDone = null
        pendingRetryRename = false
        if (item == null || cb == null) return
        cb(if (ok) item.copy(name = name) else null)
    }

    // ------------------------------------------------------------------ activity results

    /** Forward Activity.onActivityResult here. Returns true if the result belonged to us. */
    fun onActivityResult(requestCode: Int, resultCode: Int): Boolean {
        if (requestCode == REQ_DELETE) {
            if (resultCode == Activity.RESULT_OK && Build.VERSION.SDK_INT == 29) {
                val ok = try {
                    val u = pendingDelete?.uri
                    u != null && act.contentResolver.delete(u, null, null) > 0
                } catch (e: Exception) {
                    false
                }
                finishDelete(ok)
            } else {
                finishDelete(resultCode == Activity.RESULT_OK)
            }
            return true
        }
        if (requestCode == REQ_WRITE) {
            // the user answered the permission prompt; stop waiting and try (or give up)
            pendingRetryRename = false
            if (resultCode == Activity.RESULT_OK) {
                finishRename(doRename())
            } else {
                finishRename(false)
            }
            return true
        }
        return false
    }

    // ------------------------------------------------------------------ share and details

    fun share(item: VideoItem) {
        val shareUri = if (item.uri.scheme == "file") {
            try {
                androidx.core.content.FileProvider.getUriForFile(
                    act, act.packageName + ".provider", File(item.uri.path ?: "")
                )
            } catch (e: Exception) {
                toast("Cannot share this file")
                return
            }
        } else item.uri
        val send = Intent(Intent.ACTION_SEND)
        send.type = if (item.isAudio) "audio/*" else "video/*"
        send.putExtra(Intent.EXTRA_STREAM, shareUri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        act.startActivity(Intent.createChooser(send, "Share"))
    }

    fun showDetails(item: VideoItem) {
        val sb = StringBuilder()
        sb.append("Name: ").append(item.name).append('\n')
        if (!item.path.isNullOrEmpty()) {
            sb.append("Path: ").append(item.path).append('\n')
            sb.append("Storage: ").append(if (item.isSdCard) "SD card" else "Internal").append('\n')
        }
        if (item.sizeBytes > 0) sb.append("Size: ").append(formatSize(item.sizeBytes)).append('\n')
        if (item.durationMs > 0) sb.append("Duration: ").append(formatTime(item.durationMs)).append('\n')
        if (item.width > 0 && item.height > 0) {
            sb.append("Resolution: ").append(item.width).append(" x ").append(item.height).append('\n')
        }
        if (item.dateAdded > 0) {
            sb.append("Added: ")
                .append(DateFormat.getDateTimeInstance().format(Date(item.dateAdded * 1000)))
                .append('\n')
        }
        AlertDialog.Builder(act)
            .setTitle("Details")
            .setMessage(sb.toString().trim())
            .setPositiveButton("OK", null)
            .show()
    }
}
