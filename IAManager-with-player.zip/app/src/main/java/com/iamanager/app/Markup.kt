/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CropSquare
import androidx.compose.material.icons.outlined.Gesture
import androidx.compose.material.icons.outlined.Highlight
import androidx.compose.material.icons.outlined.NorthEast
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Redo
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material.icons.outlined.TextFields
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp

object ShapeType {
    const val PEN = 0
    const val LINE = 1
    const val RECT = 2
    const val OVAL = 3
    const val ARROW = 4
    const val TEXT = 5
    const val HILITE = 6
}

/** A markup shape. All coordinates are normalized (0..1) relative to the image; width is a fraction of min(width, height). */
data class Shape(
    val type: Int,
    val color: Int,
    val width: Float,
    val pts: List<Offset>,
    val text: String = ""
)

/** Rotates all points of a shape by 90 degrees clockwise (used when a PDF page is rotated). */
fun Shape.rotated90(): Shape = copy(pts = pts.map { Offset(1f - it.y, it.x) })

fun drawShapes(c: android.graphics.Canvas, w: Float, h: Float, shapes: List<Shape>) {
    val base = minOf(w, h)
    for (s in shapes) {
        val pts = s.pts
        if (pts.isEmpty()) continue
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = s.color
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = (s.width * base).coerceAtLeast(1f)
        if (s.type == ShapeType.HILITE) {
            p.alpha = 90
            p.strokeWidth = (s.width * base * 3f).coerceAtLeast(6f)
            p.strokeCap = Paint.Cap.SQUARE
        }
        when (s.type) {
            ShapeType.PEN, ShapeType.HILITE -> {
                if (pts.size == 1) {
                    p.style = Paint.Style.FILL
                    c.drawCircle(pts[0].x * w, pts[0].y * h, p.strokeWidth / 2f, p)
                } else {
                    val path = android.graphics.Path()
                    path.moveTo(pts[0].x * w, pts[0].y * h)
                    for (i in 1 until pts.size) path.lineTo(pts[i].x * w, pts[i].y * h)
                    c.drawPath(path, p)
                }
            }
            ShapeType.LINE -> if (pts.size >= 2) c.drawLine(pts[0].x * w, pts[0].y * h, pts[1].x * w, pts[1].y * h, p)
            ShapeType.RECT -> if (pts.size >= 2) {
                c.drawRect(
                    minOf(pts[0].x, pts[1].x) * w, minOf(pts[0].y, pts[1].y) * h,
                    maxOf(pts[0].x, pts[1].x) * w, maxOf(pts[0].y, pts[1].y) * h, p
                )
            }
            ShapeType.OVAL -> if (pts.size >= 2) {
                c.drawOval(
                    RectF(
                        minOf(pts[0].x, pts[1].x) * w, minOf(pts[0].y, pts[1].y) * h,
                        maxOf(pts[0].x, pts[1].x) * w, maxOf(pts[0].y, pts[1].y) * h
                    ), p
                )
            }
            ShapeType.ARROW -> if (pts.size >= 2) {
                val x1 = pts[0].x * w
                val y1 = pts[0].y * h
                val x2 = pts[1].x * w
                val y2 = pts[1].y * h
                c.drawLine(x1, y1, x2, y2, p)
                val ang = Math.atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())
                val head = maxOf(p.strokeWidth * 4f, base * 0.03f)
                for (d in doubleArrayOf(0.5, -0.5)) {
                    val a = ang + Math.PI - d
                    c.drawLine(x2, y2, x2 + (head * Math.cos(a)).toFloat(), y2 + (head * Math.sin(a)).toFloat(), p)
                }
            }
            ShapeType.TEXT -> {
                p.style = Paint.Style.FILL
                p.textSize = (s.width * base * 4f).coerceAtLeast(12f)
                var y = pts[0].y * h + p.textSize
                for (line in s.text.split("\n")) {
                    c.drawText(line, pts[0].x * w, y, p)
                    y += p.textSize * 1.2f
                }
            }
        }
    }
}

private val PALETTE = listOf(
    Color.White, Color(0xFF3A3A3A), Color(0xFFFF3B14), Color(0xFFFF6B5E), Color(0xFFFF8A30),
    Color(0xFFFFD233), Color(0xFF4CD964), Color(0xFF2196F3), Color(0xFF8E44AD), Color.Black
)
private val WIDTHS = listOf(0.004f, 0.008f, 0.016f, 0.03f)

@Composable
private fun ToolBox(icon: ImageVector, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(width = 58.dp, height = 52.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF262626))
            .border(if (selected) 2.dp else 0.dp, Color(0xFFFFC107), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color(0xFFDDDDDD)) }
}

/**
 * Full-screen markup editor (pen, line, rectangle, circle, arrow, text, highlighter).
 * Calls [onDone] with the newly drawn shapes (normalized) or [onCancel].
 */
@Composable
fun MarkupEditor(base: Bitmap, onCancel: () -> Unit, onDone: (List<Shape>) -> Unit) {
    val shapes = remember { mutableStateListOf<Shape>() }
    val redo = remember { mutableStateListOf<Shape>() }
    var live by remember { mutableStateOf<Shape?>(null) }
    var tool by remember { mutableIntStateOf(ShapeType.PEN) }
    var color by remember { mutableIntStateOf(PALETTE[2].toArgb()) }
    var widthIdx by remember { mutableIntStateOf(1) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var pendingText by remember { mutableStateOf<Offset?>(null) }
    var textValue by remember { mutableStateOf("") }

    val iw = base.width.toFloat()
    val ih = base.height.toFloat()
    val sc = if (box.width > 0 && box.height > 0) minOf(box.width / iw, box.height / ih) else 1f
    val rw = iw * sc
    val rh = ih * sc
    val rl = (box.width - rw) / 2f
    val rt = (box.height - rh) / 2f
    fun norm(p: Offset) = Offset(((p.x - rl) / rw).coerceIn(0f, 1f), ((p.y - rt) / rh).coerceIn(0f, 1f))

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (shapes.isNotEmpty()) redo.add(shapes.removeAt(shapes.lastIndex))
            }, enabled = shapes.isNotEmpty()) {
                Icon(Icons.Outlined.Undo, "Undo", tint = if (shapes.isNotEmpty()) Color.White else Color(0xFF666666))
            }
            IconButton(onClick = {
                if (redo.isNotEmpty()) shapes.add(redo.removeAt(redo.lastIndex))
            }, enabled = redo.isNotEmpty()) {
                Icon(Icons.Outlined.Redo, "Redo", tint = if (redo.isNotEmpty()) Color.White else Color(0xFF666666))
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().onSizeChanged { box = it }) {
            Image(
                bitmap = base.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize()
            )
            Canvas(
                Modifier.fillMaxSize().pointerInput(tool, color, widthIdx, box) {
                    if (tool == ShapeType.TEXT) {
                        detectTapGestures { pos ->
                            pendingText = norm(pos)
                            textValue = ""
                        }
                    } else {
                        detectDragGestures(
                            onDragStart = { pos -> live = Shape(tool, color, WIDTHS[widthIdx], listOf(norm(pos))) },
                            onDrag = { change, _ ->
                                val l = live
                                if (l != null) {
                                    val n = norm(change.position)
                                    live = if (tool == ShapeType.PEN || tool == ShapeType.HILITE) l.copy(pts = l.pts + n)
                                    else l.copy(pts = listOf(l.pts[0], n))
                                }
                                change.consume()
                            },
                            onDragEnd = {
                                val l = live
                                if (l != null && (l.pts.size >= 2 || l.type == ShapeType.PEN)) {
                                    shapes.add(l)
                                    redo.clear()
                                }
                                live = null
                            },
                            onDragCancel = { live = null }
                        )
                    }
                }
            ) {
                drawIntoCanvas { cv ->
                    val nc = cv.nativeCanvas
                    nc.save()
                    nc.translate(rl, rt)
                    val all = live?.let { shapes.toList() + it } ?: shapes.toList()
                    drawShapes(nc, rw, rh, all)
                    nc.restore()
                }
            }
        }
        // size dot + colors
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                Modifier.size(48.dp).background(Color(0xFF2A2A2A), CircleShape).clickable { widthIdx = (widthIdx + 1) % WIDTHS.size },
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size((6 + widthIdx * 5).dp).background(Color(color), CircleShape))
            }
            PALETTE.forEach { c ->
                val on = c.toArgb() == color
                Box(
                    Modifier.size(44.dp)
                        .border(if (on) 3.dp else 0.dp, if (on) Color(0xFFFF3B14) else Color.Transparent, CircleShape)
                        .padding(if (on) 4.dp else 0.dp)
                        .background(c, CircleShape)
                        .clickable { color = c.toArgb() }
                )
            }
        }
        // tools
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ToolBox(Icons.Outlined.Gesture, tool == ShapeType.PEN) { tool = ShapeType.PEN }
            ToolBox(Icons.Outlined.Remove, tool == ShapeType.LINE) { tool = ShapeType.LINE }
            ToolBox(Icons.Outlined.CropSquare, tool == ShapeType.RECT) { tool = ShapeType.RECT }
            ToolBox(Icons.Outlined.RadioButtonUnchecked, tool == ShapeType.OVAL) { tool = ShapeType.OVAL }
            ToolBox(Icons.Outlined.NorthEast, tool == ShapeType.ARROW) { tool = ShapeType.ARROW }
            ToolBox(Icons.Outlined.TextFields, tool == ShapeType.TEXT) { tool = ShapeType.TEXT }
            ToolBox(Icons.Outlined.Highlight, tool == ShapeType.HILITE) { tool = ShapeType.HILITE }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = onCancel) { Icon(Icons.Outlined.Close, "Cancel", tint = Color.White) }
            IconButton(onClick = { onDone(shapes.toList()) }) { Icon(Icons.Outlined.Check, "Done", tint = Color.White) }
        }
    }
    val pt = pendingText
    if (pt != null) {
        AlertDialog(
            onDismissRequest = { pendingText = null },
            title = { Text("Add text") },
            text = { OutlinedTextField(value = textValue, onValueChange = { textValue = it }) },
            confirmButton = {
                TextButton(onClick = {
                    if (textValue.isNotBlank()) {
                        shapes.add(Shape(ShapeType.TEXT, color, WIDTHS[widthIdx], listOf(pt), textValue))
                        redo.clear()
                    }
                    pendingText = null
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { pendingText = null }) { Text("Cancel") } }
        )
    }
}
