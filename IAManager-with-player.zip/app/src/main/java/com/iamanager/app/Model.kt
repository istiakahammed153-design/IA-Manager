/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

enum class Cat(val title: String, val exts: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")),
    VIDEOS("Videos", setOf("mp4", "mkv", "webm", "avi", "mov", "3gp", "flv", "wmv", "m4v")),
    AUDIO("Audio", setOf("mp3", "wav", "aac", "m4a", "ogg", "flac", "opus", "amr", "wma")),
    DOCS("Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "md", "json", "xml", "html", "epub")),
    ARCHIVES("Archives", setOf("zip", "rar", "7z", "tar", "gz"))
}

enum class Conv(val title: String, val sub: String, val exts: Set<String>, val multi: Boolean) {
    IMG_TO_PDF("Images \u2192 PDF", "Combine photos into one PDF (pages in the order you tap)", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif"), true),
    PDF_TO_IMG("PDF \u2192 Images", "Save every page of a PDF as a JPG image", setOf("pdf"), false),
    PDF_TO_DOCX("PDF \u2192 Word", "Extract the text of a PDF into a .docx file", setOf("pdf"), false),
    DOC_TO_PDF("Word / PowerPoint / Text \u2192 PDF", "Make a PDF from the text of .docx, .pptx or .txt", setOf("docx", "pptx", "txt", "md"), false),
    XLSX_TO_CSV("Excel \u2192 CSV", "Export the first sheet of a spreadsheet as CSV", setOf("xlsx"), false),
    IMG_FORMAT("Convert image format", "Change images to PNG, JPG or WEBP", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif"), true)
}

data class StorageVol(val name: String, val root: File)

fun detectStorages(ctx: Context): List<StorageVol> {
    val internal = Environment.getExternalStorageDirectory()
    val list = arrayListOf(StorageVol("Internal Storage", internal))
    val seen = hashSetOf(internal.path)
    fun add(dir: File, name: String) {
        if (dir.path in seen || !dir.exists() || dir.listFiles() == null) return
        seen.add(dir.path)
        list.add(StorageVol(name, dir))
    }
    try {
        if (Build.VERSION.SDK_INT >= 30) {
            val sm = ctx.getSystemService(Context.STORAGE_SERVICE) as StorageManager
            for (v in sm.storageVolumes) {
                val dir = v.directory ?: continue
                if (v.isPrimary || v.state != Environment.MEDIA_MOUNTED) continue
                add(dir, v.getDescription(ctx) ?: "External Storage")
            }
        }
    } catch (e: Exception) {
    }
    try {
        for (d in ctx.getExternalFilesDirs(null)) {
            if (d == null) continue
            val i = d.path.indexOf("/Android/data")
            if (i > 0) add(File(d.path.substring(0, i)), "SD Card / USB")
        }
    } catch (e: Exception) {
    }
    return list
}

sealed interface Screen {
    data object Home : Screen
    data class Files(val path: String) : Screen
    data class Category(val cat: Cat, val pickEdit: Boolean = false) : Screen
    data object Search : Screen
    data class Details(val path: String) : Screen
    data class Editor(val path: String) : Screen
    data class Create(val dir: String) : Screen
    data object Settings : Screen
    data object Shared : Screen
    data object Recent : Screen
    data object Starred : Screen
    data object Trash : Screen
    data class Viewer(val path: String) : Screen
    data class Pick(val conv: Conv, val dir: String) : Screen
    data class PdfEdit(val path: String) : Screen
    data class OfficeEdit(val path: String) : Screen
    data object Ftp : Screen
    data object Vault : Screen
}

val File.ext: String get() = extension.lowercase(Locale.ROOT)

fun File.cat(): Cat? {
    val e = ext
    return Cat.values().firstOrNull { e in it.exts }
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    while (v >= 1024 && i < u.size - 1) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, u[i])
}

fun fmtDate(ms: Long): String = SimpleDateFormat("MMM d, yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))
fun fmtDay(ms: Long): String = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ms))

fun createdTime(f: File): Long = try {
    if (Build.VERSION.SDK_INT >= 26) {
        java.nio.file.Files.readAttributes(f.toPath(), java.nio.file.attribute.BasicFileAttributes::class.java)
            .creationTime().toMillis()
    } else f.lastModified()
} catch (e: Exception) {
    f.lastModified()
}

fun relPath(root: File, rootName: String, f: File): String {
    val parts = f.path.removePrefix(root.path).split("/").filter { it.isNotEmpty() }
    return (listOf(rootName) + parts).joinToString(" \u203A ")
}

fun storageStats(root: File): Pair<Long, Long> {
    return try {
        val s = StatFs(root.path)
        val total = s.totalBytes
        Pair(total - s.availableBytes, total)
    } catch (e: Exception) {
        Pair(0L, 0L)
    }
}

fun imageSize(f: File): String? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    return if (o.outWidth > 0) "${o.outWidth} \u00D7 ${o.outHeight}" else null
}

fun uniqueFile(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = name.substringBeforeLast('.', name)
    val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
    var i = 1
    do {
        f = File(dir, "$base ($i)$ext")
        i++
    } while (f.exists())
    return f
}

/** Cache of per-file info, filled on a background thread so list rows never touch the disk while scrolling. */
object MetaCache {
    private val map = java.util.concurrent.ConcurrentHashMap<String, FMeta>()
    fun get(path: String): FMeta? = map[path]
    fun put(path: String, m: FMeta) {
        if (map.size > 30000) map.clear()
        map[path] = m
    }
}

fun metaOf(f: File): FMeta {
    val d = f.isDirectory
    val m = FMeta(d, if (d) 0L else f.length(), f.lastModified(), if (d) (f.list()?.size ?: 0) else 0)
    MetaCache.put(f.path, m)
    return m
}

fun sortFiles(list: List<File>, sortBy: Int): List<File> = sortMetas(list.map { it to metaOf(it) }, sortBy)

private fun sortMetas(list: List<Pair<File, FMeta>>, sortBy: Int): List<File> {
    val cmp: Comparator<Pair<File, FMeta>> = when (sortBy) {
        1 -> compareByDescending<Pair<File, FMeta>> { it.second.mtime }
        2 -> compareByDescending<Pair<File, FMeta>> { it.second.size }
        else -> compareBy<Pair<File, FMeta>> { it.first.name.lowercase() }
    }
    return list.sortedWith(compareBy<Pair<File, FMeta>> { !it.second.isDir }.then(cmp)).map { it.first }
}

fun listDir(dir: File, showHidden: Boolean, sortBy: Int): List<File> {
    val kids = (dir.listFiles() ?: emptyArray()).filter { showHidden || !it.name.startsWith(".") }
    return sortFiles(kids, sortBy)
}

class ScanResult(
    val files: List<File>,
    val dirs: List<File>,
    val sizes: Map<Cat, Long>,
    val mtimes: Map<String, Long> = emptyMap()
)

fun scanRoot(root: File, hidden: Boolean): ScanResult {
    val files = ArrayList<File>()
    val dirs = ArrayList<File>()
    val sizes = HashMap<Cat, Long>()
    val mtimes = HashMap<String, Long>()
    if (Build.VERSION.SDK_INT >= 26) {
        val rootPath = root.toPath()
        try {
            java.nio.file.Files.walkFileTree(rootPath, object : java.nio.file.SimpleFileVisitor<java.nio.file.Path>() {
                override fun preVisitDirectory(
                    dir: java.nio.file.Path,
                    attrs: java.nio.file.attribute.BasicFileAttributes
                ): java.nio.file.FileVisitResult {
                    if (dir != rootPath) {
                        val name = dir.fileName?.toString() ?: ""
                        if ((!hidden && name.startsWith(".")) || (dir.parent == rootPath && name == "Android")) {
                            return java.nio.file.FileVisitResult.SKIP_SUBTREE
                        }
                        dirs.add(dir.toFile())
                    }
                    return java.nio.file.FileVisitResult.CONTINUE
                }

                override fun visitFile(
                    file: java.nio.file.Path,
                    attrs: java.nio.file.attribute.BasicFileAttributes
                ): java.nio.file.FileVisitResult {
                    val name = file.fileName?.toString() ?: ""
                    if (hidden || !name.startsWith(".")) {
                        val f = file.toFile()
                        files.add(f)
                        mtimes[f.path] = attrs.lastModifiedTime().toMillis()
                        val c = f.cat()
                        if (c != null) sizes[c] = (sizes[c] ?: 0L) + attrs.size()
                    }
                    return java.nio.file.FileVisitResult.CONTINUE
                }

                override fun visitFileFailed(file: java.nio.file.Path, exc: IOException): java.nio.file.FileVisitResult =
                    java.nio.file.FileVisitResult.CONTINUE
            })
        } catch (e: Exception) {
        }
    } else {
        try {
            root.walkTopDown()
                .onEnter { d -> d == root || ((hidden || !d.name.startsWith(".")) && !(d.parentFile == root && d.name == "Android")) }
                .forEach { f ->
                    if (f.isDirectory) {
                        if (f != root) dirs.add(f)
                    } else if (hidden || !f.name.startsWith(".")) {
                        files.add(f)
                        mtimes[f.path] = f.lastModified()
                        val c = f.cat()
                        if (c != null) sizes[c] = (sizes[c] ?: 0L) + f.length()
                    }
                }
        } catch (e: Exception) {
        }
    }
    return ScanResult(files, dirs, sizes, mtimes)
}

fun dirSize(f: File): Long = if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }

// ---------- Creating new files ----------

fun writeZipText(out: File, entries: List<Pair<String, String>>) {
    ZipOutputStream(FileOutputStream(out)).use { z ->
        for ((name, text) in entries) {
            z.putNextEntry(ZipEntry(name))
            z.write(text.toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
    }
}

const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
const val REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
const val OD_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

fun createNewItem(target: File, kind: String) {
    when (kind) {
        "dir" -> if (!target.mkdirs()) throw IOException("Could not create folder")
        "txt" -> target.writeText("")
        "pdf" -> {
            val sb = StringBuilder("%PDF-1.4\n")
            val offs = ArrayList<Int>()
            val objs = listOf(
                "<</Type/Catalog/Pages 2 0 R>>",
                "<</Type/Pages/Kids[3 0 R]/Count 1>>",
                "<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]>>"
            )
            objs.forEachIndexed { i, o ->
                offs.add(sb.length)
                sb.append("${i + 1} 0 obj\n$o\nendobj\n")
            }
            val x = sb.length
            sb.append("xref\n0 4\n0000000000 65535 f \n")
            offs.forEach { sb.append(String.format(Locale.US, "%010d 00000 n \n", it)) }
            sb.append("trailer\n<</Size 4/Root 1 0 R>>\nstartxref\n$x\n%%EOF\n")
            target.writeBytes(sb.toString().toByteArray(Charsets.ISO_8859_1))
        }
        "docx" -> writeZipText(
            target, listOf(
                "[Content_Types].xml" to "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>",
                "_rels/.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/officeDocument\" Target=\"word/document.xml\"/></Relationships>",
                "word/document.xml" to "$XML<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body><w:p/></w:body></w:document>"
            )
        )
        "xlsx" -> writeZipText(
            target, listOf(
                "[Content_Types].xml" to "$XML<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>",
                "_rels/.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
                "xl/workbook.xml" to "$XML<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$OD_REL\"><sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>",
                "xl/_rels/workbook.xml.rels" to "$XML<Relationships xmlns=\"$REL_NS\"><Relationship Id=\"rId1\" Type=\"$OD_REL/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>",
                "xl/worksheets/sheet1.xml" to "$XML<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData/></worksheet>"
            )
        )
        "zip" -> {
            val b = ByteArray(22)
            b[0] = 0x50; b[1] = 0x4B; b[2] = 0x05; b[3] = 0x06
            target.writeBytes(b)
        }
        else -> throw IOException("Unknown type")
    }
}

// ---------- Open / share ----------

fun mimeOf(f: File): String = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.ext) ?: "*/*"

fun uriOf(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".provider", f)

fun openFile(ctx: Context, f: File) {
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriOf(ctx, f), mimeOf(f))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot open file", Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(ctx: Context, files: List<File>) {
    val fs = files.filter { it.isFile }
    if (fs.isEmpty()) {
        Toast.makeText(ctx, "Folders cannot be shared", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val i = if (fs.size == 1) {
            Intent(Intent.ACTION_SEND).setType(mimeOf(fs[0])).putExtra(Intent.EXTRA_STREAM, uriOf(ctx, fs[0]))
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(fs.map { uriOf(ctx, it) }))
        }
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Cannot share", Toast.LENGTH_SHORT).show()
    }
}
