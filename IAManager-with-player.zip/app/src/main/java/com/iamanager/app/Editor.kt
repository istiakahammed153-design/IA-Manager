/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalMaterial3Api::class)

package com.iamanager.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

// ---------------- Edit operations ----------------

sealed interface Op {
    data class Rotate(val deg: Int) : Op
    data object Flip : Op
    data class Crop(val l: Float, val t: Float, val r: Float, val b: Float) : Op
    data class Markup(val shapes: List<Shape>) : Op
}

data class Tone(val filter: Int = 0, val bright: Float = 0f, val contrast: Float = 1f, val sat: Float = 1f) {
    val isDefault: Boolean get() = filter == 0 && bright == 0f && contrast == 1f && sat == 1f
}

val FILTER_NAMES = listOf("Original", "Vivid", "Warm", "Cool", "B&W")

fun decodeScaled(f: File, max: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val deg = try {
        when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90
            3 -> 180
            8 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }
    if (deg == 0) return bmp
    val m = Matrix()
    m.postRotate(deg.toFloat())
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
}

private fun contrastM(c: Float, b: Float = 0f): ColorMatrix {
    val t = (-0.5f * c + 0.5f) * 255f + b
    return ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f))
}

fun colorMatrixFor(p: Tone): ColorMatrix {
    val cm = ColorMatrix()
    when (p.filter) {
        1 -> {
            val s = ColorMatrix(); s.setSaturation(1.45f)
            cm.postConcat(s); cm.postConcat(contrastM(1.1f))
        }
        2 -> cm.postConcat(ColorMatrix(floatArrayOf(1.12f, 0f, 0f, 0f, 8f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0.85f, 0f, -8f, 0f, 0f, 0f, 1f, 0f)))
        3 -> cm.postConcat(ColorMatrix(floatArrayOf(0.88f, 0f, 0f, 0f, -6f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.15f, 0f, 10f, 0f, 0f, 0f, 1f, 0f)))
        4 -> {
            val s = ColorMatrix(); s.setSaturation(0f)
            cm.postConcat(s)
        }
    }
    val s = ColorMatrix(); s.setSaturation(p.sat)
    cm.postConcat(s)
    cm.postConcat(contrastM(p.contrast, p.bright * 2.55f))
    return cm
}

private fun applyTone(b: Bitmap, t: Tone): Bitmap {
    if (t.isDefault) return b
    val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(colorMatrixFor(t))
    Canvas(out).drawBitmap(b, 0f, 0f, paint)
    return out
}

fun applyOps(src: Bitmap, ops: List<Op>, tone: Tone): Bitmap {
    var b = src
    var toned = false
    for (op in ops) {
        if (op is Op.Markup && !toned) {
            b = applyTone(b, tone)
            toned = true
        }
        b = when (op) {
            is Op.Rotate -> {
                val m = Matrix()
                m.postRotate(op.deg.toFloat())
                Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            }
            Op.Flip -> {
                val m = Matrix()
                m.postScale(-1f, 1f)
                Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
            }
            is Op.Crop -> {
                val x = (op.l * b.width).toInt().coerceIn(0, b.width - 1)
                val y = (op.t * b.height).toInt().coerceIn(0, b.height - 1)
                val w = ((op.r - op.l) * b.width).toInt().coerceIn(1, b.width - x)
                val h = ((op.b - op.t) * b.height).toInt().coerceIn(1, b.height - y)
                Bitmap.createBitmap(b, x, y, w, h)
            }
            is Op.Markup -> {
                val out = b.copy(Bitmap.Config.ARGB_8888, true) ?: b
                drawShapes(Canvas(out), out.width.toFloat(), out.height.toFloat(), op.shapes)
                out
            }
        }
    }
    if (!toned) b = applyTone(b, tone)
    return b
}

// ---------------- Crop overlay ----------------

data class CropRect(val l: Float, val t: Float, val r: Float, val b: Float)

private fun fitRatioRect(ratio: Float, iw: Float, ih: Float): CropRect {
    if (ratio <= 0f) return CropRect(0f, 0f, 1f, 1f)
    // largest centered rect with pixel ratio w/h = ratio
    var w = iw
    var h = w / ratio
    if (h > ih) {
        h = ih
        w = h * ratio
    }
    val nw = w / iw
    val nh = h / ih
    return CropRect((1f - nw) / 2f, (1f - nh) / 2f, (1f + nw) / 2f, (1f + nh) / 2f)
}

@Composable
fun CropOverlay(bmp: Bitmap, ratio: Float, rect: CropRect, onRect: (CropRect) -> Unit) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    val density = LocalDensity.current.density
    val iw = bmp.width.toFloat()
    val ih = bmp.height.toFloat()
    val sc = if (box.width > 0 && box.height > 0) minOf(box.width / iw, box.height / ih) else 1f
    val rw = iw * sc
    val rh = ih * sc
    val rl = (box.width - rw) / 2f
    val rt = (box.height - rh) / 2f
    var mode by remember { mutableIntStateOf(0) }
    var cur by remember { mutableStateOf(rect) }
    LaunchedEffect(rect) { cur = rect }
    val minSize = 0.08f

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { box = it }) {
        Image(bitmap = bmp.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        ComposeCanvas(
            Modifier.fillMaxSize().pointerInput(ratio, box) {
                val hit = 30f * density
                detectDragGestures(
                    onDragStart = { pos ->
                        val x1 = rl + cur.l * rw
                        val x2 = rl + cur.r * rw
                        val y1 = rt + cur.t * rh
                        val y2 = rt + cur.b * rh
                        fun near(a: Float, b: Float) = Math.abs(a - b) < hit
                        mode = when {
                            near(pos.x, x1) && near(pos.y, y1) -> 2
                            near(pos.x, x2) && near(pos.y, y1) -> 3
                            near(pos.x, x1) && near(pos.y, y2) -> 4
                            near(pos.x, x2) && near(pos.y, y2) -> 5
                            ratio <= 0f && near(pos.x, x1) && pos.y in y1..y2 -> 6
                            ratio <= 0f && near(pos.x, x2) && pos.y in y1..y2 -> 7
                            ratio <= 0f && near(pos.y, y1) && pos.x in x1..x2 -> 8
                            ratio <= 0f && near(pos.y, y2) && pos.x in x1..x2 -> 9
                            pos.x in x1..x2 && pos.y in y1..y2 -> 1
                            else -> 0
                        }
                    },
                    onDragEnd = { mode = 0; onRect(cur) },
                    onDragCancel = { mode = 0; onRect(cur) },
                    onDrag = { change, delta ->
                        if (mode != 0 && rw > 0f && rh > 0f) {
                            val dx = delta.x / rw
                            val dy = delta.y / rh
                            var c = cur
                            when (mode) {
                                1 -> {
                                    val w = c.r - c.l
                                    val h = c.b - c.t
                                    val nl = (c.l + dx).coerceIn(0f, 1f - w)
                                    val nt = (c.t + dy).coerceIn(0f, 1f - h)
                                    c = CropRect(nl, nt, nl + w, nt + h)
                                }
                                6 -> c = c.copy(l = (c.l + dx).coerceIn(0f, c.r - minSize))
                                7 -> c = c.copy(r = (c.r + dx).coerceIn(c.l + minSize, 1f))
                                8 -> c = c.copy(t = (c.t + dy).coerceIn(0f, c.b - minSize))
                                9 -> c = c.copy(b = (c.b + dy).coerceIn(c.t + minSize, 1f))
                                else -> {
                                    val left = mode == 2 || mode == 4
                                    val top = mode == 2 || mode == 3
                                    if (ratio <= 0f) {
                                        c = if (left) c.copy(l = (c.l + dx).coerceIn(0f, c.r - minSize))
                                        else c.copy(r = (c.r + dx).coerceIn(c.l + minSize, 1f))
                                        c = if (top) c.copy(t = (c.t + dy).coerceIn(0f, c.b - minSize))
                                        else c.copy(b = (c.b + dy).coerceIn(c.t + minSize, 1f))
                                    } else {
                                        val ax = if (left) c.r else c.l
                                        val ay = if (top) c.b else c.t
                                        val px = (if (left) c.l else c.r) + dx
                                        var nw = Math.abs(px - ax).coerceAtLeast(minSize)
                                        var nh = nw * rw / (ratio * rh)
                                        val maxW = if (left) ax else 1f - ax
                                        val maxH = if (top) ay else 1f - ay
                                        if (nw > maxW) {
                                            nw = maxW
                                            nh = nw * rw / (ratio * rh)
                                        }
                                        if (nh > maxH) {
                                            nh = maxH
                                            nw = nh * ratio * rh / rw
                                        }
                                        val nl = if (left) ax - nw else ax
                                        val nt = if (top) ay - nh else ay
                                        c = CropRect(nl, nt, nl + nw, nt + nh)
                                    }
                                }
                            }
                            cur = c
                        }
                        change.consume()
                    }
                )
            }
        ) {
            val x1 = rl + cur.l * rw
            val x2 = rl + cur.r * rw
            val y1 = rt + cur.t * rh
            val y2 = rt + cur.b * rh
            val dim = Color(0xAA000000)
            drawRect(dim, Offset(0f, 0f), Size(size.width, y1))
            drawRect(dim, Offset(0f, y2), Size(size.width, size.height - y2))
            drawRect(dim, Offset(0f, y1), Size(x1, y2 - y1))
            drawRect(dim, Offset(x2, y1), Size(size.width - x2, y2 - y1))
            drawRect(Color.White, Offset(x1, y1), Size(x2 - x1, y2 - y1), style = Stroke(width = 2f * density))
            val thin = Stroke(width = 1f * density)
            val g = Color(0x88FFFFFF)
            for (i in 1..2) {
                val gx = x1 + (x2 - x1) * i / 3f
                val gy = y1 + (y2 - y1) * i / 3f
                drawLine(g, Offset(gx, y1), Offset(gx, y2), strokeWidth = thin.width)
                drawLine(g, Offset(x1, gy), Offset(x2, gy), strokeWidth = thin.width)
            }
            val r = 7f * density
            for (cx in listOf(x1, x2)) for (cy in listOf(y1, y2)) drawCircle(Color.White, r, Offset(cx, cy))
        }
    }
}

// ---------------- Editor screen ----------------

@Composable
private fun ToolBtn(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(21.dp))
                .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
        }
        Text(label, fontSize = 11.sp, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
    }
}

private val CROP_PRESETS = listOf("Free" to 0f, "1:1" to 1f, "4:3" to 4f / 3f, "3:4" to 3f / 4f, "16:9" to 16f / 9f, "9:16" to 9f / 16f)

@Composable
fun EditorScreen(vm: AppViewModel, path: String) {
    val file = File(path)
    val scope = rememberCoroutineScope()
    var src by remember { mutableStateOf<Bitmap?>(null) }
    val ops = remember { mutableStateListOf<Op>() }
    val redo = remember { mutableStateListOf<Op>() }
    var tone by remember { mutableStateOf(Tone()) }
    var tool by remember { mutableIntStateOf(1) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var saving by remember { mutableStateOf(false) }
    var markup by remember { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    var cropRatioIdx by remember { mutableIntStateOf(0) }
    var cropRect by remember { mutableStateOf(CropRect(0f, 0f, 1f, 1f)) }

    LaunchedEffect(path) { src = withContext(Dispatchers.IO) { decodeScaled(file, 1280) } }
    val opsSnapshot = ops.toList()
    LaunchedEffect(src, opsSnapshot, tone) {
        val s = src ?: return@LaunchedEffect
        preview = withContext(Dispatchers.Default) { applyOps(s, opsSnapshot, tone) }
    }
    val thumbs = remember(src) {
        val s = src
        if (s == null) emptyList() else {
            val h = (96f * s.height / s.width).toInt().coerceAtLeast(1)
            val small = Bitmap.createScaledBitmap(s, 96, h, true)
            FILTER_NAMES.indices.map { applyOps(small, emptyList(), Tone(filter = it)) }
        }
    }
    val dirty = ops.isNotEmpty() || !tone.isDefault
    BackHandler(enabled = dirty && !markup) { discard = true }

    fun resetCrop(ratioIdx: Int) {
        val p = preview
        cropRect = if (p != null) fitRatioRect(CROP_PRESETS[ratioIdx].second, p.width.toFloat(), p.height.toFloat()) else CropRect(0f, 0f, 1f, 1f)
    }

    LaunchedEffect(preview?.width, preview?.height) { if (tool == 0) resetCrop(cropRatioIdx) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface)) {
            SimpleTop("Edit Photo", onBack = { if (dirty) discard = true else vm.pop() }) {
                IconButton(onClick = { if (ops.isNotEmpty()) redo.add(ops.removeAt(ops.lastIndex)) }, enabled = ops.isNotEmpty()) {
                    Icon(Icons.Outlined.Undo, "Undo")
                }
                IconButton(onClick = { if (redo.isNotEmpty()) ops.add(redo.removeAt(redo.lastIndex)) }, enabled = redo.isNotEmpty()) {
                    Icon(Icons.Outlined.Redo, "Redo")
                }
                TextButton(
                    enabled = !saving && src != null && dirty,
                    onClick = {
                        saving = true
                        val opsCopy = ops.toList()
                        val toneCopy = tone
                        scope.launch {
                            val res = withContext(Dispatchers.IO) {
                                try {
                                    val full = decodeScaled(file, 3072) ?: throw IllegalStateException("decode")
                                    val out = applyOps(full, opsCopy, toneCopy)
                                    val png = file.ext == "png"
                                    val target = uniqueFile(
                                        file.parentFile ?: vm.root,
                                        file.nameWithoutExtension + "_edited." + (if (png) "png" else "jpg")
                                    )
                                    FileOutputStream(target).use {
                                        out.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it)
                                    }
                                    target.name
                                } catch (e: Throwable) {
                                    null
                                }
                            }
                            saving = false
                            vm.message = if (res != null) "Saved: $res" else "Could not save image"
                            if (res != null) {
                                vm.refresh()
                                vm.pop()
                            }
                        }
                    }
                ) { Text(if (saving) "Saving..." else "Save", fontWeight = FontWeight.Bold) }
            }
            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black), contentAlignment = Alignment.Center) {
                val pv = preview
                if (pv == null) {
                    CircularProgressIndicator()
                } else if (tool == 0) {
                    CropOverlay(pv, CROP_PRESETS[cropRatioIdx].second, cropRect) { cropRect = it }
                } else {
                    Image(bitmap = pv.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                }
            }
            Box(Modifier.fillMaxWidth().heightIn(min = 96.dp).padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                when (tool) {
                    0 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CROP_PRESETS.forEachIndexed { i, (n, _) ->
                                FilterChip(selected = cropRatioIdx == i, onClick = { cropRatioIdx = i; resetCrop(i) }, label = { Text(n) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick = { resetCrop(cropRatioIdx) }) { Text("Reset") }
                            Button(onClick = {
                                val c = cropRect
                                if (c.l > 0.001f || c.t > 0.001f || c.r < 0.999f || c.b < 0.999f) {
                                    ops.add(Op.Crop(c.l, c.t, c.r, c.b))
                                    redo.clear()
                                }
                                cropRect = CropRect(0f, 0f, 1f, 1f)
                                cropRatioIdx = 0
                                tool = 1
                            }) { Text("Apply crop") }
                        }
                    }
                    1 -> LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        itemsIndexed(FILTER_NAMES) { i, n ->
                            Column(Modifier.clickable { tone = tone.copy(filter = i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                val t = thumbs.getOrNull(i)
                                Box(
                                    Modifier.size(60.dp).clip(RoundedCornerShape(8.dp))
                                        .border(if (tone.filter == i) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    if (t != null) Image(t.asImageBitmap(), null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                }
                                Text(
                                    n, fontSize = 11.sp,
                                    color = if (tone.filter == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    2 -> Column(Modifier.padding(horizontal = 20.dp)) {
                        Text("Brightness", fontSize = 12.sp)
                        Slider(value = tone.bright, onValueChange = { tone = tone.copy(bright = it) }, valueRange = -100f..100f)
                        Text("Contrast", fontSize = 12.sp)
                        Slider(value = tone.contrast, onValueChange = { tone = tone.copy(contrast = it) }, valueRange = 0.5f..1.5f)
                        Text("Saturation", fontSize = 12.sp)
                        Slider(value = tone.sat, onValueChange = { tone = tone.copy(sat = it) }, valueRange = 0f..2f)
                    }
                    else -> Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        OutlinedButton(onClick = { ops.add(Op.Flip); redo.clear() }) {
                            Icon(Icons.Outlined.Flip, null); Spacer(Modifier.width(6.dp)); Text("Flip")
                        }
                        OutlinedButton(onClick = { ops.clear(); redo.clear(); tone = Tone() }) {
                            Icon(Icons.Outlined.RestartAlt, null); Spacer(Modifier.width(6.dp)); Text("Reset all")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                ToolBtn(Icons.Outlined.Crop, "Crop", tool == 0) { tool = 0; resetCrop(cropRatioIdx) }
                ToolBtn(Icons.Outlined.RotateRight, "Rotate", false) { ops.add(Op.Rotate(90)); redo.clear() }
                ToolBtn(Icons.Outlined.AutoAwesome, "Filter", tool == 1) { tool = 1 }
                ToolBtn(Icons.Outlined.Tune, "Adjust", tool == 2) { tool = 2 }
                ToolBtn(Icons.Outlined.Brush, "Draw", false) { if (preview != null) markup = true }
                ToolBtn(Icons.Outlined.MoreHoriz, "More", tool == 3) { tool = 3 }
            }
        }
        val pv = preview
        if (markup && pv != null) {
            MarkupEditor(
                base = pv,
                onCancel = { markup = false },
                onDone = { shapes ->
                    if (shapes.isNotEmpty()) {
                        ops.add(Op.Markup(shapes))
                        redo.clear()
                    }
                    markup = false
                }
            )
        }
    }
    if (discard) {
        AlertDialog(
            onDismissRequest = { discard = false },
            title = { Text("Discard edits?") },
            text = { Text("Your changes have not been saved.") },
            confirmButton = { TextButton(onClick = { discard = false; vm.pop() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } }
        )
    }
}
