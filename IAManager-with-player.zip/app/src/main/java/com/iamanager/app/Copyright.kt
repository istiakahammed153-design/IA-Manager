/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.content.Context
import java.security.MessageDigest

/**
 * Ownership information. The author name is verified at start-up; a build in which the
 * copyright owner has been altered or removed refuses to run.
 */
object Owner {
    private val codes = intArrayOf(73, 115, 116, 105, 97, 107, 32, 65, 104, 97, 109, 109, 101, 100)
    private const val HASH = "9829fa07414ff487857c7f1f00c26457aaf6aa1ccdcd2ea3ff3d643d118f0b82"
    const val YEAR = "2026"

    val name: String get() = String(CharArray(codes.size) { codes[it].toChar() })
    val notice: String get() = "\u00A9 $YEAR $name. All rights reserved."

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun verify(ctx: Context): Boolean = try {
        sha(name) == HASH && sha(ctx.getString(R.string.copyright_owner)) == HASH
    } catch (e: Exception) {
        false
    }
}
