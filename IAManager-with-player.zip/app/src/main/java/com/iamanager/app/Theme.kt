/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val Blue = Color(0xFF1A73E8)

private val LightScheme = lightColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EEFF),
    onPrimaryContainer = Color(0xFF0B3D91),
    secondaryContainer = Color(0xFFE3EEFF),
    background = Color(0xFFF6F8FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFEEF2F8),
    onSurfaceVariant = Color(0xFF5F6B7A),
    outlineVariant = Color(0xFFE0E5EC)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF4C8DF6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF16305E),
    onPrimaryContainer = Color(0xFFD6E4FF),
    secondaryContainer = Color(0xFF16305E),
    background = Color(0xFF0B111C),
    surface = Color(0xFF111827),
    surfaceVariant = Color(0xFF1B2433),
    onSurfaceVariant = Color(0xFF9AA7B8),
    outlineVariant = Color(0xFF273244)
)

@Composable
fun IATheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val cs = if (dark) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as Activity).window
            w.statusBarColor = cs.surface.toArgb()
            w.navigationBarColor = cs.surface.toArgb()
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = cs, content = content)
}
