# IA Manager

Android file manager. Copyright (c) 2026 Istiak Ahammed. All rights reserved. (see LICENSE)

## APK তৈরি (GitHub Actions)
1. এই zip ফাইলটি GitHub repo-র root-এ আপলোড করুন (repo **private** রাখুন)।
2. `.github/workflows/build.yml` ফাইলটি repo-তে রাখুন।
3. Actions ট্যাবে "Build APK" চলবে → শেষে **Artifacts → IAManager-apk** নামিয়ে ইন্সটল করুন।
4. প্রথমবার অ্যাপ খুললে "All files access" পারমিশন দিন।

## Start-up
An animated start-up screen (Splash.kt) covers the app while the first scan runs, then fades away.

## Vault (security notes)
- AES-256-GCM, 1 MiB chunks, a fresh key per file. Name, folder, size and date are inside the encrypted data.
- Password -> scrypt (N=32768, r=8, p=1, 32 MB per guess; verified against the RFC 7914 vector by a built-in self-test) -> wraps a random master key.
- One-time recovery key (160 bits) wraps the same master key, so a forgotten password is recoverable (keep it on paper).
- Each storage (internal / SD card) has its own `.IAVault` folder with its own encrypted index and a copy of the small header.
  SD-card data is encrypted, viewed (temp copy in the SD card's own app cache) and restored on the SD card, never using internal storage.
- Adding: encrypt -> decrypt again and compare SHA-256 -> only then overwrite + delete the original. Folders keep their structure.
- The Vault is not listed on the Home screen or in the menu: press and hold the "IA Manager" title (Home or menu) to open it.
- Videos and audio from the Vault are decrypted in memory while they play (instant start, instant seeking, no readable copy on the disk, no picture-in-picture, no notification). Other files are opened from a short-lived private copy that is wiped when you leave.
- Vault operations never show file names in notifications; decoded images are dropped from the image cache when the Vault locks; app backup is off.
- Wrong passwords are throttled; the vault auto-locks; screenshots are blocked inside it; "Check vault integrity" decrypts everything.

## Video & audio player
Videos and audio open in a full-featured built-in player (speed control, gestures, subtitles, audio tracks,
picture-in-picture, background audio with notification controls, A-B repeat, sleep timer, equalizer/boost,
playlist of the folder, bookmarks, favorites, screenshot, cut clip, extract audio). Code: `app/.../player/`.
Files opened from the Vault play in a locked-down mode (no screenshots, share, cut or background play).


## Transfers keep running (Ops.kt)
Copy, move, delete, zip and Vault in/out run inside the app process, not inside a screen, with a foreground service
(progress notification + Cancel button). You can press Home, switch apps or close IA Manager: the transfer carries on
and a notification reports the result. Files are written to a hidden `.iapart` file first and renamed only when complete;
originals are removed only after a verified copy exists. If Android still kills the app, the half-written files are
removed at the next start.

## v1.3.0
- Built-in APK installer (.apk, plus split bundles .apks / .xapk / .apkm): tap an APK to see its name, version, permissions and install / update it.
- Apps manager: installed apps list (search, system toggle), backup APK, share APK, app info, uninstall; list of every APK on the phone.
- Large Files finder and Duplicate Files finder.
