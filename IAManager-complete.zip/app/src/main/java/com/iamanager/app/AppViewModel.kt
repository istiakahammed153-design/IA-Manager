/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.app.Application
import android.content.Context
import android.os.Environment
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("ia_prefs", Context.MODE_PRIVATE)
    private fun readLines(k: String): List<String> =
        (sp.getString(k, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeLines(k: String, v: List<String>) {
        val e = sp.edit().putString(k, v.joinToString("\n"))
        if (k == "trash") e.commit() else e.apply()   // recycle-bin index is written to disk immediately
    }

    val internalRoot: File = Environment.getExternalStorageDirectory()
    val trashDir: File = File(internalRoot, ".IATrash")

    // storages (internal + SD card / USB)
    var root by mutableStateOf(internalRoot)
    var storages by mutableStateOf(listOf(StorageVol("Internal Storage", internalRoot)))
    var showStoragePicker by mutableStateOf(false)
    val rootName: String get() = storages.firstOrNull { it.root.path == root.path }?.name ?: "Internal Storage"

    fun updateStorages(ctx: Context) {
        val list = detectStorages(ctx)
        storages = list
        prefetchStorages(list)
        Vault.setVolumes(list.map { it.root })   // the Vault keeps a separate encrypted folder on every storage
        if (list.none { it.root.path == root.path }) {
            selectStorage(list.first())
        }
    }

    /** Path of the media file whose player screen is currently open (so it is not launched twice). */
    var playerLaunchedFor: String? = null

    /** True once the start-up animation has finished (kept here so a screen rotation does not replay it). */
    var splashDone by mutableStateOf(false)

    fun selectStorage(v: StorageVol) {
        root = v.root
        val cached = scanCache[v.root.path + showHidden]
        allFiles = cached?.files ?: emptyList()
        allDirs = cached?.dirs ?: emptyList()
        catSizes = cached?.sizes ?: loadSizes(v.root.path + showHidden)
        allMtimes = cached?.mtimes ?: emptyMap()
        goTab(Screen.Home)
        tick++   // storage card re-reads the numbers of the new storage
        updateScanning()
        scan()
    }

    // ---- scroll positions & list caches (survive leaving and re-entering a screen) ----
    private val listStates = HashMap<String, LazyListState>()
    private val gridStates = HashMap<String, LazyGridState>()
    private val scrollStates = HashMap<String, ScrollState>()
    fun listState(k: String): LazyListState = listStates.getOrPut(k) { LazyListState() }
    fun gridState(k: String): LazyGridState = gridStates.getOrPut(k) { LazyGridState() }
    fun scrollState(k: String): ScrollState = scrollStates.getOrPut(k) { ScrollState(0) }

    private fun forgetScroll(s: Screen) {
        val p = s.toString() + "|"
        listStates.keys.removeAll { it.startsWith(p) }
        gridStates.keys.removeAll { it.startsWith(p) }
        scrollStates.keys.removeAll { it.startsWith(p) }
    }

    private fun <V> lru(max: Int) = object : LinkedHashMap<String, V>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, V>?) = size > max
    }

    /** Last known folder listing / category listing, shown instantly while a fresh one loads in the background. */
    val dirCache: MutableMap<String, List<File>> = lru(40)
    val catCache: MutableMap<String, List<File>> = lru(40)

    // navigation
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()
    var selected by mutableStateOf<Set<String>>(emptySet())

    // settings
    var theme by mutableIntStateOf(sp.getInt("theme", 0))
    var showHidden by mutableStateOf(sp.getBoolean("hidden", false))
    var gridView by mutableStateOf(sp.getBoolean("grid", false))
    var sortBy by mutableIntStateOf(sp.getInt("sort", 0))

    private val gridMap = mutableStateMapOf<String, Boolean>()
    fun isGrid(c: Cat): Boolean =
        gridMap[c.name] ?: sp.getBoolean("grid_" + c.name, c == Cat.IMAGES || c == Cat.VIDEOS)

    fun setCatGrid(c: Cat, v: Boolean) {
        gridMap[c.name] = v
        sp.edit().putBoolean("grid_" + c.name, v).apply()
    }

    // persisted lists
    var starred by mutableStateOf(readLines("starred"))
    var recent by mutableStateOf(readLines("recent"))
    var shared by mutableStateOf(readLines("shared"))
    var trash by mutableStateOf(readLines("trash"))

    // ---- recycle bin auto-delete: 0 = never, otherwise the number of days an item may stay in the bin ----
    var trashDays by mutableIntStateOf(sp.getInt("trash_days", 0))

    fun setTrashDays(days: Int) {
        trashDays = days
        sp.edit().putInt("trash_days", days).apply()
        purgeOldTrash()
    }

    private fun stampTrash(entry: String) {
        sp.edit().putLong("tt_$entry", System.currentTimeMillis()).apply()
    }

    /** Whole days left before [entry] is deleted automatically, or null when auto-delete is off. */
    fun trashDaysLeft(entry: String): Int? {
        if (trashDays <= 0) return null
        val t = sp.getLong("tt_$entry", 0L)
        if (t == 0L) return trashDays
        val left = trashDays * 86_400_000L - (System.currentTimeMillis() - t)
        return if (left <= 0L) 0 else ((left + 86_400_000L - 1) / 86_400_000L).toInt()
    }

    /** Permanently deletes the recycle-bin items that stayed longer than the chosen number of days. */
    fun purgeOldTrash() {
        val days = trashDays
        if (days <= 0 || trash.isEmpty()) return
        val limit = days * 86_400_000L
        val snapshot = trash
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val removed = HashSet<String>()
            val ed = sp.edit()
            for (e in snapshot) {
                val k = "tt_$e"
                val t = sp.getLong(k, 0L)
                if (t == 0L) { ed.putLong(k, now); continue }   // items from before this feature start counting now
                if (now - t < limit) continue
                val f = trashFile(e)
                if (f.exists() && !f.deleteRecursively() && f.exists()) continue   // could not delete: try next time
                ed.remove(k)
                removed += e
            }
            ed.apply()
            if (removed.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    trash = trash.filter { it !in removed }
                    writeLines("trash", trash)
                    message = "Recycle Bin: ${removed.size} old item(s) deleted automatically"
                }
            }
        }
    }

    init { purgeOldTrash() }
    var searches by mutableStateOf(readLines("searches"))

    // scan results
    var allFiles by mutableStateOf<List<File>>(emptyList())
    var allDirs by mutableStateOf<List<File>>(emptyList())
    var catSizes by mutableStateOf<Map<Cat, Long>>(emptyMap())
    var allMtimes by mutableStateOf<Map<String, Long>>(emptyMap())
    var scanning by mutableStateOf(false)
    var tick by mutableIntStateOf(0)

    // ui state
    var message by mutableStateOf<String?>(null)
    var pickerMove by mutableStateOf<Boolean?>(null)
    var confirmDelete by mutableStateOf(false)
    var renameTarget by mutableStateOf<String?>(null)

    fun changeTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun setGrid(v: Boolean) { gridView = v; sp.edit().putBoolean("grid", v).apply() }
    fun setSort(v: Int) { sortBy = v; sp.edit().putInt("sort", v).apply() }
    fun setHidden(v: Boolean) { showHidden = v; sp.edit().putBoolean("hidden", v).apply(); refresh() }

    // ---- navigation ----
    fun push(s: Screen) { selected = emptySet(); stack.add(s); lockVaultIfOutside() }
    fun pop() {
        selected = emptySet()
        if (stack.size > 1) forgetScroll(stack.removeAt(stack.lastIndex))
        lockVaultIfOutside()
    }
    /** Pops only if [path] is still the viewer on top (prevents a double pop that would also leave the Vault). */
    fun popViewer(path: String) {
        val c = stack.lastOrNull()
        if (c is Screen.Viewer && c.path == path) pop()
    }
    fun goTab(s: Screen) {
        selected = emptySet()
        stack.drop(1).forEach { forgetScroll(it) }
        stack.clear()
        if (s != Screen.Home) stack.add(Screen.Home)
        stack.add(s)
        lockVaultIfOutside()
    }

    /** The Vault locks the very moment you leave it (no delay). Safe for "Move to Vault": the key is copied before navigation. */
    fun lockVaultIfOutside() {
        val s = stack.lastOrNull()
        val inside = s is Screen.Vault || (s is Screen.Viewer && Vault.isTemp(s.path))
        if (!inside && vaultPending == null && Vault.unlocked) Vault.lock()
    }

    fun toggleSelect(p: String) { selected = if (p in selected) selected - p else selected + p }

    fun dismissDialogs() {
        pickerMove = null
        confirmDelete = false
        renameTarget = null
        if (current is Screen.Details || current is Screen.Viewer) selected = emptySet()
    }

    // ---- scanning ----
    fun refresh() { tick++; scan() }

    private val scanCache = java.util.concurrent.ConcurrentHashMap<String, ScanResult>()

    private val scanJobs = HashMap<String, Job>()
    private val rescanKeys = HashSet<String>()
    private var lastScan = 0L

    private fun sizesKey(key: String) = "sizes|$key"

    private fun saveSizes(key: String, m: Map<Cat, Long>) {
        sp.edit().putString(sizesKey(key), m.entries.joinToString(";") { it.key.name + ":" + it.value }).apply()
    }

    private fun loadSizes(key: String): Map<Cat, Long> {
        val raw = sp.getString(sizesKey(key), null) ?: return emptyMap()
        val out = HashMap<Cat, Long>()
        for (part in raw.split(";")) {
            val kv = part.split(":")
            if (kv.size != 2) continue
            val c = Cat.values().firstOrNull { it.name == kv[0] } ?: continue
            out[c] = kv[1].toLongOrNull() ?: continue
        }
        return out
    }

    private fun updateScanning() {
        scanning = scanJobs[root.path + showHidden]?.isActive == true
    }

    /** Scans one storage in the background. Several storages can be scanned at the same time. */
    private fun startScan(r: File, hidden: Boolean) {
        val key = r.path + hidden
        if (scanJobs[key]?.isActive == true) { rescanKeys.add(key); return }
        if (r.path == root.path && hidden == showHidden && allFiles.isEmpty() && catSizes.isEmpty()) {
            catSizes = loadSizes(key)   // last known sizes, shown instantly
        }
        scanJobs[key] = viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    scanRoot(r, hidden)
                } catch (e: Exception) {
                    ScanResult(emptyList(), emptyList(), emptyMap())
                }
            }
            scanCache[key] = res
            saveSizes(key, res.sizes)
            if (r.path == root.path && hidden == showHidden) {
                allFiles = res.files
                allDirs = res.dirs
                catSizes = res.sizes
                allMtimes = res.mtimes
            }
            lastScan = System.currentTimeMillis()
            scanJobs.remove(key)
            updateScanning()
            if (rescanKeys.remove(key)) startScan(r, hidden)
        }
        updateScanning()
    }

    fun scan() = startScan(root, showHidden)

    /** Reads every storage in the background once, so switching storage later is instant. */
    private fun prefetchStorages(list: List<StorageVol>) {
        for (v in list) {
            val key = v.root.path + showHidden
            if (scanCache[key] == null && scanJobs[key]?.isActive != true) startScan(v.root, showHidden)
        }
    }

    // ---- live updates: files added/removed by other apps show up without a manual refresh ----
    private var changeJob: Job? = null

    /** Called by the folder watcher / media observer. Debounced so bursts of events cause only one refresh. */
    fun dirChanged() {
        changeJob?.cancel()
        changeJob = viewModelScope.launch {
            delay(300)
            tick++
            delay(1200)
            scan()
        }
    }

    /** App came back to the foreground (e.g. after opening a file in another app or downloading something). */
    fun onResume(ctx: Context) {
        updateStorages(ctx)
        Vault.onForeground()
        if (Vault.unlocked) viewModelScope.launch(Dispatchers.IO) { Vault.reload() }   // e.g. SD card inserted
        tick++
        if (System.currentTimeMillis() - lastScan > 3000) scan()
    }

    // ---- recents / stars / shares ----
    fun toggleStar(p: String) {
        starred = if (p in starred) starred - p else starred + p
        writeLines("starred", starred)
    }

    fun starSelected() {
        val all = selected.all { it in starred }
        starred = if (all) starred - selected else (starred + selected).distinct()
        writeLines("starred", starred)
        selected = emptySet()
    }

    fun addRecent(p: String) {
        recent = (listOf(p) + recent.filter { it != p }).take(50)
        writeLines("recent", recent)
    }

    fun addSearch(q: String) {
        if (q.isBlank()) return
        searches = (listOf(q.trim()) + searches.filter { it != q.trim() }).take(8)
        writeLines("searches", searches)
    }

    fun clearSearches() { searches = emptyList(); writeLines("searches", searches) }

    fun open(ctx: Context, f: File) {
        if (f.isDirectory) push(Screen.Files(f.path)) else {
            addRecent(f.path)
            push(Screen.Viewer(f.path))
        }
    }

    fun share(ctx: Context, files: List<File>) {
        shareFiles(ctx, files)
        shared = (files.filter { it.isFile }.map { it.path } + shared).distinct().take(100)
        writeLines("shared", shared)
        selected = emptySet()
    }

    // ---- file operations ----
    private fun launchOp(okMsg: String, popViewer: Boolean = true, work: () -> Unit) {
        launchCore(popViewer) { work(); okMsg }
    }

    private fun launchCore(popViewer: Boolean, work: () -> String) {
        viewModelScope.launch {
            var err: String? = null
            var msg = ""
            withContext(Dispatchers.IO) {
                try {
                    msg = work()
                } catch (e: Throwable) {
                    err = e.message ?: "Operation failed"
                }
            }
            val failed = err
            message = failed ?: msg
            selected = emptySet()
            refresh()
            if (failed == null) {
                while (current is Screen.Create || current is Screen.Pick) pop()
                if (popViewer && (current is Screen.Details || current is Screen.Viewer)) pop()
            }
        }
    }

    fun convert(kind: Conv, files: List<File>, dir: File, option: String = "") {
        val ctx = getApplication<Application>()
        launchCore(false) { doConvert(ctx, kind, files, dir, option) }
    }

    // ---------------- safe, tracked operations (progress + speed + cancel) ----------------
    /** The running operation. It is kept in [Ops] (not in this screen model), so it survives the screen being closed. */
    var op: OpState?
        get() = Ops.state
        set(v) { Ops.state = v }

    /**
     * Runs a file operation with progress, speed and cancel.
     * [background] = true (default): the operation belongs to the app, not to the screen. A foreground service with a
     * notification keeps it running when you leave the app or close it, and a result notification is shown when it ends.
     */
    private fun launchTracked(
        title: String,
        files: List<File>,
        measure: Boolean,
        popViewer: Boolean = true,
        background: Boolean = true,
        onSuccess: () -> Unit = {},
        work: (OpState) -> String
    ) {
        if (op != null) { message = "Another operation is still running"; return }
        val st = OpState(title)
        st.secret = title.contains("Vault")   // vault work never shows file names outside the app
        op = st
        if (!background) screenOp = st
        val app = getApplication<Application>()
        if (background) Ops.begin(app)
        val runIn = if (background) Ops.scope else viewModelScope
        runIn.launch {
            var err: String? = null
            var msg = ""
            val t0 = System.currentTimeMillis()
            withContext(Dispatchers.IO) {
                try {
                    if (measure) {
                        var b = 0L
                        files.forEach { b += treeStats(it).first }
                        st.totalBytes = b
                    }
                    st.totalItems = files.size
                    st.preparing = false
                    msg = work(st)
                } catch (e: OpCancelled) {
                    err = "Cancelled. Your original files were not changed."
                } catch (e: Throwable) {
                    err = e.message ?: "Operation failed"
                }
                st.flush()
            }
            val secs = (System.currentTimeMillis() - t0) / 1000.0
            op = null
            val text = err ?: (msg + if (msg.isNotEmpty() && st.totalBytes > 0 && secs >= 2) "  \u2022  ${fmtSize(st.totalBytes)} in ${secs.toInt()}s (${fmtSize((st.totalBytes / secs).toLong())}/s)" else "")
            if (background) {
                // the screen that started the operation may be gone (app closed): whichever screen is open now gets the result
                if (!Ops.visible || Ops.activeVm == null) {
                    val shown = if (st.secret) (if (err != null) "Something went wrong. Open IA Manager for details." else "Done") else text.ifEmpty { "Done" }
                    Ops.notifyDone(app, title, shown, err != null)
                }
                Ops.activeVm?.finishOpUi(text.ifEmpty { null }, err == null, popViewer) { }
            } else {
                finishOpUi(text.ifEmpty { null }, err == null, popViewer, onSuccess)
            }
        }
    }

    /** A short operation that belongs to this screen (not to the app): it is dropped together with the screen. */
    private var screenOp: OpState? = null

    /** What the screen does when an operation has ended: message, refresh, close the finished dialogs. */
    private fun finishOpUi(text: String?, ok: Boolean, popViewer: Boolean, onSuccess: () -> Unit) {
        message = text
        selected = emptySet()
        trash = readLines("trash")   // the operation may have been started by a screen model that no longer exists
        refresh()
        if (ok) {
            while (current is Screen.Create || current is Screen.Pick) pop()
            if (popViewer && (current is Screen.Details || current is Screen.Viewer)) pop()
            onSuccess()
        }
    }

    /** Runs [step] for every file; one failure never stops the others. Throws a summary if anything failed. */
    private inline fun forEachSafe(files: List<File>, st: OpState, verb: String, step: (File) -> Unit): String {
        var ok = 0
        val fails = ArrayList<String>()
        for (f in files) {
            st.checkCancel()
            st.current = f.name
            try {
                step(f)
                ok++
            } catch (e: OpCancelled) {
                throw e
            } catch (e: Throwable) {
                fails += "${f.name}: ${e.message ?: "failed"}"
            }
            st.doneItems++
        }
        if (fails.isNotEmpty()) throw IOException((if (ok > 0) "$verb $ok item(s). " else "") + "Failed: " + fails.joinToString("; "))
        return "$verb $ok item(s)"
    }

    fun copyMove(dest: File, move: Boolean) {
        val files = selected.map { File(it) }
        if (move && files.any { Vault.isVaultPath(it.path) }) {
            message = "Vault files can't be moved from here. Use the Vault's 'Move out of Vault'."
            selected = emptySet()
            return
        }
        launchTracked(if (move) "Moving files" else "Copying files", files, measure = true) { st ->
            forEachSafe(files, st, if (move) "Moved" else "Copied") {
                if (move) moveItemSafe(it, dest, st) else copyItemSafe(it, dest, st)
            }
        }
    }

    // ---- recycle bin: one ".IATrash" folder on each storage, so deleting is an instant, safe rename ----
    fun trashDirFor(f: File): File {
        val vol = storages.map { it.root }.filter { f.path.startsWith(it.path + "/") }.maxByOrNull { it.path.length } ?: internalRoot
        return File(vol, ".IATrash")
    }

    fun trashFile(entry: String): File {
        val name = entry.substringBefore('\t')
        val a = File(trashDirFor(File(entry.substringAfter('\t'))), name)
        return if (a.exists()) a else File(trashDir, name)
    }

    fun deleteSelected() {
        val files = selected.map { File(it) }
        if (files.any { Vault.isVaultPath(it.path) || it.path == internalRoot.path }) {
            message = "The Vault folder is protected. Open the Vault to delete files from inside it."
            selected = emptySet()
            return
        }
        launchTracked("Moving to Recycle Bin", files, measure = false) { st ->
            forEachSafe(files, st, "Moved to Recycle Bin:") { f ->
                val entry = trashItem(f, trashDirFor(f), st)
                trash = trash + entry
                stampTrash(entry)
                writeLines("trash", trash)   // recorded right away, even if a later item fails
            }
        }
    }

    fun rename(path: String, newName: String) {
        launchOp("Renamed") {
            if (Vault.isVaultPath(path)) throw IOException("Vault files can't be renamed")
            val f = File(path)
            val t = File(f.parentFile, newName)
            if (newName.isBlank() || newName.contains("/")) throw IOException("Invalid name")
            if (t.exists()) throw IOException("A file with that name already exists")
            if (!f.renameTo(t)) throw IOException("Rename failed")
        }
    }

    fun createItem(dir: String, kind: String, ext: String, name: String) {
        launchOp("Created") {
            val clean = name.trim().ifEmpty { "New" }
            val full = if (ext.isNotEmpty() && !clean.endsWith(".$ext", true)) "$clean.$ext" else clean
            createNewItem(uniqueFile(File(dir), full), kind)
        }
    }

    fun compress() {
        val files = selected.map { File(it) }
        if (files.isEmpty()) return
        launchTracked("Compressing to ZIP", files, measure = true) { st ->
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val parent = files[0].parentFile ?: root
            checkFreeFor(parent, st.totalBytes)
            zipFilesSafe(files, uniqueFile(parent, "Archive_$stamp.zip"), st)
            "Compressed to ZIP"
        }
    }

    private fun checkFreeFor(dir: File, need: Long) {
        val free = dir.usableSpace
        if (need > 0 && free > 0 && free < need / 2 + (8L shl 20)) throw IOException("Not enough free space")
    }

    fun extract(path: String, stay: Boolean = false) {
        val z = File(path)
        launchTracked("Extracting", listOf(z), measure = false, popViewer = !stay) { st ->
            unzipSafe(z, uniqueFile(z.parentFile ?: root, z.nameWithoutExtension), st)
            "Extracted"
        }
    }

    fun restore(entry: String) {
        launchTracked("Restoring", emptyList(), measure = false) { st ->
            val src = trashFile(entry)
            val orig = File(entry.substringAfter('\t'))
            val parent = orig.parentFile ?: root
            parent.mkdirs()
            val dest = uniqueFile(parent, orig.name)
            st.current = orig.name
            moveExact(src, dest, st)
            trash = trash - entry
            writeLines("trash", trash)
            "Restored"
        }
    }

    fun deleteForever(entry: String) {
        launchTracked("Deleting permanently", emptyList(), measure = false) { st ->
            val f = trashFile(entry)
            st.current = f.name
            if (f.exists() && !f.deleteRecursively() && f.exists()) throw IOException("Could not delete ${f.name}")
            trash = trash - entry
            writeLines("trash", trash)
            "Deleted permanently"
        }
    }

    fun emptyTrash() {
        launchTracked("Emptying Recycle Bin", emptyList(), measure = false) { st ->
            var failed = 0
            val remaining = ArrayList<String>()
            st.totalItems = trash.size
            for (e in trash) {
                st.checkCancel()
                val f = trashFile(e)
                st.current = f.name
                if (f.exists() && !f.deleteRecursively() && f.exists()) { failed++; remaining += e }
                st.doneItems++
            }
            trash = remaining
            writeLines("trash", trash)
            if (failed > 0) throw IOException("$failed item(s) could not be deleted")
            "Recycle Bin emptied"
        }
    }

    // ---------------- VAULT (password-encrypted storage) ----------------
    var vaultPending by mutableStateOf<List<File>?>(null)

    /** "Move to Vault" from any file list: asks for the password first if the vault is locked. */
    fun requestVaultAdd(files: List<File>) {
        if (files.isEmpty()) return
        if (!Vault.exists) {
            message = "Create your Vault first"
            selected = emptySet()
            push(Screen.Vault)
            return
        }
        if (Vault.unlocked) vaultAdd(files) else vaultPending = files
    }

    /** Files go in as they are; folders go in with their whole structure (sub-folders are kept inside the Vault). */
    fun vaultAdd(all: List<File>) {
        val key = Vault.keyCopy() ?: run { message = "Unlock the Vault first"; return }
        val files = all.filterNot { Vault.isVaultPath(it.path) }
        val vmap = HashMap<File, String>()
        val entries = ArrayList<File>()
        val folders = ArrayList<File>()
        for (f in files) {
            if (f.isFile) {
                entries += f
                vmap[f] = ""
            } else if (f.isDirectory) {
                folders += f
                f.walkTopDown().filter { it.isFile }.forEach { x ->
                    entries += x
                    val rel = x.parentFile?.relativeTo(f.parentFile ?: f)?.path ?: f.name
                    vmap[x] = rel.replace(File.separatorChar, '/')
                }
            }
        }
        if (entries.isEmpty()) {
            key.fill(0)
            message = "Nothing to add (empty folder)"
            selected = emptySet()
            return
        }
        launchTracked("Encrypting into Vault", entries, measure = true) { st ->
            st.passes = 3   // encrypt + verify + wipe the original: the bar covers all three, the sizes shown stay the real file size
            try {
                val r = forEachSafe(entries, st, "Moved to Vault:") { f ->
                    Vault.addFile(key, f, vmap[f] ?: "", st)
                    st.phase = "Wiping the original"
                    Vault.shred(f, st)
                }
                // folders that are now empty are removed (only if really empty)
                folders.forEach { fd -> fd.walkBottomUp().filter { it.isDirectory }.forEach { it.delete() } }
                r
            } finally {
                key.fill(0)
            }
        }
    }

    fun vaultOpen(item: VaultItem) {
        val key = Vault.keyCopy() ?: run { message = "Unlock the Vault first"; return }
        var tmp: File? = null
        launchTracked("Decrypting", emptyList(), measure = false, popViewer = false, background = false, onSuccess = { tmp?.let { push(Screen.Viewer(it.path)) } }) { st ->
            st.totalBytes = item.size
            st.current = item.name
            try {
                tmp = Vault.decryptToTemp(key, item, st)
            } finally {
                key.fill(0)
            }
            ""
        }
    }

    /** Decrypts items back to their original folder (or Download of the SAME storage) and removes them from the vault. */
    fun vaultRestore(list: List<VaultItem>) {
        val key = Vault.keyCopy() ?: run { message = "Unlock the Vault first"; return }
        val fake = list.map { File(it.name) }
        launchTracked("Moving out of Vault", fake, measure = false) { st ->
            st.totalBytes = list.sumOf { it.size }
            try {
                var ok = 0
                val fails = ArrayList<String>()
                for (v in list) {
                    st.checkCancel()
                    st.current = v.name
                    try {
                        val fallback = File(File(v.vol), "Download")
                        val d = if (v.dir.isEmpty()) fallback else File(v.dir)
                        val target = if (d.isDirectory || d.mkdirs()) d else fallback
                        Vault.exportFile(key, v, target, st)
                        Vault.deleteItem(key, v)
                        ok++
                    } catch (e: OpCancelled) {
                        throw e
                    } catch (e: Throwable) {
                        fails += "${v.name}: ${e.message ?: "failed"}"
                    }
                    st.doneItems++
                }
                if (fails.isNotEmpty()) throw IOException((if (ok > 0) "Restored $ok item(s). " else "") + "Failed: " + fails.joinToString("; "))
                "Restored $ok item(s)"
            } finally {
                key.fill(0)
            }
        }
    }

    fun vaultDelete(list: List<VaultItem>) {
        val key = Vault.keyCopy() ?: run { message = "Unlock the Vault first"; return }
        launchTracked("Deleting from Vault", list.map { File(it.name) }, measure = false) { st ->
            try {
                for (v in list) { st.checkCancel(); st.current = v.name; Vault.deleteItem(key, v); st.doneItems++ }
            } finally {
                key.fill(0)
            }
            "Deleted ${list.size} item(s) permanently"
        }
    }

    /** Decrypts every item without saving anything, to prove none is damaged. */
    fun vaultVerify() {
        val key = Vault.keyCopy() ?: run { message = "Unlock the Vault first"; return }
        val list = Vault.items
        launchTracked("Checking Vault integrity", list.map { File(it.name) }, measure = false) { st ->
            st.totalBytes = list.sumOf { it.size }
            try {
                val bad = ArrayList<String>()
                for (v in list) {
                    st.checkCancel()
                    st.current = v.name
                    try { Vault.verifyItem(key, v, st) } catch (e: OpCancelled) { throw e } catch (e: Throwable) { bad += "${v.name} (${e.message})" }
                    st.doneItems++
                }
                if (bad.isNotEmpty()) throw IOException("${bad.size} damaged item(s): " + bad.joinToString("; "))
                "All ${list.size} item(s) are intact"
            } finally {
                key.fill(0)
            }
        }
    }

    // ---------------- FTP ----------------
    var ftpServer by mutableStateOf<FtpServer?>(null)
    var ftpPort by mutableIntStateOf(2121)
    var ftpUser by mutableStateOf("")
    var ftpPass by mutableStateOf("")
    var ftpWrite by mutableStateOf(false)

    fun startFtpServer(ctx: Context, port: Int, user: String, pass: String, write: Boolean) {
        if (!Owner.verify(ctx)) {
            message = "This copy of the app has been modified without permission."
            return
        }
        // Without a login anybody on the same Wi-Fi could change or delete every file, and an empty password is no password.
        if (write && user.isEmpty()) {
            message = "Uploading / deleting needs a username and password"
            return
        }
        if (user.isNotEmpty() && pass.isEmpty()) {
            message = "Please enter a password"
            return
        }
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    val s = FtpServer(root, port, user, pass, !write)
                    s.start()
                    ftpServer = s
                    null
                } catch (e: Throwable) {
                    e.message ?: "Cannot start the server"
                }
            }
            if (err != null) message = err else {
                ftpPort = port
                ftpUser = user
                ftpPass = pass
                ftpWrite = write
            }
        }
    }

    fun stopFtpServer() {
        val s = ftpServer
        ftpServer = null
        viewModelScope.launch(Dispatchers.IO) { s?.stop() }
    }

    private var ftpClient: FTPClient? = null
    var ftpConnected by mutableStateOf(false)
    var ftpBusy by mutableStateOf(false)
    var ftpPath by mutableStateOf("/")
    var ftpList by mutableStateOf<List<FTPFile>>(emptyList())

    private fun ftpRefreshList(c: FTPClient) {
        ftpPath = c.printWorkingDirectory() ?: "/"
        ftpList = c.listFiles().toList()
            .filter { it.name != "." && it.name != ".." }
            .sortedWith(compareBy<FTPFile> { !it.isDirectory }.thenBy { it.name.lowercase() })
    }

    fun ftpConnect(host: String, port: Int, user: String, pass: String) {
        ftpBusy = true
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                val c = FTPClient()
                try {
                    c.controlEncoding = "UTF-8"
                    c.connectTimeout = 10000
                    c.defaultTimeout = 20000
                    c.connect(host, port)
                    if (!c.login(user, pass)) throw IOException("Login failed")
                    c.enterLocalPassiveMode()
                    c.setFileType(FTP.BINARY_FILE_TYPE)
                    ftpClient = c
                    ftpRefreshList(c)
                    null
                } catch (e: Throwable) {
                    ftpClient = null
                    try { c.disconnect() } catch (x: Exception) { }   // no leaked socket after a failed connect / login
                    e.message ?: "Connection failed"
                }
            }
            if (err != null) message = err else ftpConnected = true
            ftpBusy = false
        }
    }

    private fun ftpRun(onDone: () -> Unit = {}, work: (FTPClient) -> Unit) {
        val c = ftpClient ?: return
        ftpBusy = true
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    synchronized(c) { work(c) }
                    null
                } catch (e: Throwable) {
                    e.message ?: "FTP error"
                }
            }
            if (err != null) message = err else onDone()
            ftpBusy = false
        }
    }

    fun ftpOpenDir(name: String) = ftpRun {
        if (it.changeWorkingDirectory(name)) ftpRefreshList(it) else throw IOException("Cannot open the folder")
    }

    fun ftpUp() = ftpRun {
        it.changeToParentDirectory()
        ftpRefreshList(it)
    }

    /** A file name that came from a remote server: only the last part is ever used, so "../" can't escape the folder. */
    private fun safeRemoteName(name: String): String {
        val n = name.substringAfterLast('/').substringAfterLast('\\').trim()
        return if (n.isEmpty() || n == "." || n == "..") "download" else n
    }

    fun ftpDownload(name: String) {
        var saved = ""
        ftpRun(onDone = { message = "Downloaded to Download/$saved"; refresh() }) { c ->
            val dir = File(internalRoot, "Download")
            dir.mkdirs()
            val dest = uniqueFile(dir, safeRemoteName(name))
            try {
                FileOutputStream(dest).use { if (!c.retrieveFile(name, it)) throw IOException("Download failed") }
            } catch (e: Throwable) {
                dest.delete()   // never leave a half-downloaded file behind
                throw e
            }
            saved = dest.name
        }
    }

    fun ftpOpenFile(name: String) {
        var opened: File? = null
        ftpRun(onDone = { opened?.let { push(Screen.Viewer(it.path)) } }) { c ->
            val dir = File(getApplication<Application>().cacheDir, "ftp")
            dir.mkdirs()
            val dest = File(dir, safeRemoteName(name))
            dest.delete()
            try {
                FileOutputStream(dest).use { if (!c.retrieveFile(name, it)) throw IOException("Download failed") }
            } catch (e: Throwable) {
                dest.delete()
                throw e
            }
            opened = dest
        }
    }

    fun ftpDisconnect() {
        val c = ftpClient
        ftpClient = null
        ftpConnected = false
        ftpList = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                c?.logout()
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    init {
        Ops.init(getApplication())
        Ops.activeVm = this
        // a transfer that the phone killed half way leaves temp files behind: remove them (never while one is running)
        if (Ops.state == null) viewModelScope.launch(Dispatchers.IO) { Ops.cleanLeftovers() }
    }

    override fun onCleared() {
        if (Ops.activeVm === this) Ops.activeVm = null   // running transfers go on without a screen
        screenOp?.let { if (Ops.state === it) Ops.state = null }   // ... but a screen-bound one must not stay "running" forever
        try { ftpServer?.stop() } catch (e: Exception) { }
        try { ftpClient?.disconnect() } catch (e: Exception) { }
        super.onCleared()
    }
}
