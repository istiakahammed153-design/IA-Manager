/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.app.Activity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay

private const val SPLASH_MIN_MS = 800L    // long enough to see the animation, never a blink
private const val SPLASH_MAX_MS = 3000L   // a huge storage must not keep the screen covered: Home shows the last known sizes
private val SplashTop = Color(0xFF0B2A5B)
private val SplashBottom = Color(0xFF14408F)
private val SplashAccent = Color(0xFF1DB9A6)

/**
 * Animated start-up screen. It covers the app while the first screen is being prepared (the storage is scanned in the
 * background), then fades and zooms away. It plays once per app start - a screen rotation does not replay it.
 */
@Composable
fun StartupSplash(vm: AppViewModel) {
    if (vm.splashDone) return
    val ctx = LocalContext.current
    val view = LocalView.current
    val surface = MaterialTheme.colorScheme.surface
    val surfaceArgb = surface.toArgb()
    val lightBars = surface.luminance() > 0.5f

    // Full-screen look: the status bar and navigation bar wear the splash colours, then go back to normal.
    val window = (view.context as? Activity)?.window
    DisposableEffect(window) {
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            window.statusBarColor = SplashTop.toArgb()
            window.navigationBarColor = SplashBottom.toArgb()
            c.isAppearanceLightStatusBars = false
            c.isAppearanceLightNavigationBars = false
        }
        onDispose {
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                window.statusBarColor = surfaceArgb
                window.navigationBarColor = surfaceArgb
                c.isAppearanceLightStatusBars = lightBars
                c.isAppearanceLightNavigationBars = lightBars
            }
        }
    }

    val intro = remember { Animatable(0f) }   // 0 -> 1: logo and texts appear
    val leave = remember { Animatable(0f) }   // 0 -> 1: the splash fades away
    LaunchedEffect(Unit) { intro.animateTo(1f, tween(650, easing = FastOutSlowInEasing)) }
    LaunchedEffect(Unit) {
        val t0 = System.currentTimeMillis()
        while (true) {
            val elapsed = System.currentTimeMillis() - t0
            val waitForScan = hasAccess(ctx)   // without file access there is nothing to scan: go straight to the permission screen
            if (elapsed >= SPLASH_MAX_MS || (elapsed >= SPLASH_MIN_MS && (!waitForScan || !vm.scanning))) break
            delay(40)
        }
        leave.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        vm.splashDone = true
    }

    val inf = rememberInfiniteTransition(label = "splash")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(
        0.94f, 1.06f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                val l = leave.value
                alpha = 1f - l
                scaleX = 1f + 0.08f * l
                scaleY = 1f + 0.08f * l
            }
            .background(Brush.verticalGradient(listOf(SplashTop, SplashBottom)))
            .pointerInput(Unit) { detectTapGestures { } },   // swallow taps: the screen below is not usable yet
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(140.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 5.dp.toPx()
                    val inset = stroke / 2f
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawCircle(
                        Color.White.copy(alpha = 0.10f),
                        radius = (size.minDimension - stroke) / 2f,
                        style = Stroke(stroke)
                    )
                    rotate(spin) {
                        drawArc(
                            SplashAccent, 0f, 100f, false, Offset(inset, inset), arcSize,
                            style = Stroke(stroke, cap = StrokeCap.Round)
                        )
                        drawArc(
                            SplashAccent.copy(alpha = 0.35f), 180f, 40f, false, Offset(inset, inset), arcSize,
                            style = Stroke(stroke, cap = StrokeCap.Round)
                        )
                    }
                }
                Box(
                    Modifier.size(88.dp)
                        .graphicsLayer {
                            val s = intro.value * pulse
                            scaleX = s
                            scaleY = s
                            alpha = intro.value
                        }
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color.White.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Outlined.Folder, null, tint = FolderYellow, modifier = Modifier.size(54.dp)) }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "IA Manager", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.graphicsLayer {
                    alpha = intro.value
                    translationY = (1f - intro.value) * 28.dp.toPx()
                }
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Manage your files, easily", color = Color(0xFFB8C7E6), fontSize = 14.sp,
                modifier = Modifier.graphicsLayer { alpha = intro.value }
            )
            Spacer(Modifier.height(36.dp))
            LoadingDots()
        }
        Text(
            "\u00A9 ${Owner.YEAR} ${Owner.name}", color = Color(0x99B8C7E6), fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp)
        )
    }
}

/** Three dots that pulse one after the other. */
@Composable
private fun LoadingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until 3) {
            val a by t.animateFloat(
                0.25f, 1f,
                infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset(i * 170)),
                label = "dot$i"
            )
            Box(
                Modifier.size(9.dp)
                    .graphicsLayer {
                        alpha = a
                        val s = 0.7f + 0.3f * a
                        scaleX = s
                        scaleY = s
                    }
                    .background(Color.White, CircleShape)
            )
        }
    }
}
