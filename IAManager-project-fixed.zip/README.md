# IA Manager

Android file manager. Copyright (c) 2026 Istiak Ahammed. All rights reserved. (see LICENSE)

## APK তৈরি (GitHub Actions)
1. এই zip ফাইলটি GitHub repo-র root-এ আপলোড করুন (repo **private** রাখুন)।
2. `.github/workflows/build.yml` ফাইলটি repo-তে রাখুন।
3. Actions ট্যাবে "Build APK" চলবে → শেষে **Artifacts → IAManager-apk** নামিয়ে ইন্সটল করুন।
4. প্রথমবার অ্যাপ খুললে "All files access" পারমিশন দিন।
