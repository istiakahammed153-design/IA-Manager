# IA Manager

Android file manager. Copyright (c) 2026 Istiak Ahammed. All rights reserved. (see LICENSE)

## APK তৈরি (GitHub Actions)
1. এই zip ফাইলটি GitHub repo-র root-এ আপলোড করুন (repo **private** রাখুন)।
2. `.github/workflows/build.yml` ফাইলটি repo-তে রাখুন।
3. Actions ট্যাবে "Build APK" চলবে → শেষে **Artifacts → IAManager-apk** নামিয়ে ইন্সটল করুন।
4. প্রথমবার অ্যাপ খুললে "All files access" পারমিশন দিন।

## Vault (security notes)
- AES-256-GCM, 1 MiB chunks, a fresh key per file. Name, folder, size and date are inside the encrypted data.
- Password -> scrypt (N=32768, r=8, p=1, 32 MB per guess; verified against the RFC 7914 vector by a built-in self-test) -> wraps a random master key.
- One-time recovery key (160 bits) wraps the same master key, so a forgotten password is recoverable (keep it on paper).
- Each storage (internal / SD card) has its own `.IAVault` folder with its own encrypted index and a copy of the small header.
  SD-card data is encrypted, viewed (temp copy in the SD card's own app cache) and restored on the SD card, never using internal storage.
- Adding: encrypt -> decrypt again and compare SHA-256 -> only then overwrite + delete the original. Folders keep their structure.
- Wrong passwords are throttled; the vault auto-locks; screenshots are blocked inside it; "Check vault integrity" decrypts everything.
