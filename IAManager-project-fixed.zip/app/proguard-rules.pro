# Copyright (c) 2026 Istiak Ahammed. All rights reserved.
-ignorewarnings
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
-dontwarn org.apache.**
-dontwarn javax.**
-dontwarn java.awt.**
-keep class com.tom_roush.** { *; }
-keep class org.apache.commons.net.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
