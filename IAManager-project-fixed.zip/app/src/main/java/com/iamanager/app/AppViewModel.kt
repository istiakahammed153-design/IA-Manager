/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
package com.iamanager.app

import android.app.Application
import android.content.Context
import android.os.Environment
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("ia_prefs", Context.MODE_PRIVATE)
    private fun readLines(k: String): List<String> =
        (sp.getString(k, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeLines(k: String, v: List<String>) {
        sp.edit().putString(k, v.joinToString("\n")).apply()
    }

    val internalRoot: File = Environment.getExternalStorageDirectory()
    val trashDir: File = File(internalRoot, ".IATrash")

    // storages (internal + SD card / USB)
    var root by mutableStateOf(internalRoot)
    var storages by mutableStateOf(listOf(StorageVol("Internal Storage", internalRoot)))
    var showStoragePicker by mutableStateOf(false)
    val rootName: String get() = storages.firstOrNull { it.root.path == root.path }?.name ?: "Internal Storage"

    fun updateStorages(ctx: Context) {
        val list = detectStorages(ctx)
        storages = list
        if (list.none { it.root.path == root.path }) {
            root = internalRoot
            goTab(Screen.Home)
            scan()
        }
    }

    fun selectStorage(v: StorageVol) {
        root = v.root
        val cached = scanCache[v.root.path + showHidden]
        allFiles = cached?.files ?: emptyList()
        allDirs = cached?.dirs ?: emptyList()
        catSizes = cached?.sizes ?: emptyMap()
        allMtimes = cached?.mtimes ?: emptyMap()
        goTab(Screen.Home)
        scan()
    }

    // ---- scroll positions & list caches (survive leaving and re-entering a screen) ----
    private val listStates = HashMap<String, LazyListState>()
    private val gridStates = HashMap<String, LazyGridState>()
    private val scrollStates = HashMap<String, ScrollState>()
    fun listState(k: String): LazyListState = listStates.getOrPut(k) { LazyListState() }
    fun gridState(k: String): LazyGridState = gridStates.getOrPut(k) { LazyGridState() }
    fun scrollState(k: String): ScrollState = scrollStates.getOrPut(k) { ScrollState(0) }

    private fun forgetScroll(s: Screen) {
        val p = s.toString() + "|"
        listStates.keys.removeAll { it.startsWith(p) }
        gridStates.keys.removeAll { it.startsWith(p) }
        scrollStates.keys.removeAll { it.startsWith(p) }
    }

    private fun <V> lru(max: Int) = object : LinkedHashMap<String, V>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, V>?) = size > max
    }

    /** Last known folder listing / category listing, shown instantly while a fresh one loads in the background. */
    val dirCache: MutableMap<String, List<File>> = lru(40)
    val catCache: MutableMap<String, List<File>> = lru(40)

    // navigation
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()
    var selected by mutableStateOf<Set<String>>(emptySet())

    // settings
    var theme by mutableIntStateOf(sp.getInt("theme", 0))
    var showHidden by mutableStateOf(sp.getBoolean("hidden", false))
    var gridView by mutableStateOf(sp.getBoolean("grid", false))
    var sortBy by mutableIntStateOf(sp.getInt("sort", 0))

    private val gridMap = mutableStateMapOf<String, Boolean>()
    fun isGrid(c: Cat): Boolean =
        gridMap[c.name] ?: sp.getBoolean("grid_" + c.name, c == Cat.IMAGES || c == Cat.VIDEOS)

    fun setCatGrid(c: Cat, v: Boolean) {
        gridMap[c.name] = v
        sp.edit().putBoolean("grid_" + c.name, v).apply()
    }

    // persisted lists
    var starred by mutableStateOf(readLines("starred"))
    var recent by mutableStateOf(readLines("recent"))
    var shared by mutableStateOf(readLines("shared"))
    var trash by mutableStateOf(readLines("trash"))
    var searches by mutableStateOf(readLines("searches"))

    // scan results
    var allFiles by mutableStateOf<List<File>>(emptyList())
    var allDirs by mutableStateOf<List<File>>(emptyList())
    var catSizes by mutableStateOf<Map<Cat, Long>>(emptyMap())
    var allMtimes by mutableStateOf<Map<String, Long>>(emptyMap())
    var scanning by mutableStateOf(false)
    var tick by mutableIntStateOf(0)

    // ui state
    var message by mutableStateOf<String?>(null)
    var pickerMove by mutableStateOf<Boolean?>(null)
    var confirmDelete by mutableStateOf(false)
    var renameTarget by mutableStateOf<String?>(null)

    fun changeTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun setGrid(v: Boolean) { gridView = v; sp.edit().putBoolean("grid", v).apply() }
    fun setSort(v: Int) { sortBy = v; sp.edit().putInt("sort", v).apply() }
    fun setHidden(v: Boolean) { showHidden = v; sp.edit().putBoolean("hidden", v).apply(); refresh() }

    // ---- navigation ----
    fun push(s: Screen) { selected = emptySet(); stack.add(s) }
    fun pop() {
        selected = emptySet()
        if (stack.size > 1) forgetScroll(stack.removeAt(stack.lastIndex))
    }
    fun goTab(s: Screen) {
        selected = emptySet()
        stack.drop(1).forEach { forgetScroll(it) }
        stack.clear()
        if (s != Screen.Home) stack.add(Screen.Home)
        stack.add(s)
    }

    fun toggleSelect(p: String) { selected = if (p in selected) selected - p else selected + p }

    fun dismissDialogs() {
        pickerMove = null
        confirmDelete = false
        renameTarget = null
        if (current is Screen.Details || current is Screen.Viewer) selected = emptySet()
    }

    // ---- scanning ----
    fun refresh() { tick++; scan() }

    private val scanCache = java.util.concurrent.ConcurrentHashMap<String, ScanResult>()

    private var rescanQueued = false
    private var lastScan = 0L

    fun scan() {
        // one scan at a time; if something changed meanwhile, scan again right after
        if (scanning) { rescanQueued = true; return }
        val r = root
        val hidden = showHidden
        scanning = true
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                try {
                    scanRoot(r, hidden)
                } catch (e: Exception) {
                    ScanResult(emptyList(), emptyList(), emptyMap())
                }
            }
            scanCache[r.path + hidden] = res
            if (r == root && hidden == showHidden) {
                allFiles = res.files
                allDirs = res.dirs
                catSizes = res.sizes
                allMtimes = res.mtimes
            }
            lastScan = System.currentTimeMillis()
            scanning = false
            if (rescanQueued || r != root || hidden != showHidden) {
                rescanQueued = false
                scan()
            }
        }
    }

    // ---- live updates: files added/removed by other apps show up without a manual refresh ----
    private var changeJob: Job? = null

    /** Called by the folder watcher / media observer. Debounced so bursts of events cause only one refresh. */
    fun dirChanged() {
        changeJob?.cancel()
        changeJob = viewModelScope.launch {
            delay(300)
            tick++
            delay(1200)
            scan()
        }
    }

    /** App came back to the foreground (e.g. after opening a file in another app or downloading something). */
    fun onResume(ctx: Context) {
        updateStorages(ctx)
        tick++
        if (System.currentTimeMillis() - lastScan > 3000) scan()
    }

    // ---- recents / stars / shares ----
    fun toggleStar(p: String) {
        starred = if (p in starred) starred - p else starred + p
        writeLines("starred", starred)
    }

    fun starSelected() {
        val all = selected.all { it in starred }
        starred = if (all) starred - selected else (starred + selected).distinct()
        writeLines("starred", starred)
        selected = emptySet()
    }

    fun addRecent(p: String) {
        recent = (listOf(p) + recent.filter { it != p }).take(50)
        writeLines("recent", recent)
    }

    fun addSearch(q: String) {
        if (q.isBlank()) return
        searches = (listOf(q.trim()) + searches.filter { it != q.trim() }).take(8)
        writeLines("searches", searches)
    }

    fun clearSearches() { searches = emptyList(); writeLines("searches", searches) }

    fun open(ctx: Context, f: File) {
        if (f.isDirectory) push(Screen.Files(f.path)) else {
            addRecent(f.path)
            push(Screen.Viewer(f.path))
        }
    }

    fun share(ctx: Context, files: List<File>) {
        shareFiles(ctx, files)
        shared = (files.filter { it.isFile }.map { it.path } + shared).distinct().take(100)
        writeLines("shared", shared)
        selected = emptySet()
    }

    // ---- file operations ----
    private fun launchOp(okMsg: String, popViewer: Boolean = true, work: () -> Unit) {
        launchCore(popViewer) { work(); okMsg }
    }

    private fun launchCore(popViewer: Boolean, work: () -> String) {
        viewModelScope.launch {
            var err: String? = null
            var msg = ""
            withContext(Dispatchers.IO) {
                try {
                    msg = work()
                } catch (e: Throwable) {
                    err = e.message ?: "Operation failed"
                }
            }
            val failed = err
            message = failed ?: msg
            selected = emptySet()
            refresh()
            if (failed == null) {
                while (current is Screen.Create || current is Screen.Pick) pop()
                if (popViewer && (current is Screen.Details || current is Screen.Viewer)) pop()
            }
        }
    }

    fun convert(kind: Conv, files: List<File>, dir: File, option: String = "") {
        val ctx = getApplication<Application>()
        launchCore(false) { doConvert(ctx, kind, files, dir, option) }
    }

    fun copyMove(dest: File, move: Boolean) {
        val files = selected.map { File(it) }
        launchOp((if (move) "Moved " else "Copied ") + files.size + " item(s)") {
            files.forEach { if (move) moveItem(it, dest) else copyItem(it, dest) }
        }
    }

    fun deleteSelected() {
        val files = selected.map { File(it) }
        launchOp("Moved ${files.size} item(s) to Recycle Bin") {
            val entries = files.map { moveToTrash(it, trashDir) }
            trash = trash + entries
            writeLines("trash", trash)
        }
    }

    fun rename(path: String, newName: String) {
        launchOp("Renamed") {
            val f = File(path)
            val t = File(f.parentFile, newName)
            if (newName.isBlank() || newName.contains("/")) throw IOException("Invalid name")
            if (t.exists()) throw IOException("A file with that name already exists")
            if (!f.renameTo(t)) throw IOException("Rename failed")
        }
    }

    fun createItem(dir: String, kind: String, ext: String, name: String) {
        launchOp("Created") {
            val clean = name.trim().ifEmpty { "New" }
            val full = if (ext.isNotEmpty() && !clean.endsWith(".$ext", true)) "$clean.$ext" else clean
            createNewItem(uniqueFile(File(dir), full), kind)
        }
    }

    fun compress() {
        val files = selected.map { File(it) }
        if (files.isEmpty()) return
        launchOp("Compressed to ZIP") {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val parent = files[0].parentFile ?: root
            zipFiles(files, uniqueFile(parent, "Archive_$stamp.zip"))
        }
    }

    fun extract(path: String, stay: Boolean = false) {
        val z = File(path)
        launchOp("Extracted", !stay) {
            unzip(z, uniqueFile(z.parentFile ?: root, z.nameWithoutExtension))
        }
    }

    fun restore(entry: String) {
        launchOp("Restored") {
            val src = File(trashDir, entry.substringBefore('\t'))
            val orig = File(entry.substringAfter('\t'))
            val parent = orig.parentFile ?: root
            parent.mkdirs()
            val dest = uniqueFile(parent, orig.name)
            if (!src.renameTo(dest)) {
                if (src.isDirectory) src.copyRecursively(dest) else src.copyTo(dest)
                src.deleteRecursively()
            }
            trash = trash - entry
            writeLines("trash", trash)
        }
    }

    fun deleteForever(entry: String) {
        launchOp("Deleted permanently") {
            File(trashDir, entry.substringBefore('\t')).deleteRecursively()
            trash = trash - entry
            writeLines("trash", trash)
        }
    }

    fun emptyTrash() {
        launchOp("Recycle Bin emptied") {
            trashDir.listFiles()?.forEach { it.deleteRecursively() }
            trash = emptyList()
            writeLines("trash", trash)
        }
    }

    // ---------------- FTP ----------------
    var ftpServer by mutableStateOf<FtpServer?>(null)
    var ftpPort by mutableIntStateOf(2121)
    var ftpUser by mutableStateOf("")
    var ftpPass by mutableStateOf("")
    var ftpWrite by mutableStateOf(false)

    fun startFtpServer(ctx: Context, port: Int, user: String, pass: String, write: Boolean) {
        if (!Owner.verify(ctx)) {
            message = "This copy of the app has been modified without permission."
            return
        }
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    val s = FtpServer(root, port, user, pass, !write)
                    s.start()
                    ftpServer = s
                    null
                } catch (e: Throwable) {
                    e.message ?: "Cannot start the server"
                }
            }
            if (err != null) message = err else {
                ftpPort = port
                ftpUser = user
                ftpPass = pass
                ftpWrite = write
            }
        }
    }

    fun stopFtpServer() {
        val s = ftpServer
        ftpServer = null
        viewModelScope.launch(Dispatchers.IO) { s?.stop() }
    }

    private var ftpClient: FTPClient? = null
    var ftpConnected by mutableStateOf(false)
    var ftpBusy by mutableStateOf(false)
    var ftpPath by mutableStateOf("/")
    var ftpList by mutableStateOf<List<FTPFile>>(emptyList())

    private fun ftpRefreshList(c: FTPClient) {
        ftpPath = c.printWorkingDirectory() ?: "/"
        ftpList = c.listFiles().toList()
            .filter { it.name != "." && it.name != ".." }
            .sortedWith(compareBy<FTPFile> { !it.isDirectory }.thenBy { it.name.lowercase() })
    }

    fun ftpConnect(host: String, port: Int, user: String, pass: String) {
        ftpBusy = true
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    val c = FTPClient()
                    c.controlEncoding = "UTF-8"
                    c.connectTimeout = 10000
                    c.defaultTimeout = 20000
                    c.connect(host, port)
                    if (!c.login(user, pass)) {
                        c.disconnect()
                        throw IOException("Login failed")
                    }
                    c.enterLocalPassiveMode()
                    c.setFileType(FTP.BINARY_FILE_TYPE)
                    ftpClient = c
                    ftpRefreshList(c)
                    null
                } catch (e: Throwable) {
                    e.message ?: "Connection failed"
                }
            }
            if (err != null) message = err else ftpConnected = true
            ftpBusy = false
        }
    }

    private fun ftpRun(onDone: () -> Unit = {}, work: (FTPClient) -> Unit) {
        val c = ftpClient ?: return
        ftpBusy = true
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    synchronized(c) { work(c) }
                    null
                } catch (e: Throwable) {
                    e.message ?: "FTP error"
                }
            }
            if (err != null) message = err else onDone()
            ftpBusy = false
        }
    }

    fun ftpOpenDir(name: String) = ftpRun {
        if (it.changeWorkingDirectory(name)) ftpRefreshList(it) else throw IOException("Cannot open the folder")
    }

    fun ftpUp() = ftpRun {
        it.changeToParentDirectory()
        ftpRefreshList(it)
    }

    fun ftpDownload(name: String) {
        var saved = ""
        ftpRun(onDone = { message = "Downloaded to Download/$saved"; refresh() }) { c ->
            val dir = File(internalRoot, "Download")
            dir.mkdirs()
            val dest = uniqueFile(dir, name)
            FileOutputStream(dest).use { if (!c.retrieveFile(name, it)) throw IOException("Download failed") }
            saved = dest.name
        }
    }

    fun ftpOpenFile(name: String) {
        var opened: File? = null
        ftpRun(onDone = { opened?.let { push(Screen.Viewer(it.path)) } }) { c ->
            val dir = File(getApplication<Application>().cacheDir, "ftp")
            dir.mkdirs()
            val dest = File(dir, name)
            dest.delete()
            FileOutputStream(dest).use { if (!c.retrieveFile(name, it)) throw IOException("Download failed") }
            opened = dest
        }
    }

    fun ftpDisconnect() {
        val c = ftpClient
        ftpClient = null
        ftpConnected = false
        ftpList = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                c?.logout()
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    override fun onCleared() {
        try { ftpServer?.stop() } catch (e: Exception) { }
        try { ftpClient?.disconnect() } catch (e: Exception) { }
        super.onCleared()
    }
}
