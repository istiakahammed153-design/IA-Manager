/*
 * Copyright (c) 2026 Istiak Ahammed. All rights reserved.
 *
 * IA Manager - source code. This file is proprietary. It may not be copied, modified,
 * published, redistributed, rebranded or claimed as the work of anyone other than
 * Istiak Ahammed without his prior written permission. See the LICENSE file.
 */
@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.iamanager.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---------------- HOME ----------------
@Composable
fun RowScope.CatTile(cat: Cat, icon: ImageVector, size: Long, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(catColor(cat)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(cat.title, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(fmtSize(size), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SectionTitle(title: String, action: String, onAction: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
fun HomeScreen(vm: AppViewModel, openDrawer: () -> Unit) {
    val cardColors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    Column(Modifier.fillMaxSize().verticalScroll(vm.scrollState("home|scroll"))) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFF0B2A5B), Color(0xFF14408F))))
                .padding(start = 8.dp, end = 16.dp, top = 8.dp, bottom = 16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = openDrawer) { Icon(Icons.Outlined.Menu, "Menu", tint = Color.White) }
                    Column(Modifier.weight(1f)) {
                        Text("IA Manager", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("Manage your files, easily", color = Color(0xFFB8C7E6), fontSize = 13.sp)
                    }
                    IconButton(onClick = { vm.push(Screen.Search) }) { Icon(Icons.Outlined.Search, "Search", tint = Color.White) }
                }
                Spacer(Modifier.height(12.dp))
                StorageCard(
                    vm,
                    onClick = { if (vm.storages.size > 1) vm.showStoragePicker = true else vm.push(Screen.Files(vm.root.path)) },
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp)) {
            CatTile(Cat.IMAGES, Icons.Outlined.Image, vm.catSizes[Cat.IMAGES] ?: 0L) { vm.push(Screen.Category(Cat.IMAGES)) }
            CatTile(Cat.VIDEOS, Icons.Outlined.Videocam, vm.catSizes[Cat.VIDEOS] ?: 0L) { vm.push(Screen.Category(Cat.VIDEOS)) }
            CatTile(Cat.AUDIO, Icons.Outlined.MusicNote, vm.catSizes[Cat.AUDIO] ?: 0L) { vm.push(Screen.Category(Cat.AUDIO)) }
            CatTile(Cat.DOCS, Icons.Outlined.Description, vm.catSizes[Cat.DOCS] ?: 0L) { vm.push(Screen.Category(Cat.DOCS)) }
        }
        SectionTitle("Quick Access", "See All") { vm.push(Screen.Recent) }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(16.dp), colors = cardColors) {
            ActionRow(Icons.Outlined.History, Color(0xFF7C4DFF), "Recent Files", "Files you've opened") { vm.push(Screen.Recent) }
            ActionRow(Icons.Outlined.Star, Color(0xFFFFA000), "Starred", "Important files") { vm.push(Screen.Starred) }
            ActionRow(Icons.Outlined.People, Color(0xFF1A73E8), "Shared", "Files shared with others") { vm.push(Screen.Shared) }
            ActionRow(Icons.Outlined.DeleteOutline, Color(0xFF1E8E3E), "Recycle Bin", "Deleted files") { vm.push(Screen.Trash) }
            ActionRow(Icons.Outlined.Lock, Color(0xFF455A64), "Vault", "Password-encrypted private files") { vm.push(Screen.Vault) }
            ActionRow(Icons.Outlined.Cloud, Color(0xFF00897B), "FTP", "Share files over Wi-Fi or connect to a server") { vm.push(Screen.Ftp) }
        }
        SectionTitle("Common Folders", "See All") { vm.push(Screen.Files(vm.root.path)) }
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), shape = RoundedCornerShape(16.dp), colors = cardColors) {
            ActionRow(Icons.Outlined.Folder, FolderYellow, "DCIM", "Camera photos & videos") {
                vm.push(Screen.Files(File(vm.root, "DCIM").path))
            }
            ActionRow(Icons.Outlined.Folder, FolderYellow, "Download", "Downloaded files") {
                vm.push(Screen.Files(File(vm.root, "Download").path))
            }
            ActionRow(Icons.Outlined.Folder, FolderYellow, "Documents", "Documents & PDFs") {
                vm.push(Screen.Files(File(vm.root, "Documents").path))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ---------------- FILE BROWSER ----------------
@Composable
fun ViewMenu(vm: AppViewModel, expanded: Boolean, onDismiss: () -> Unit) {
    DropdownMenu(expanded, onDismiss) {
        val names = listOf("Name", "Date", "Size")
        names.forEachIndexed { i, n ->
            DropdownMenuItem(
                text = { Text("Sort by $n" + if (vm.sortBy == i) "  \u2713" else "") },
                onClick = { vm.setSort(i); onDismiss() }
            )
        }
        DropdownMenuItem(
            text = { Text(if (vm.gridView) "List view" else "Grid view") },
            onClick = { vm.setGrid(!vm.gridView); onDismiss() }
        )
        DropdownMenuItem(
            text = { Text("Show hidden files" + if (vm.showHidden) "  \u2713" else "") },
            onClick = { vm.setHidden(!vm.showHidden); onDismiss() }
        )
        val ctx = androidx.compose.ui.platform.LocalContext.current
        DropdownMenuItem(text = { Text("Refresh") }, onClick = { vm.updateStorages(ctx); vm.refresh(); onDismiss() })
    }
}

val FilterLabels = listOf("All", "Images", "Videos", "Audio", "Documents", "Archives")

@Composable
fun FilesScreen(vm: AppViewModel, path: String, openDrawer: () -> Unit) {
    val ctx = LocalContext.current
    val dir = File(path)
    val isRoot = dir == vm.root
    val cacheKey = path + "|" + vm.showHidden + "|" + vm.sortBy
    // Starts from the last known listing (no spinner, no jump to top) and refreshes quietly in the background.
    val loaded by produceState<List<File>?>(vm.dirCache[cacheKey], cacheKey, vm.tick) {
        val fresh = withContext(Dispatchers.IO) { listDir(dir, vm.showHidden, vm.sortBy) }
        vm.dirCache[cacheKey] = fresh
        value = fresh
    }
    // Watch this folder: files added / deleted / renamed by any app appear immediately.
    DisposableEffect(path) {
        @Suppress("DEPRECATION")
        val obs = object : android.os.FileObserver(
            path,
            android.os.FileObserver.CREATE or android.os.FileObserver.DELETE or android.os.FileObserver.MOVED_FROM or
                android.os.FileObserver.MOVED_TO or android.os.FileObserver.CLOSE_WRITE or
                android.os.FileObserver.DELETE_SELF or android.os.FileObserver.MOVE_SELF
        ) {
            override fun onEvent(event: Int, p: String?) { vm.dirChanged() }
        }
        try { obs.startWatching() } catch (e: Exception) { }
        onDispose { try { obs.stopWatching() } catch (e: Exception) { } }
    }
    val files = loaded ?: emptyList()
    var menu by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (vm.selected.isNotEmpty()) {
                SelectionTop(vm, files)
            } else {
                TopAppBar(
                    title = { Text(if (isRoot) "Files" else dir.name, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    navigationIcon = {
                        IconButton(onClick = { if (isRoot) openDrawer() else vm.pop() }) {
                            Icon(if (isRoot) Icons.Outlined.Menu else Icons.Outlined.ArrowBack, null)
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.push(Screen.Search) }) { Icon(Icons.Outlined.Search, "Search") }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "More") }
                            ViewMenu(vm, menu) { menu = false }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            }
            ChipsRow(FilterLabels, 0) { i -> if (i > 0) vm.push(Screen.Category(Cat.values()[i - 1])) }
            if (loaded == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else FileCollection(
                files, vm, vm.gridView, onOpen = { vm.open(ctx, it) }, emptyText = "This folder is empty"
            ) {
                if (isRoot) {
                    StorageCard(
                        vm,
                        onClick = { if (vm.storages.size > 1) vm.showStoragePicker = true },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                } else {
                    Text(
                        relPath(vm.root, vm.rootName, dir), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
        }
        if (vm.selected.isEmpty()) {
            FloatingActionButton(
                onClick = { vm.push(Screen.Create(path)) },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Outlined.Add, "Create", tint = Color.White) }
        }
    }
}

// ---------------- CATEGORY / GRID ----------------
@Composable
fun CategoryScreen(vm: AppViewModel, cat: Cat, pickEdit: Boolean) {
    val ctx = LocalContext.current
    var sub by remember { mutableIntStateOf(0) }
    val labels = if (cat == Cat.IMAGES) listOf("All", "Camera", "Screenshots", "Pictures") else listOf("All")
    val catKey = vm.root.path + "|" + cat.name + "|" + sub + "|" + vm.showHidden
    val items by produceState(vm.catCache[catKey] ?: emptyList<File>(), vm.allFiles, cat, sub) {
        val all = vm.allFiles
        val mt = vm.allMtimes
        value = withContext(Dispatchers.Default) {
            all.filter { it.cat() == cat }
                .filter {
                    when (sub) {
                        1 -> it.path.contains("/Camera/", true)
                        2 -> it.path.contains("Screenshots", true)
                        3 -> it.path.contains("/Pictures/", true)
                        else -> true
                    }
                }
                .sortedByDescending { mt[it.path] ?: 0L }
        }
        vm.catCache[catKey] = value
    }
    val grid = vm.isGrid(cat)
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (vm.selected.isNotEmpty()) {
                SelectionTop(vm, items)
            } else {
                SimpleTop(if (pickEdit) "Choose a photo to edit" else cat.title, onBack = { vm.pop() }) {
                    IconButton(onClick = { vm.setCatGrid(cat, !grid) }) {
                        Icon(if (grid) Icons.Outlined.ViewList else Icons.Outlined.GridView, if (grid) "List view" else "Grid view")
                    }
                    IconButton(onClick = { vm.push(Screen.Search) }) { Icon(Icons.Outlined.Search, "Search") }
                }
            }
            if (labels.size > 1) ChipsRow(labels, sub) { sub = it }
            if (vm.scanning && items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                FileCollection(
                    items, vm, grid,
                    onOpen = { f ->
                        when {
                            pickEdit -> vm.push(Screen.Editor(f.path))
                            else -> vm.open(ctx, f)
                        }
                    },
                    emptyText = "No ${cat.title.lowercase()} found",
                    stateKey = vm.current.toString() + "|" + sub
                )
            }
        }
        if (vm.selected.isEmpty() && !pickEdit) {
            FloatingActionButton(
                onClick = { vm.push(Screen.Create(vm.root.path)) },
                containerColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
            ) { Icon(Icons.Outlined.Add, "Create", tint = Color.White) }
        }
    }
}

// ---------------- SEARCH ----------------
@Composable
fun SearchScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var chip by remember { mutableIntStateOf(0) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    val results by produceState(emptyList<File>(), q, chip, vm.allFiles, vm.allDirs) {
        if (q.isBlank()) { value = emptyList(); return@produceState }
        val n = q.trim().lowercase()
        val files = vm.allFiles
        val dirs = vm.allDirs
        value = withContext(Dispatchers.Default) {
            val base: List<File> = if (chip == 0) dirs + files else {
                val c = Cat.values()[chip - 1]
                files.filter { it.cat() == c }
            }
            base.filter { it.name.lowercase().contains(n) }.take(300).also { r -> r.forEach { metaOf(it) } }
        }
    }
    Column(Modifier.fillMaxSize()) {
        if (vm.selected.isNotEmpty()) {
            SelectionTop(vm, results)
        } else {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { vm.pop() }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                TextField(
                    value = q, onValueChange = { q = it },
                    modifier = Modifier.weight(1f).focusRequester(focus).padding(end = 12.dp),
                    placeholder = { Text("Search files...") },
                    singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    leadingIcon = { Icon(Icons.Outlined.Search, null) },
                    trailingIcon = {
                        if (q.isNotEmpty()) IconButton(onClick = { q = "" }) { Icon(Icons.Outlined.Close, "Clear") }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.addSearch(q) }),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                )
            }
        }
        ChipsRow(FilterLabels, chip) { chip = it }
        if (q.isBlank()) {
            LazyColumn(Modifier.fillMaxSize()) {
                if (vm.searches.isNotEmpty()) {
                    item {
                        SectionTitle("Recent Searches", "Clear") { vm.clearSearches() }
                    }
                    items(vm.searches) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { q = s }.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.History, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(16.dp)); Text(s)
                        }
                    }
                }
                item { SectionTitle("Suggestions", "") {} }
                items(listOf("DCIM", "Download", "Documents", "Pictures")) { n ->
                    ActionRow(Icons.Outlined.Folder, FolderYellow, n, null) {
                        vm.push(Screen.Files(File(vm.root, n).path))
                    }
                }
            }
        } else {
            FileCollection(
                results, vm, false,
                onOpen = { vm.addSearch(q); vm.open(ctx, it) },
                emptyText = "No results for \"$q\""
            )
        }
    }
}

// ---------------- RECENT / STARRED / SHARED ----------------
@Composable
fun PathListScreen(vm: AppViewModel, title: String, paths: List<String>, emptyText: String) {
    val ctx = LocalContext.current
    val prefix = vm.root.path + "/"
    val files by produceState(
        paths.map { File(it) }.filter { it.path.startsWith(prefix) }, paths, vm.tick, vm.root
    ) {
        value = withContext(Dispatchers.IO) {
            paths.map { File(it) }.filter { it.path.startsWith(prefix) && it.exists() }.also { r -> r.forEach { metaOf(it) } }
        }
    }
    Column(Modifier.fillMaxSize()) {
        if (vm.selected.isNotEmpty()) SelectionTop(vm, files) else SimpleTop(title, onBack = { vm.pop() })
        FileCollection(files, vm, false, onOpen = { vm.open(ctx, it) }, emptyText = emptyText)
    }
}

// ---------------- RECYCLE BIN ----------------
@Composable
fun TrashScreen(vm: AppViewModel) {
    // null = no dialog, "" = empty whole bin, otherwise the trash entry to delete forever
    var confirm by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        SimpleTop("Recycle Bin", onBack = { vm.pop() }) {
            if (vm.trash.isNotEmpty()) TextButton(onClick = { confirm = "" }) { Text("Empty") }
        }
        if (vm.trash.isEmpty()) {
            EmptyState("Recycle Bin is empty")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.trash, key = { it }) { e ->
                    val stored = vm.trashFile(e)
                    val orig = e.substringAfter('\t')
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        FileThumb(stored, Modifier.size(46.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stored.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                            Text(orig, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { vm.restore(e) }) { Icon(Icons.Outlined.Restore, "Restore") }
                        IconButton(onClick = { confirm = e }) { Icon(Icons.Outlined.DeleteForever, "Delete forever") }
                    }
                }
            }
        }
    }
    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (c.isEmpty()) "Empty Recycle Bin?" else "Delete permanently?") },
            text = { Text(if (c.isEmpty()) "All ${vm.trash.size} item(s) will be erased for good. This cannot be undone." else "This file will be erased for good. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    if (c.isEmpty()) vm.emptyTrash() else vm.deleteForever(c)
                }) { Text("Delete", color = Color(0xFFE53935)) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
}
